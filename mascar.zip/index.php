<?php
require_once __DIR__ . '/config.php';

$stmt = db()->prepare("SELECT * FROM vehicles WHERE status != 'pasif' AND is_featured = 1 ORDER BY created_at DESC LIMIT 3");
$stmt->execute();
$featuredVehicles = $stmt->fetchAll();

if (count($featuredVehicles) < 3) {
    $need = 3 - count($featuredVehicles);
    $ids = array_column($featuredVehicles, 'id') ?: [0];
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $fill = db()->prepare("SELECT * FROM vehicles WHERE status = 'musait' AND id NOT IN ($ph) ORDER BY created_at DESC LIMIT " . (int)$need);
    $fill->execute($ids);
    $featuredVehicles = array_merge($featuredVehicles, $fill->fetchAll());
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,viewport-fit=cover">
<meta name="description" content="Mas-Car Auto Özel Servis Kocaali; araç kiralama, kaporta, boya, mekanik ve elektrik hizmetleri. Kocaali Sakarya'da güvenilir oto servis ve rent a car çözümleri.">
<meta name="keywords" content="kocaali oto servis, kocaali rent a car, sakarya araç kiralama, kocaali özel servis, kaporta boya, mekanik, oto elektrik, mas-car auto">
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="https://www.mascarauto.com.tr/">
<meta property="og:title" content="Mas-Car Auto Özel Servis Kocaali | Rent A Car & Oto Servis">
<meta property="og:description" content="Kocaali'de güvenilir araç kiralama ve özel oto servis hizmetleri. Kaporta, boya, mekanik, elektrik ve daha fazlası.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.mascarauto.com.tr/">
<meta property="og:site_name" content="Mas-Car Auto">
<meta property="og:locale" content="tr_TR">
<title>Ana Sayfa | Mas-Car Auto Özel Servis Kocaali</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="css/style.css">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": ["AutoRepair", "LocalBusiness"],
      "@id": "https://www.mascarauto.com.tr/#autorepair",
      "name": "Mas-Car Auto Özel Servis Kocaali",
      "url": "https://www.mascarauto.com.tr/",
      "telephone": "+905424495454",
      "priceRange": "₺₺",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Yayla Mah. Gaffar Okkan Cad. No:1",
        "addressLocality": "Kocaali",
        "addressRegion": "Sakarya",
        "postalCode": "54600",
        "addressCountry": "TR"
      },
      "geo": { "@type": "GeoCoordinates", "latitude": 41.0458, "longitude": 30.8600 },
      "openingHoursSpecification": [
        { "@type": "OpeningHoursSpecification", "dayOfWeek": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"], "opens": "08:30", "closes": "19:00" }
      ],
      "areaServed": "Kocaali, Sakarya"
    },
    {
      "@type": "BreadcrumbList",
      "@id": "https://www.mascarauto.com.tr/#breadcrumb",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Ana Sayfa", "item": "https://www.mascarauto.com.tr/" }
      ]
    }
  ]
}
</script>
</head>
<body>
<a href="#main-content" class="skip-link">İçeriğe geç</a>
<div id="loading-screen" aria-hidden="true"><div class="loader-mark">MAS-CAR AUTO<div class="loader-bar"><span></span></div></div></div>

<header class="mc-header">
  <nav class="mc-nav container">
    <a class="mc-brand navbar-brand" href="index.php"><span class="brand-mark">M</span>Mas-Car <span class="hide-sm d-none d-sm-inline">Auto</span></a>
    <button class="nav-toggle navbar-toggler" id="navToggle" aria-label="Menü"><i class="bi bi-list"></i></button>
    <ul class="nav-links" id="navLinks">
      <li><a href="index.php" class="nav-link active">Ana Sayfa</a></li>
      <li><a href="service.php" class="nav-link">Hizmetler</a></li>
      <li><a href="gallery.php" class="nav-link">Galeri</a></li>
      <li><a href="rent.php" class="nav-link">Araç Kiralama</a></li>
      <li><a href="about.html" class="nav-link">Hakkımızda</a></li>
      <li><a href="contact.html" class="nav-link">İletişim</a></li>
    </ul>
    <div class="header-actions">
      <a href="tel:+905424495454" class="icon-btn" aria-label="Ara"><i class="bi bi-telephone-fill"></i></a>
      <a href="contact.html" class="btn btn-mc-primary btn-sm-pill">Randevu Al</a>
    </div>
  </nav>
</header>

<!-- Offcanvas Mobile Menu -->
<div class="offcanvas-overlay"></div>
<div class="offcanvas-panel">
  <div class="offcanvas-header">
    <a href="index.php" class="navbar-brand" style="color:var(--mc-black)"><span class="brand-mark">M</span>Mas-Car Auto</a>
    <button class="offcanvas-close" aria-label="Kapat"><i class="bi bi-x-lg"></i></button>
  </div>
  <nav class="offcanvas-nav">
    <a href="index.php" class="active">Ana Sayfa</a>
    <a href="service.php">Hizmetler</a>
    <a href="gallery.php">Galeri</a>
    <a href="rent.php">Araç Kiralama</a>
    <a href="about.html">Hakkımızda</a>
    <a href="contact.html">İletişim</a>
  </nav>
  <div style="margin-top:1.5rem; display:flex; flex-direction:column; gap:.75rem;">
    <a href="tel:+905424495454" class="btn btn-mc-outline w-100"><i class="bi bi-telephone-fill me-2"></i>0 (542) 449 5454</a>
    <a href="https://wa.me/905424495454" target="_blank" rel="noopener" class="btn btn-mc-primary w-100"><i class="bi bi-whatsapp me-2"></i>WhatsApp</a>
  </div>
</div>

<main id="main-content">

  <!-- HERO -->
  <section class="hero" id="hero">
    <div class="hero-media">
      <img src="https://images.unsplash.com/photo-1493238792000-8113da705763?auto=format&fit=crop&w=1920&q=80" alt="Mas-Car Auto özel servis" fetchpriority="high">
    </div>
    <div class="container hero-content">
      <div class="row">
        <div class="col-lg-8">
          <span class="eyebrow reveal">Kocaali · Sakarya</span>
          <h1 class="hero-title reveal reveal-delay-1">Aracınız İçin <em>Güven</em>, Yolculuğunuz İçin <em>Özgürlük</em></h1>
          <p class="hero-sub reveal reveal-delay-2">Kaporta, boya, mekanik, elektrik ve araç kiralama hizmetlerimizle Kocaali'de tek adresiniz. Uzman kadromuz ve modern ekipmanlarımızla yanınızdayız.</p>
          <div class="hero-cta reveal reveal-delay-3">
            <a href="rent.php" class="btn btn-mc-primary"><i class="bi bi-car-front-fill me-2"></i>Araç Kirala</a>
            <a href="service.php" class="btn btn-mc-outline-light"><i class="bi bi-calendar-check me-2"></i>Hizmetlerimiz</a>
            <a href="tel:+905424495454" class="btn btn-mc-outline-light"><i class="bi bi-telephone-fill me-2"></i>Bizi Ara</a>
          </div>
          <div class="hero-stats reveal reveal-delay-3">
            <div><div class="stat-num">18+</div><div class="stat-label">Yıllık Deneyim</div></div>
            <div><div class="stat-num">12.400+</div><div class="stat-label">Bakımı Yapılan Araç</div></div>
            <div><div class="stat-num">4.9/5</div><div class="stat-label">Müşteri Memnuniyeti</div></div>
          </div>
        </div>
      </div>
    </div>
    <div class="hero-scroll"><span>Aşağı Kaydır</span><span class="dot"></span></div>
  </section>
  <div class="pit-stripe" aria-hidden="true"></div>

  <!-- HİZMETLER -->
  <section class="bg-fog" id="hizmetler" aria-labelledby="hizmetler-title">
    <div class="container">
      <div class="row justify-content-center text-center mb-5">
        <div class="col-lg-7 reveal">
          <span class="eyebrow justify-content-center">Özel Servis</span>
          <h2 class="section-title" id="hizmetler-title">Hizmet Alanlarımız</h2>
          <p class="section-lead mx-auto">Marka bağımsız, tüm otomobil modellerine yönelik profesyonel bakım ve onarım hizmeti sunuyoruz.</p>
        </div>
      </div>
      <div class="row g-4">
        <div class="col-md-6 col-lg-3 reveal">
          <a href="service.php#kaporta" class="d-block">
            <div class="service-card card-hover">
              <div class="icon-tile"><i class="bi bi-car-front"></i></div>
              <h3>Kaporta</h3>
              <p>Şase düzeltme, göçük giderme ve kaporta onarımı.</p>
            </div>
          </a>
        </div>
        <div class="col-md-6 col-lg-3 reveal reveal-delay-1">
          <a href="service.php#boya" class="d-block">
            <div class="service-card card-hover">
              <div class="icon-tile"><i class="bi bi-palette-fill"></i></div>
              <h3>Boya</h3>
              <p>Fırın boya, parça boya, pasta cila ve boya koruma.</p>
            </div>
          </a>
        </div>
        <div class="col-md-6 col-lg-3 reveal reveal-delay-2">
          <a href="service.php#mekanik" class="d-block">
            <div class="service-card card-hover">
              <div class="icon-tile"><i class="bi bi-tools"></i></div>
              <h3>Mekanik</h3>
              <p>Ön takım, amortisör, motor ve tüm mekanik onarım.</p>
            </div>
          </a>
        </div>
        <div class="col-md-6 col-lg-3 reveal reveal-delay-3">
          <a href="service.php#elektrik" class="d-block">
            <div class="service-card card-hover">
              <div class="icon-tile"><i class="bi bi-lightning-charge-fill"></i></div>
              <h3>Elektrik</h3>
              <p>Bilgisayarlı arıza tespiti, far bakımı ve tesisat tamiri.</p>
            </div>
          </a>
        </div>
      </div>
      <div class="text-center mt-5 reveal">
        <a href="service.php" class="btn btn-mc-primary">Tüm Hizmetleri İncele <i class="bi bi-arrow-right ms-1"></i></a>
      </div>
    </div>
  </section>

  <!-- ÖNE ÇIKAN ARAÇLAR -->
  <section id="filo" aria-labelledby="filo-title">
    <div class="container">
      <div class="row justify-content-between align-items-end mb-5">
        <div class="col-lg-7 reveal">
          <span class="eyebrow">Rent A Car</span>
          <h2 class="section-title" id="filo-title">Öne Çıkan Araçlarımız</h2>
          <p class="section-lead">Düzenli bakımdan geçmiş, sigortalı ve temiz araçlarla güvenle yola çıkın.</p>
        </div>
        <div class="col-lg-4 text-lg-end reveal">
          <a href="rent.php" class="btn btn-mc-outline">Tüm Filoyu Görüntüle <i class="bi bi-arrow-right ms-1"></i></a>
        </div>
      </div>
      <div class="row g-4">
        <?php foreach ($featuredVehicles as $i => $v): ?>
        <div class="col-md-6 col-lg-4 reveal <?= $i > 0 ? 'reveal-delay-' . min($i, 3) : '' ?>">
          <div class="vehicle-card card-hover">
            <div class="vehicle-media">
              <span class="vehicle-badge"><?= h(ucfirst($v['segment'])) ?></span>
              <?php if ($v['status'] !== 'musait'): ?>
                <span class="vehicle-badge" style="left:auto;right:.9rem;background:var(--mc-anthracite);"><?= $v['status'] === 'kirada' ? 'Kirada' : 'Bakımda' ?></span>
              <?php endif; ?>
              <img src="<?= $v['main_image'] ? 'uploads/' . h($v['main_image']) : 'https://images.unsplash.com/photo-1493238792000-8113da705763?auto=format&fit=crop&w=800&q=80' ?>" alt="<?= h($v['brand'] . ' ' . $v['model'] . ' kiralık araç') ?>">
            </div>
            <div class="vehicle-body">
              <h3 class="h5 mb-0"><?= h($v['brand'] . ' ' . $v['model']) ?></h3>
              <div class="vehicle-specs">
                <span><i class="bi bi-calendar3"></i><?= (int)$v['year'] ?></span>
                <span><i class="bi bi-fuel-pump"></i><?= h(ucfirst($v['fuel_type'])) ?></span>
                <span><i class="bi bi-gear"></i><?= h(ucfirst($v['gear_type'])) ?></span>
                <span><i class="bi bi-people"></i><?= (int)$v['seats'] ?> Kişi</span>
              </div>
              <div class="justify-content-between align-items-center" style="display:flex;">
                <div class="vehicle-price"><?= number_format((float)$v['daily_price'], 0, ',', '.') ?> ₺ <small>/ günlük</small></div>
                <a href="vehicle-detail.php?id=<?= (int)$v['id'] ?>" class="btn btn-mc-primary btn-sm-pill">Detay</a>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
        <?php if (!$featuredVehicles): ?>
          <div class="col-12"><p class="text-muted text-center py-5">Şu anda listelenecek araç bulunmuyor.</p></div>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <!-- HIZLI RANDEVU FORMU -->
  <section class="bg-fog" id="randevu" aria-labelledby="randevu-title">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-7">
          <div class="text-center mb-4 reveal">
            <span class="eyebrow justify-content-center">Randevu</span>
            <h2 class="section-title" id="randevu-title">Hızlı Randevu Alın</h2>
            <p class="section-lead mx-auto">Formu doldurun, en kısa sürede size dönüş yapalım.</p>
          </div>
          <form class="row g-3 needs-validation" novalidate data-mc-form="appointment" action="process-appointment.php" method="post">
            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
            <div class="col-md-6">
              <label class="form-label">Ad Soyad</label>
              <input type="text" name="full_name" class="form-control" required>
              <div class="invalid-feedback">Lütfen adınızı girin.</div>
            </div>
            <div class="col-md-6">
              <label class="form-label">Telefon</label>
              <input type="tel" name="phone" class="form-control" required>
              <div class="invalid-feedback">Lütfen telefon numaranızı girin.</div>
            </div>
            <div class="col-md-6">
              <label class="form-label">Hizmet</label>
              <select class="form-select" name="service_type" required>
                <option value="">Seçiniz</option>
                <option value="kaporta">Kaporta</option>
                <option value="boya">Boya</option>
                <option value="mekanik">Mekanik</option>
                <option value="elektrik">Elektrik</option>
                <option value="diger">Diğer</option>
              </select>
              <div class="invalid-feedback">Lütfen hizmet seçin.</div>
            </div>
            <div class="col-md-6">
              <label class="form-label">Tercih Edilen Tarih</label>
              <input type="date" name="preferred_date" class="form-control">
            </div>
            <div class="col-12">
              <label class="form-label">Notunuz (opsiyonel)</label>
              <textarea class="form-control" name="message" rows="3" placeholder="Araç modeli, plaka veya özel isteklerinizi belirtin..."></textarea>
            </div>
            <div class="col-12 text-center">
              <button type="submit" class="btn btn-mc-primary px-5">Randevu Talep Et</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- NEDEN BİZİ SEÇİN -->
  <section id="neden-biz" aria-labelledby="neden-title">
    <div class="container">
      <div class="row align-items-center g-5">
        <div class="col-lg-6 reveal">
          <div class="ratio ratio-4x3 rounded-4 overflow-hidden shadow">
            <img src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=900&q=80" alt="Mas-Car Auto uzman teknisyen" style="object-fit:cover">
          </div>
        </div>
        <div class="col-lg-6">
          <span class="eyebrow reveal">Neden Mas-Car Auto?</span>
          <h2 class="section-title reveal reveal-delay-1" id="neden-title">Bizi Tercih Etmeniz İçin Nedenler</h2>
          <div class="why-item reveal">
            <div class="icon-tile"><i class="bi bi-award-fill"></i></div>
            <div><h3 class="h6 mb-1">18 Yıllık Deneyim</h3><p class="mb-0 text-muted small">Kocaali ve çevresinde uzun yıllardır kesintisiz hizmet.</p></div>
          </div>
          <div class="why-item reveal reveal-delay-1">
            <div class="icon-tile"><i class="bi bi-patch-check-fill"></i></div>
            <div><h3 class="h6 mb-1">Orijinal Yedek Parça</h3><p class="mb-0 text-muted small">Onaylı ve orijinal parça kullanım garantisi.</p></div>
          </div>
          <div class="why-item reveal reveal-delay-2">
            <div class="icon-tile"><i class="bi bi-shield-check"></i></div>
            <div><h3 class="h6 mb-1">Garantili İşçilik</h3><p class="mb-0 text-muted small">Tüm işlemler yazılı işçilik garantisi kapsamında.</p></div>
          </div>
          <div class="why-item reveal reveal-delay-3">
            <div class="icon-tile"><i class="bi bi-lightning-fill"></i></div>
            <div><h3 class="h6 mb-1">Hızlı Teslim</h3><p class="mb-0 text-muted small">Randevulu sistemle bekletmeden hızlı hizmet.</p></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- İSTATİSTİKLER -->
  <section class="bg-anthracite">
    <div class="container">
      <div class="row g-4">
        <div class="col-6 col-lg-3"><div class="stat-block"><div class="counter" data-target="12400"><span class="num">0</span><span class="plus">+</span></div><div class="stat-caption">Bakımı Yapılan Araç</div></div></div>
        <div class="col-6 col-lg-3"><div class="stat-block"><div class="counter" data-target="3800"><span class="num">0</span><span class="plus">+</span></div><div class="stat-caption">Teslim Edilen Araç</div></div></div>
        <div class="col-6 col-lg-3"><div class="stat-block"><div class="counter" data-target="9600"><span class="num">0</span><span class="plus">+</span></div><div class="stat-caption">Mutlu Müşteri</div></div></div>
        <div class="col-6 col-lg-3"><div class="stat-block"><div class="counter" data-target="18"><span class="num">0</span><span class="plus">+</span></div><div class="stat-caption">Yıllık Deneyim</div></div></div>
      </div>
    </div>
  </section>

</main>

<footer class="mc-footer">
  <div class="container">
    <div class="footer-grid row g-5">
      <div class="footer-col col-lg-4">
        <a href="index.php" class="mc-brand navbar-brand mb-3 d-inline-flex"><span class="brand-mark">M</span>Mas-Car Auto</a>
        <p>Kocaali'de araç kiralama ve özel oto servis alanında güvenilir çözüm ortağınız.</p>
        <div class="footer-social"><a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a><a href="#" aria-label="Facebook"><i class="bi bi-facebook"></i></a><a href="https://wa.me/905424495454" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a></div>
      </div>
      <div class="footer-col col-lg-2 col-md-4 col-6">
        <h4>Hızlı Menü</h4>
        <a href="index.php">Ana Sayfa</a>
        <a href="service.php">Hizmetler</a>
        <a href="rent.php">Araç Kiralama</a>
        <a href="gallery.php">Galeri</a>
      </div>
      <div class="footer-col col-lg-2 col-md-4 col-6">
        <h4>Kurumsal</h4>
        <a href="about.html">Hakkımızda</a>
        <a href="faq.html">S.S.S.</a>
        <a href="contact.html">İletişim</a>
      </div>
      <div class="footer-col col-lg-4 col-md-4">
        <h4>İletişim</h4>
        <p><i class="bi bi-geo-alt-fill"></i> Yayla Mah. Gaffar Okkan Cad. No:1, Kocaali/Sakarya</p>
        <p><i class="bi bi-telephone-fill"></i> <a href="tel:+905424495454">0 (542) 449 5454</a></p>
        <p><i class="bi bi-envelope-fill"></i> <a href="mailto:info@mascarauto.com.tr">info@mascarauto.com.tr</a></p>
        <p><i class="bi bi-clock-fill"></i> Pzt-Cmt: 08:30-19:00</p>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <span data-current-year></span> Mas-Car Auto Özel Servis Kocaali. Tüm hakları saklıdır.</span>
    </div>
  </div>
</footer>

<div class="floating-actions">
  <a href="#" class="fab fab-top" id="scrollTopBtn" aria-label="Yukarı çık"><i class="bi bi-arrow-up"></i></a>
  <a href="tel:+905424495454" class="fab fab-phone" aria-label="Ara"><i class="bi bi-telephone-fill"></i></a>
  <a href="https://wa.me/905424495454" target="_blank" rel="noopener" class="fab fab-whatsapp" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a>
</div>

<div class="mc-cookie" id="mc-cookie">
  <div class="cookie-content" style="display:flex;align-items:flex-start;gap:.75rem;">
    <i class="bi bi-shield-lock-fill" style="color:var(--mc-red);font-size:1.2rem;flex-shrink:0;margin-top:.15rem;"></i>
    <p>Sitemizde çerezler kullanılmaktadır. KVKK kapsamında <a href="javascript:void(0)" onclick="alert('Kişisel Verilerin Korunması Kanunu (KVKK) kapsamında kişisel verileriniz, site kullanımınızı iyileştirmek ve yasal yükümlülükleri yerine getirmek amacıyla işlenmektedir. Detaylı bilgi için bizimle iletişime geçebilirsiniz.')">açıklama</a> için tıklayın.</p>
  </div>
  <button class="btn btn-mc-primary btn-sm-pill" data-cookie-accept>Kabul Et</button>
</div>

<script src="js/main.js" defer></script>
</body>
</html>

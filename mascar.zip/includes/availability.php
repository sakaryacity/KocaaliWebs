<?php
if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === basename(__FILE__)) { http_response_code(403); exit('Forbidden'); }

function get_busy_ranges(PDO $pdo, int $vehicleId, string $startDate, string $endDate): array {
    $stmt = $pdo->prepare("SELECT start_date, end_date, status FROM rentals WHERE vehicle_id = ? AND status IN ('aktif','rezervasyon') AND start_date <= ? AND end_date >= ? ORDER BY start_date ASC");
    $stmt->execute([$vehicleId, $endDate, $startDate]);
    return $stmt->fetchAll();
}

function find_conflict(string $reqStart, string $reqEnd, string $busyStart, string $busyEnd): bool {
    return $reqStart <= $busyEnd && $reqEnd >= $busyStart;
}

function get_free_ranges(string $startDate, string $endDate, array $busyRanges): array {
    $free = []; $cursor = $startDate;
    foreach ($busyRanges as $busy) {
        $bS = $busy['start_date'] ?? $busy['start']; $bE = $busy['end_date'] ?? $busy['end'];
        if ($cursor < $bS) $free[] = ['start' => $cursor, 'end' => date('Y-m-d', strtotime($bS . ' -1 day'))];
        $cursor = max($cursor, date('Y-m-d', strtotime($bE . ' +1 day')));
    }
    if ($cursor <= $endDate) $free[] = ['start' => $cursor, 'end' => $endDate];
    return $free;
}

function build_availability_report(PDO $pdo, int $vehicleId, string $startDate, string $endDate): array {
    $busy = get_busy_ranges($pdo, $vehicleId, $startDate, $endDate);
    $conflict = null;
    foreach ($busy as $b) {
        $bS = $b['start_date']??$b['start']; $bE = $b['end_date']??$b['end'];
        if (find_conflict($startDate, $endDate, $bS, $bE)) { $conflict = ['start'=>$bS,'end'=>$bE,'status'=>$b['status']]; break; }
    }
    $available = $conflict === null;
    $suggestion = null; $freeRanges = [];
    if (!$available) { $freeRanges = get_free_ranges($startDate, $endDate, $busy); $suggestion = !empty($freeRanges) ? $freeRanges[0] : null; }
    else { $freeRanges = [['start'=>$startDate,'end'=>$endDate]]; }
    return ['requested'=>['available'=>$available,'conflict'=>$conflict,'suggestion'=>$suggestion],'busy_ranges'=>$busy,'free_ranges'=>$freeRanges];
}

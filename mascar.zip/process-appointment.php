<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
function respond(bool $ok, string $msg): void { echo json_encode(['success'=>$ok,'message'=>$msg], JSON_UNESCAPED_UNICODE); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); respond(false, 'Gecersiz istek.'); }
$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
$isJson = stripos($contentType, 'application/json') !== false;
if ($isJson) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $input['csrf_token'] ?? '')) { http_response_code(400); respond(false, 'CSRF dogrulamasi basarisiz.'); }
    $fn=trim($input['full_name']??''); $ph=trim($input['phone']??''); $vi=trim($input['vehicle_info']??'');
    $st=trim($input['service_type']??''); $dt=$input['appointment_date']??''; $tm=$input['appointment_time']??''; $ms=trim($input['message']??'');
} else {
    csrf_check();
    $fn=trim($_POST['full_name']??''); $ph=trim($_POST['phone']??''); $vi=trim($_POST['vehicle_info']??'');
    $st=trim($_POST['service_type']??''); $dt=$_POST['appointment_date']??''; $tm=$_POST['appointment_time']??''; $ms=trim($_POST['message']??'');
}
if ($fn===''||$ph===''||$st===''||!$dt||!$tm) respond(false, 'Lutfen zorunlu alanlari doldurun.');
if (!preg_match('/^[\d\s\+\-\(\)]{7,30}$/', $ph)) respond(false, 'Gecerli bir telefon numarasi girin.');
$dateObj = DateTime::createFromFormat('Y-m-d', $dt);
if (!$dateObj || $dateObj->format('Y-m-d') !== $dt) respond(false, 'Gecerli bir tarih secin.');
if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $tm)) respond(false, 'Gecerli bir saat secin.');
try {
    db()->prepare("INSERT INTO appointments (full_name,phone,vehicle_info,service_type,appointment_date,appointment_time,message) VALUES (?,?,?,?,?,?,?)")
        ->execute([h($fn),h($ph),h($vi)?:null,h($st),$dt,$tm,h($ms)?:null]);
    respond(true, 'Randevu talebiniz alindi! Kisa surede arayarak teyit edecegiz.');
} catch (Throwable $e) { respond(false, 'Bir hata olustu. Lutfen bizi arayin.'); }

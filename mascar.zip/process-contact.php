<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
function respond(bool $ok, string $msg): void { echo json_encode(['success'=>$ok,'message'=>$msg], JSON_UNESCAPED_UNICODE); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); respond(false, 'Gecersiz istek.'); }
$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
$isJson = stripos($contentType, 'application/json') !== false;
if ($isJson) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $input['csrf_token'] ?? '')) { http_response_code(400); respond(false, 'CSRF dogrulamasi basarisiz.'); }
    $fn = trim($input['full_name'] ?? ''); $ph = trim($input['phone'] ?? ''); $em = trim($input['email'] ?? '');
    $su = trim($input['subject'] ?? ''); $ms = trim($input['message'] ?? '');
} else {
    csrf_check();
    $fn = trim($_POST['full_name'] ?? ''); $ph = trim($_POST['phone'] ?? ''); $em = trim($_POST['email'] ?? '');
    $su = trim($_POST['subject'] ?? ''); $ms = trim($_POST['message'] ?? '');
}
if ($fn === '' || $ms === '') respond(false, 'Ad soyad ve mesaj alanlari zorunludur.');
if ($ph !== '' && !preg_match('/^[\d\s\+\-\(\)]{7,30}$/', $ph)) respond(false, 'Gecerli bir telefon numarasi girin.');
if ($em !== '' && !filter_var($em, FILTER_VALIDATE_EMAIL)) respond(false, 'Gecerli bir e-posta adresi girin.');
try {
    db()->prepare("INSERT INTO contact_messages (full_name, phone, email, subject, message) VALUES (?,?,?,?,?)")
        ->execute([h($fn), h($ph)?:null, h($em)?:null, h($su)?:null, h($ms)]);
    respond(true, 'Mesajiniz alindi! En kisa surede size donus yapacagiz.');
} catch (Throwable $e) { respond(false, 'Bir hata olustu. Lutfen bizi arayin.'); }

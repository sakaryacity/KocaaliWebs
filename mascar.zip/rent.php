<?php
require_once __DIR__ . '/config.php';

$stmt = db()->prepare("SELECT * FROM vehicles WHERE status != 'pasif' ORDER BY is_featured DESC, created_at DESC");
$stmt->execute();
$vehicles = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,viewport-fit=cover">
<meta name="description" content="Kocaali'de günlük ve aylık araç kiralama. Ekonomik, sedan ve SUV segmentinde sigortalı, bakımlı araçlarla Mas-Car Auto güvencesi.">
<meta name="keywords" content="kocaali araç kiralama, rent a car, sakarya araç kiralama, günlük araç, aylık araç, mascar auto kiralama">
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="https://www.mascarauto.com.tr/rent.php">
<meta property="og:title" content="Araç Kiralama | Mas-Car Auto Rent A Car Kocaali">
<meta property="og:description" content="Kocaali'de güvenilir araç kiralama. Ekonomik, sedan ve SUV seçenekleri.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.mascarauto.com.tr/rent.php">
<meta property="og:site_name" content="Mas-Car Auto">
<meta property="og:locale" content="tr_TR">
<title>Araç Kiralama | Mas-Car Auto Özel Servis Kocaali</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="css/style.css">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        {"@type":"ListItem","position":1,"name":"Ana Sayfa","item":"https://www.mascarauto.com.tr/"},
        {"@type":"ListItem","position":2,"name":"Araç Kiralama","item":"https://www.mascarauto.com.tr/rent.php"}
      ]
    },
    {
      "@type": "CarRental",
      "name": "Mas-Car Auto Rent A Car",
      "url": "https://www.mascarauto.com.tr/rent.php",
      "telephone": "+905424495454",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Yayla Mah. Gaffar Okkan Cad. No:1",
        "addressLocality": "Kocaali",
        "addressRegion": "Sakarya",
        "addressCountry": "TR"
      }
    }
  ]
}
</script>
</head>
<body>
<a href="#main-content" class="skip-link">İçeriğe geç</a>
<div id="loading-screen" aria-hidden="true"><div class="loader-mark">MAS-CAR AUTO<div class="loader-bar"><span></span></div></div></div>

<header class="mc-header">
  <nav class="mc-nav container">
    <a class="mc-brand navbar-brand" href="index.php"><span class="brand-mark">M</span>Mas-Car <span class="hide-sm d-none d-sm-inline">Auto</span></a>
    <button class="nav-toggle navbar-toggler" id="navToggle" aria-label="Menü"><i class="bi bi-list"></i></button>
    <ul class="nav-links" id="navLinks">
      <li><a href="index.php" class="nav-link">Ana Sayfa</a></li>
      <li><a href="service.php" class="nav-link">Hizmetler</a></li>
      <li><a href="gallery.php" class="nav-link">Galeri</a></li>
      <li><a href="rent.php" class="nav-link active">Araç Kiralama</a></li>
      <li><a href="about.html" class="nav-link">Hakkımızda</a></li>
      <li><a href="contact.html" class="nav-link">İletişim</a></li>
    </ul>
    <div class="header-actions">
      <a href="tel:+905424495454" class="icon-btn" aria-label="Ara"><i class="bi bi-telephone-fill"></i></a>
      <a href="contact.html" class="btn btn-mc-primary btn-sm-pill">Randevu Al</a>
    </div>
  </nav>
</header>

<!-- Offcanvas Mobile Menu -->
<div class="offcanvas-overlay"></div>
<div class="offcanvas-panel">
  <div class="offcanvas-header">
    <a href="index.php" class="navbar-brand" style="color:var(--mc-black)"><span class="brand-mark">M</span>Mas-Car Auto</a>
    <button class="offcanvas-close" aria-label="Kapat"><i class="bi bi-x-lg"></i></button>
  </div>
  <nav class="offcanvas-nav">
    <a href="index.php">Ana Sayfa</a>
    <a href="service.php">Hizmetler</a>
    <a href="gallery.php">Galeri</a>
    <a href="rent.php" class="active">Araç Kiralama</a>
    <a href="about.html">Hakkımızda</a>
    <a href="contact.html">İletişim</a>
  </nav>
  <div style="margin-top:1.5rem; display:flex; flex-direction:column; gap:.75rem;">
    <a href="tel:+905424495454" class="btn btn-mc-outline w-100"><i class="bi bi-telephone-fill me-2"></i>0 (542) 449 5454</a>
    <a href="https://wa.me/905424495454" target="_blank" rel="noopener" class="btn btn-mc-primary w-100"><i class="bi bi-whatsapp me-2"></i>WhatsApp</a>
  </div>
</div>

<div class="page-hero">
  <div class="container">
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="index.php">Ana Sayfa</a></li><li class="breadcrumb-item active" aria-current="page">Araç Kiralama</li></ol></nav>
    <h1 class="display-5">Araç Kiralama Filomuz</h1>
  </div>
</div>

<main id="main-content">

<!-- FİLTRE & FİLO -->
<section id="filo">
  <div class="container">
    <div class="filter-bar reveal" style="margin-top:-3rem;">
      <form class="row g-3 align-items-end" id="vehicle-filter-form">
        <div class="col-6 col-md-3">
          <label class="form-label mb-1 small text-muted">Segment</label>
          <select class="form-select" id="filter-type">
            <option value="all">Tüm Segmentler</option>
            <option value="ekonomik">Ekonomik</option>
            <option value="sedan">Sedan</option>
            <option value="suv">SUV</option>
            <option value="hatchback">Hatchback</option>
          </select>
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label mb-1 small text-muted">Yakıt</label>
          <select class="form-select" id="filter-fuel">
            <option value="all">Tümü</option>
            <option value="dizel">Dizel</option>
            <option value="benzin">Benzin</option>
            <option value="hibrit">Hibrit</option>
          </select>
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label mb-1 small text-muted">Vites</label>
          <select class="form-select" id="filter-gear">
            <option value="all">Tümü</option>
            <option value="otomatik">Otomatik</option>
            <option value="manuel">Manuel</option>
          </select>
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label mb-1 small text-muted">Durum</label>
          <select class="form-select" id="filter-status">
            <option value="all">Tümü</option>
            <option value="musait">Müsait</option>
            <option value="kirada">Kirada</option>
          </select>
        </div>
      </form>
    </div>

    <div class="row g-4 mt-4" id="vehicleGrid">
      <?php if (!$vehicles): ?>
        <div class="col-12"><p class="text-muted text-center py-5">Şu anda listelenecek araç bulunmuyor. Lütfen daha sonra tekrar kontrol edin.</p></div>
      <?php endif; ?>
      <?php foreach ($vehicles as $v): ?>
      <div class="col-md-6 col-lg-4 vehicle-col reveal">
        <div class="vehicle-card card-hover" data-vehicle-card data-brand="<?= h(strtolower($v['brand'])) ?>" data-fuel="<?= h($v['fuel_type']) ?>" data-gear="<?= h($v['gear_type']) ?>" data-type="<?= h($v['segment']) ?>" data-status="<?= h($v['status']) ?>">
          <div class="vehicle-media">
            <span class="vehicle-badge"><?= h(ucfirst($v['segment'])) ?></span>
            <?php if ($v['status'] !== 'musait'): ?>
              <span class="vehicle-badge" style="left:auto;right:.9rem;background:var(--mc-anthracite);"><?= $v['status'] === 'kirada' ? 'Kirada' : 'Bakımda' ?></span>
            <?php endif; ?>
            <img src="<?= $v['main_image'] ? 'uploads/' . h($v['main_image']) : 'https://images.unsplash.com/photo-1493238792000-8113da705763?auto=format&fit=crop&w=800&q=80' ?>" alt="<?= h($v['brand'] . ' ' . $v['model'] . ' kiralık araç') ?>">
          </div>
          <div class="vehicle-body">
            <h2 class="h5 mb-0"><?= h($v['brand'] . ' ' . $v['model']) ?></h2>
            <div class="vehicle-specs">
              <span><i class="bi bi-calendar3"></i><?= (int)$v['year'] ?></span>
              <span><i class="bi bi-fuel-pump"></i><?= h(ucfirst($v['fuel_type'])) ?></span>
              <span><i class="bi bi-gear"></i><?= h(ucfirst($v['gear_type'])) ?></span>
              <span><i class="bi bi-people"></i><?= (int)$v['seats'] ?> Kişi</span>
            </div>
            <div class="justify-content-between align-items-center" style="display:flex;">
              <div class="vehicle-price"><?= number_format((float)$v['daily_price'], 0, ',', '.') ?> ₺ <small>/ günlük</small></div>
              <a href="vehicle-detail.php?id=<?= (int)$v['id'] ?>" class="btn btn-mc-primary btn-sm-pill">Detay</a>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- REZERVASYON FORMU -->
<section class="bg-fog">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="text-center mb-4 reveal">
          <span class="eyebrow justify-content-center">Rezervasyon</span>
          <h2 class="section-title">Rezervasyon Talep Formu</h2>
          <p class="section-lead mx-auto">Formu doldurun, size en kısa sürede dönüş yapalım.</p>
        </div>
        <form class="row g-3 needs-validation reveal" novalidate data-mc-form="reservation" action="process-reservation.php" method="post">
          <div class="col-md-6">
            <label class="form-label">Ad Soyad</label>
            <input type="text" name="full_name" class="form-control" required>
            <div class="invalid-feedback">Lütfen adınızı girin.</div>
          </div>
          <div class="col-md-6">
            <label class="form-label">Telefon</label>
            <input type="tel" name="phone" class="form-control" required>
            <div class="invalid-feedback">Lütfen telefon numaranızı girin.</div>
          </div>
          <div class="col-md-6">
            <label class="form-label">Araç Seçimi</label>
            <select class="form-select" name="vehicle" id="resVehicleSelect" required>
              <option value="">Seçiniz</option>
              <?php foreach ($vehicles as $v): ?>
                <option value="<?= h($v['brand'] . ' ' . $v['model']) ?>" data-vehicle-id="<?= (int)$v['id'] ?>"><?= h($v['brand'] . ' ' . $v['model']) ?> (<?= h(ucfirst($v['segment'])) ?>)</option>
              <?php endforeach; ?>
            </select>
            <input type="hidden" name="vehicle_id" id="resVehicleId">
            <div class="invalid-feedback">Lütfen bir araç seçin.</div>
          </div>
          <div class="col-md-6">
            <label class="form-label">Kiralama Süresi</label>
            <select class="form-select" name="duration" required>
              <option value="">Seçiniz</option>
              <option>Günlük</option>
              <option>Haftalık</option>
              <option>Aylık</option>
            </select>
            <div class="invalid-feedback">Lütfen süre seçin.</div>
          </div>
          <div class="col-md-3">
            <label class="form-label">Alış Tarihi</label>
            <input type="date" name="start_date" class="form-control" required>
            <div class="invalid-feedback">Tarih seçin.</div>
          </div>
          <div class="col-md-3">
            <label class="form-label">Alış Saati</label>
            <input type="time" name="pickup_time" class="form-control" value="10:00">
          </div>
          <div class="col-md-3">
            <label class="form-label">Teslim Tarihi</label>
            <input type="date" name="end_date" class="form-control" required>
            <div class="invalid-feedback">Tarih seçin.</div>
          </div>
          <div class="col-md-3">
            <label class="form-label">Teslim Saati</label>
            <input type="time" name="return_time" class="form-control" value="10:00">
          </div>
          <div class="col-12">
            <label class="form-label">Notunuz (opsiyonel)</label>
            <textarea class="form-control" name="message" rows="3" placeholder="Özel isteklerinizi belirtin..."></textarea>
          </div>
          <div class="col-12 text-center">
            <button type="submit" class="btn btn-mc-primary px-5">Rezervasyon Talebi Gönder</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>

</main>

<footer class="mc-footer">
  <div class="container">
    <div class="footer-grid row g-5">
      <div class="footer-col col-lg-4">
        <a href="index.php" class="mc-brand navbar-brand mb-3 d-inline-flex"><span class="brand-mark">M</span>Mas-Car Auto</a>
        <p>Kocaali'de araç kiralama ve özel oto servis alanında güvenilir çözüm ortağınız.</p>
        <div class="footer-social"><a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a><a href="#" aria-label="Facebook"><i class="bi bi-facebook"></i></a><a href="https://wa.me/905424495454" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a></div>
      </div>
      <div class="footer-col col-lg-2 col-md-4 col-6">
        <h4>Hızlı Menü</h4>
        <a href="index.php">Ana Sayfa</a>
        <a href="service.php">Hizmetler</a>
        <a href="rent.php">Araç Kiralama</a>
        <a href="gallery.php">Galeri</a>
      </div>
      <div class="footer-col col-lg-2 col-md-4 col-6">
        <h4>Kurumsal</h4>
        <a href="about.html">Hakkımızda</a>
        <a href="faq.html">S.S.S.</a>
        <a href="contact.html">İletişim</a>
      </div>
      <div class="footer-col col-lg-4 col-md-4">
        <h4>İletişim</h4>
        <p><i class="bi bi-geo-alt-fill"></i> Yayla Mah. Gaffar Okkan Cad. No:1, Kocaali/Sakarya</p>
        <p><i class="bi bi-telephone-fill"></i> <a href="tel:+905424495454">0 (542) 449 5454</a></p>
        <p><i class="bi bi-envelope-fill"></i> <a href="mailto:info@mascarauto.com.tr">info@mascarauto.com.tr</a></p>
        <p><i class="bi bi-clock-fill"></i> Pzt-Cmt: 08:30-19:00</p>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <span data-current-year></span> Mas-Car Auto Özel Servis Kocaali. Tüm hakları saklıdır.</span>
    </div>
  </div>
</footer>

<div class="floating-actions">
  <a href="#" class="fab fab-top" id="scrollTopBtn" aria-label="Yukarı çık"><i class="bi bi-arrow-up"></i></a>
  <a href="tel:+905424495454" class="fab fab-phone" aria-label="Ara"><i class="bi bi-telephone-fill"></i></a>
  <a href="https://wa.me/905424495454" target="_blank" rel="noopener" class="fab fab-whatsapp" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a>
</div>

<div class="mc-cookie" id="mc-cookie">
  <div class="cookie-content" style="display:flex;align-items:flex-start;gap:.75rem;">
    <i class="bi bi-shield-lock-fill" style="color:var(--mc-red);font-size:1.2rem;flex-shrink:0;margin-top:.15rem;"></i>
    <p>Sitemizde çerezler kullanılmaktadır. KVKK kapsamında <a href="javascript:void(0)" onclick="alert('Kişisel Verilerin Korunması Kanunu (KVKK) kapsamında kişisel verileriniz, site kullanımınızı iyileştirmek ve yasal yükümlülükleri yerine getirmek amacıyla işlenmektedir. Detaylı bilgi için bizimle iletişime geçebilirsiniz.')">açıklama</a> için tıklayın.</p>
  </div>
  <button class="btn btn-mc-primary btn-sm-pill" data-cookie-accept>Kabul Et</button>
</div>

<script src="js/main.js" defer></script>
</body>
</html>

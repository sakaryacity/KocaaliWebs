<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,viewport-fit=cover">
<meta name="description" content="Mas-Car Auto hizmetleri: Kaporta onarımı, fırın boya, mekanik bakım, oto elektrik. Kocaali Sakarya'da profesyonel ve garantili oto servis hizmetleri.">
<meta name="keywords" content="oto kaporta, oto boya, mekanik bakım, oto elektrik, arıza tespit, kocaali servis, mascar auto hizmetler">
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="https://www.mascarauto.com.tr/service.php">
<meta property="og:title" content="Hizmetlerimiz | Mas-Car Auto Özel Servis Kocaali">
<meta property="og:description" content="Kaporta, boya, mekanik ve elektrik hizmetlerimizle Kocaali'de tek adresiniz.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.mascarauto.com.tr/service.php">
<meta property="og:site_name" content="Mas-Car Auto">
<meta property="og:locale" content="tr_TR">
<title>Hizmetler | Mas-Car Auto Özel Servis Kocaali</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="css/style.css">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {"@type":"ListItem","position":1,"name":"Ana Sayfa","item":"https://www.mascarauto.com.tr/"},
    {"@type":"ListItem","position":2,"name":"Hizmetler","item":"https://www.mascarauto.com.tr/service.php"}
  ]
}
</script>
</head>
<body>
<a href="#main-content" class="skip-link">İçeriğe geç</a>
<div id="loading-screen" aria-hidden="true"><div class="loader-mark">MAS-CAR AUTO<div class="loader-bar"><span></span></div></div></div>

<header class="mc-header">
  <nav class="mc-nav container">
    <a class="mc-brand navbar-brand" href="index.php"><span class="brand-mark">M</span>Mas-Car <span class="hide-sm d-none d-sm-inline">Auto</span></a>
    <button class="nav-toggle navbar-toggler" id="navToggle" aria-label="Menü"><i class="bi bi-list"></i></button>
    <ul class="nav-links" id="navLinks">
      <li><a href="index.php" class="nav-link">Ana Sayfa</a></li>
      <li><a href="service.php" class="nav-link active">Hizmetler</a></li>
      <li><a href="gallery.php" class="nav-link">Galeri</a></li>
      <li><a href="rent.php" class="nav-link">Araç Kiralama</a></li>
      <li><a href="about.html" class="nav-link">Hakkımızda</a></li>
      <li><a href="contact.html" class="nav-link">İletişim</a></li>
    </ul>
    <div class="header-actions">
      <a href="tel:+905424495454" class="icon-btn" aria-label="Ara"><i class="bi bi-telephone-fill"></i></a>
      <a href="contact.html" class="btn btn-mc-primary btn-sm-pill">Randevu Al</a>
    </div>
  </nav>
</header>

<!-- Offcanvas Mobile Menu -->
<div class="offcanvas-overlay"></div>
<div class="offcanvas-panel">
  <div class="offcanvas-header">
    <a href="index.php" class="navbar-brand" style="color:var(--mc-black)"><span class="brand-mark">M</span>Mas-Car Auto</a>
    <button class="offcanvas-close" aria-label="Kapat"><i class="bi bi-x-lg"></i></button>
  </div>
  <nav class="offcanvas-nav">
    <a href="index.php">Ana Sayfa</a>
    <a href="service.php" class="active">Hizmetler</a>
    <a href="gallery.php">Galeri</a>
    <a href="rent.php">Araç Kiralama</a>
    <a href="about.html">Hakkımızda</a>
    <a href="contact.html">İletişim</a>
  </nav>
  <div style="margin-top:1.5rem; display:flex; flex-direction:column; gap:.75rem;">
    <a href="tel:+905424495454" class="btn btn-mc-outline w-100"><i class="bi bi-telephone-fill me-2"></i>0 (542) 449 5454</a>
    <a href="https://wa.me/905424495454" target="_blank" rel="noopener" class="btn btn-mc-primary w-100"><i class="bi bi-whatsapp me-2"></i>WhatsApp</a>
  </div>
</div>

<div class="page-hero">
  <div class="container">
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="index.php">Ana Sayfa</a></li><li class="breadcrumb-item active" aria-current="page">Hizmetler</li></ol></nav>
    <h1 class="display-5">Hizmetlerimiz</h1>
  </div>
</div>

<main id="main-content">

  <!-- KAPORTA -->
  <section id="kaporta" aria-labelledby="kaporta-title">
    <div class="container">
      <div class="row align-items-center g-5">
        <div class="col-lg-6 reveal">
          <span class="eyebrow">Kaporta</span>
          <h2 class="section-title" id="kaporta-title">Kaporta Onarım & Şase Düzeltme</h2>
          <p class="text-muted">Kazalı veya hasarlı araçlarınızın kaporta onarımını en modern ekipmanlarla gerçekleştiriyoruz. Ağır şase çekme, spot kaynak çekme ve boyasız göçük düzeltme (PDR) hizmetlerimizle aracınızı ilk günkü haline getiriyoruz.</p>
          <ul class="svc-list" style="margin-top:1.5rem;">
            <li><i class="bi bi-check-circle-fill"></i><span>Ağır Şase Çektirme ve Düzeltme</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Spot Çektirme & Kaynak İşlemleri</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Boyasız Göçük Düzeltme (PDR)</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Parça Değişimi ve Montaj</span></li>
          </ul>
          <a href="contact.html" class="btn btn-mc-primary mt-4"><i class="bi bi-calendar-check me-2"></i>Randevu Al</a>
        </div>
        <div class="col-lg-6 reveal reveal-delay-1">
          <div class="ratio ratio-4x3 rounded-4 overflow-hidden shadow">
            <img src="https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=900&q=80" alt="Kaporta onarım hizmeti" style="object-fit:cover">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- BOYA -->
  <section class="bg-fog" id="boya" aria-labelledby="boya-title">
    <div class="container">
      <div class="row align-items-center g-5">
        <div class="col-lg-6 order-lg-2 reveal">
          <span class="eyebrow">Boya</span>
          <h2 class="section-title" id="boya-title">Fırın Oto Boya & Cila</h2>
          <p class="text-muted">Profesyonel fırın boya kabimizde, aracınızın orijinal rengine en uygun renk eşleştirmesi yapılıyor. Pasta cila, boyama ve boya koruma (seramik kaplama) işlemleriyle aracınızı yeniliyoruz.</p>
          <ul class="svc-list" style="margin-top:1.5rem;">
            <li><i class="bi bi-check-circle-fill"></i><span>Fırın Oto Boya</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Parça Boya & Tampon Boyama</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Pasta Cila & Parlaklık</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Boya Koruma (Seramik Kaplama)</span></li>
          </ul>
          <a href="contact.html" class="btn btn-mc-primary mt-4"><i class="bi bi-calendar-check me-2"></i>Randevu Al</a>
        </div>
        <div class="col-lg-6 order-lg-1 reveal reveal-delay-1">
          <div class="ratio ratio-4x3 rounded-4 overflow-hidden shadow">
            <img src="https://images.unsplash.com/photo-1507136566006-cfc505b114fc?auto=format&fit=crop&w=900&q=80" alt="Oto boya hizmeti" style="object-fit:cover">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- MEKANİK -->
  <section id="mekanik" aria-labelledby="mekanik-title">
    <div class="container">
      <div class="row align-items-center g-5">
        <div class="col-lg-6 reveal">
          <span class="eyebrow">Mekanik</span>
          <h2 class="section-title" id="mekanik-title">Mekanik Bakım & Onarım</h2>
          <p class="text-muted">Periyodik bakımdan karmaşık motor onarımlarına kadar tüm mekanik işlemleriniz uzman teknisyenlerimiz tarafından gerçekleştirilmektedir. Orijinal parça kullanımı ve garantili işçilik ile hizmetinizdeyiz.</p>
          <ul class="svc-list" style="margin-top:1.5rem;">
            <li><i class="bi bi-check-circle-fill"></i><span>Ön Takım (Rot, Rotil, Salıncak)</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Amortisör & Süspansiyon</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Devir Dizisi & Kayış Değişimi</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Ateşleme Sistemi & Buji</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Hava Sistemi & Filtre Bakımı</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Fren Sistemleri (Balata, Disk)</span></li>
          </ul>
          <a href="contact.html" class="btn btn-mc-primary mt-4"><i class="bi bi-calendar-check me-2"></i>Randevu Al</a>
        </div>
        <div class="col-lg-6 reveal reveal-delay-1">
          <div class="ratio ratio-4x3 rounded-4 overflow-hidden shadow">
            <img src="https://images.unsplash.com/photo-1632823469850-2b7d1e8b7af0?auto=format&fit=crop&w=900&q=80" alt="Mekanik bakım" style="object-fit:cover">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ELEKTRİK -->
  <section class="bg-fog" id="elektrik" aria-labelledby="elektrik-title">
    <div class="container">
      <div class="row align-items-center g-5">
        <div class="col-lg-6 order-lg-2 reveal">
          <span class="eyebrow">Elektrik</span>
          <h2 class="section-title" id="elektrik-title">Oto Elektrik & Diagnostik</h2>
          <p class="text-muted">Modern araçların karmaşık elektronik sistemlerinde bilgisayarlı arıza tespit cihazlarımızla hızlı ve doğru teşhis koyuyoruz. Akü, alternatör, far ve tüm elektrik tesisatı tamiratları mevcuttur.</p>
          <ul class="svc-list" style="margin-top:1.5rem;">
            <li><i class="bi bi-check-circle-fill"></i><span>Bilgisayarlı Arıza Tespiti (OBD)</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Far Bakımı & Ayarı</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Elektrik Tesisat Tamiri</span></li>
            <li><i class="bi bi-check-circle-fill"></i><span>Akü, Alternatör & Marş Motoru</span></li>
          </ul>
          <a href="contact.html" class="btn btn-mc-primary mt-4"><i class="bi bi-calendar-check me-2"></i>Randevu Al</a>
        </div>
        <div class="col-lg-6 order-lg-1 reveal reveal-delay-1">
          <div class="ratio ratio-4x3 rounded-4 overflow-hidden shadow">
            <img src="https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=900&q=80" alt="Oto elektrik hizmeti" style="object-fit:cover">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- HİZMET KARTLARI ÖZET -->
  <section aria-labelledby="svc-all-title">
    <div class="container">
      <div class="row justify-content-center text-center mb-5">
        <div class="col-lg-7 reveal">
          <span class="eyebrow justify-content-center">Tüm Hizmetler</span>
          <h2 class="section-title" id="svc-all-title">Hizmet Kartlarımız</h2>
        </div>
      </div>
      <div class="row g-4">
        <div class="col-md-6 col-lg-3 reveal">
          <div class="svc-card">
            <div class="svc-card-header">
              <div><span class="svc-card-title">Kaporta</span><span class="svc-card-subtitle">Onarım & Düzeltme</span></div>
              <i class="bi bi-car-front svc-card-icon"></i>
            </div>
            <div class="svc-card-body">
              <ul class="svc-list">
                <li><i class="bi bi-check-lg"></i><span>Şase Çektirme</span></li>
                <li><i class="bi bi-check-lg"></i><span>Spot Çektirme</span></li>
                <li><i class="bi bi-check-lg"></i><span>Boyasız Göçük</span></li>
                <li><i class="bi bi-check-lg"></i><span>Parça Değişimi</span></li>
              </ul>
            </div>
            <div class="svc-card-footer">
              <button class="btn btn-mc-outline btn-sm-pill" onclick="openSvcModal('kaporta')">Detay</button>
              <a href="contact.html" class="btn btn-mc-primary btn-sm-pill">Randevu</a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3 reveal reveal-delay-1">
          <div class="svc-card">
            <div class="svc-card-header">
              <div><span class="svc-card-title">Boya</span><span class="svc-card-subtitle">Fırın & Cila</span></div>
              <i class="bi bi-palette-fill svc-card-icon"></i>
            </div>
            <div class="svc-card-body">
              <ul class="svc-list">
                <li><i class="bi bi-check-lg"></i><span>Fırın Boya</span></li>
                <li><i class="bi bi-check-lg"></i><span>Parça Boya</span></li>
                <li><i class="bi bi-check-lg"></i><span>Pasta Cila</span></li>
                <li><i class="bi bi-check-lg"></i><span>Boya Koruma</span></li>
              </ul>
            </div>
            <div class="svc-card-footer">
              <button class="btn btn-mc-outline btn-sm-pill" onclick="openSvcModal('boya')">Detay</button>
              <a href="contact.html" class="btn btn-mc-primary btn-sm-pill">Randevu</a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3 reveal reveal-delay-2">
          <div class="svc-card">
            <div class="svc-card-header">
              <div><span class="svc-card-title">Mekanik</span><span class="svc-card-subtitle">Bakım & Onarım</span></div>
              <i class="bi bi-tools svc-card-icon"></i>
            </div>
            <div class="svc-card-body">
              <ul class="svc-list">
                <li><i class="bi bi-check-lg"></i><span>Ön Takım</span></li>
                <li><i class="bi bi-check-lg"></i><span>Amortisör</span></li>
                <li><i class="bi bi-check-lg"></i><span>Devir & Kayış</span></li>
                <li><i class="bi bi-check-lg"></i><span>Fren Sistemi</span></li>
              </ul>
            </div>
            <div class="svc-card-footer">
              <button class="btn btn-mc-outline btn-sm-pill" onclick="openSvcModal('mekanik')">Detay</button>
              <a href="contact.html" class="btn btn-mc-primary btn-sm-pill">Randevu</a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3 reveal reveal-delay-3">
          <div class="svc-card">
            <div class="svc-card-header">
              <div><span class="svc-card-title">Elektrik</span><span class="svc-card-subtitle">Arıza & Tamir</span></div>
              <i class="bi bi-lightning-charge-fill svc-card-icon"></i>
            </div>
            <div class="svc-card-body">
              <ul class="svc-list">
                <li><i class="bi bi-check-lg"></i><span>Arıza Tespiti</span></li>
                <li><i class="bi bi-check-lg"></i><span>Far Bakımı</span></li>
                <li><i class="bi bi-check-lg"></i><span>Tesisat Tamiri</span></li>
                <li><i class="bi bi-check-lg"></i><span>Akü & Alternatör</span></li>
              </ul>
            </div>
            <div class="svc-card-footer">
              <button class="btn btn-mc-outline btn-sm-pill" onclick="openSvcModal('elektrik')">Detay</button>
              <a href="contact.html" class="btn btn-mc-primary btn-sm-pill">Randevu</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- NEDEN BİZ -->
  <section class="why-us-section bg-fog" aria-labelledby="why-title">
    <div class="container">
      <div class="row justify-content-center text-center mb-5">
        <div class="col-lg-7 reveal">
          <span class="eyebrow justify-content-center">Farkımız</span>
          <h2 class="section-title" id="why-title">Neden Bizi Tercih Etmelisiniz?</h2>
        </div>
      </div>
      <div class="why-us-grid">
        <div class="why-us-item reveal"><div class="why-us-icon"><i class="bi bi-award-fill"></i></div><h3>18 Yıllık Deneyim</h3><p>Sektördeki uzun yıllarımızın getirdiği bilgi birikimi ve tecrübe.</p></div>
        <div class="why-us-item reveal reveal-delay-1"><div class="why-us-icon"><i class="bi bi-patch-check-fill"></i></div><h3>Orijinal Parça</h3><p>Tüm onarımlarda orijinal ve OEM onaylı parça kullanımı.</p></div>
        <div class="why-us-item reveal reveal-delay-2"><div class="why-us-icon"><i class="bi bi-shield-check"></i></div><h3>Garantili İşçilik</h3><p>6 ay / 10.000 km işçilik garantisi.</p></div>
        <div class="why-us-item reveal reveal-delay-3"><div class="why-us-icon"><i class="bi bi-speedometer2"></i></div><h3>Hızlı Teslimat</h3><p>Randevulu sistemle bekletmeden, zamanında teslim.</p></div>
        <div class="why-us-item reveal"><div class="why-us-icon"><i class="bi bi-cash-stack"></i></div><h3>Şeffaf Fiyat</h3><p>Önceden net fiyat bilgisi, sürpriz masraf yok.</p></div>
        <div class="why-us-item reveal reveal-delay-1"><div class="why-us-icon"><i class="bi bi-people-fill"></i></div><h3>Uzman Kadro</h3><p>Sertifikalı teknisyenlerden oluşan profesyonel ekip.</p></div>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section>
    <div class="container">
      <div class="cta-box reveal">
        <h2 class="section-title" style="color:#fff;">Aracınız İçin Hemen Randevu Alın</h2>
        <p class="text-muted" style="color:rgba(255,255,255,.65);max-width:560px;margin:1rem auto 2rem;">Uzman ekibimiz aracınızı en kısa sürede teslim almaya hazır. Hemen arayın veya randevu formu doldurun.</p>
        <div style="display:flex;gap:.75rem;justify-content:center;flex-wrap:wrap;">
          <a href="contact.html" class="btn btn-mc-primary"><i class="bi bi-calendar-check me-2"></i>Randevu Al</a>
          <a href="tel:+905424495454" class="btn btn-mc-outline-light"><i class="bi bi-telephone-fill me-2"></i>0 (542) 449 5454</a>
        </div>
      </div>
    </div>
  </section>

</main>

<!-- Service Detail Modal -->
<div class="mc-modal-overlay" id="svcModal">
  <div class="mc-modal">
    <div class="mc-modal-header">
      <span class="mc-modal-title" id="svcModalTitle">Hizmet Detayı</span>
      <button class="mc-modal-close" onclick="closeSvcModal()"><i class="bi bi-x-lg"></i></button>
    </div>
    <div class="mc-modal-body" id="svcModalBody"></div>
  </div>
</div>

<script>
const svcDetails = {
  kaporta: {
    title: 'Kaporta Onarım & Şase Düzeltme',
    body: '<p class="text-muted mb-3">Araç gövdesinde meydana gelen deformasyonların onarılması, şase düzeltme ve kaporta parça değişimi işlemlerini profesyonel şekilde gerçekleştiriyoruz.</p><ul class="svc-list"><li><i class="bi bi-check-circle-fill"></i><span>Ağır hasarlı araç şase çekme ve düzeltme</span></li><li><i class="bi bi-check-circle-fill"></i><span>Spot kaynak çekme ve lehim işlemleri</span></li><li><i class="bi bi-check-circle-fill"></i><span>Boyasız göçük düzeltme (PDR) – çiziksiz onarım</span></li><li><i class="bi bi-check-circle-fill"></i><span>Kaporta parça değişimi ve montaj</span></li><li><i class="bi bi-check-circle-fill"></i><span>Hasar değerlendirmesi ve maliyet tahmini</span></li></ul><a href="contact.html" class="btn btn-mc-primary mt-3"><i class="bi bi-calendar-check me-2"></i>Randevu Al</a>'
  },
  boya: {
    title: 'Fırın Oto Boya & Cila',
    body: '<p class="text-muted mb-3">Fırın boya kabimizde, renk koduna uygun hassas boya işlemi yapıyoruz. Aracınızı ilk günkü parlaklığına kavuşturuyoruz.</p><ul class="svc-list"><li><i class="bi bi-check-circle-fill"></i><span>Fırın boya – tam veya parça boyama</span></li><li><i class="bi bi-check-circle-fill"></i><span>Pasta cila ve hologram giderme</span></li><li><i class="bi bi-check-circle-fill"></i><span>Seramik boya koruma uygulaması</span></li><li><i class="bi bi-check-circle-fill"></i><span>Renk eşleştirme ve tonlama</span></li></ul><a href="contact.html" class="btn btn-mc-primary mt-3"><i class="bi bi-calendar-check me-2"></i>Randevu Al</a>'
  },
  mekanik: {
    title: 'Mekanik Bakım & Onarım',
    body: '<p class="text-muted mb-3">Periyodik bakımdan ağır motor onarımlarına kadar tüm mekanik ihtiyaçlarınızı karşılıyoruz. Orijinal parça ve garantili işçilik.</p><ul class="svc-list"><li><i class="bi bi-check-circle-fill"></i><span>Ön takım (rot, rotil, salıncak)</span></li><li><i class="bi bi-check-circle-fill"></i><span>Amortisör ve süspansiyon bakımı</span></li><li><i class="bi bi-check-circle-fill"></i><span>Devir dizisi, triger ve kayış değişimi</span></li><li><i class="bi bi-check-circle-fill"></i><span>Ateşleme sistemi, buji değişimi</span></li><li><i class="bi bi-check-circle-fill"></i><span>Hava filtresi, yağ ve akışkan bakımı</span></li><li><i class="bi bi-check-circle-fill"></i><span>Fren sistemi – balata, disk, hidrolik</span></li></ul><a href="contact.html" class="btn btn-mc-primary mt-3"><i class="bi bi-calendar-check me-2"></i>Randevu Al</a>'
  },
  elektrik: {
    title: 'Oto Elektrik & Diagnostik',
    body: '<p class="text-muted mb-3">Bilgisayarlı arıza tespiti ile modern araç elektronik sistemlerinde hızlı teşhis. Tüm elektrik aksamlarında profesyonel onarım.</p><ul class="svc-list"><li><i class="bi bi-check-circle-fill"></i><span>OBD bilgisayarlı arıza tespiti</span></li><li><i class="bi bi-check-circle-fill"></i><span>Far ayarı, LED/Xenon bakımı</span></li><li><i class="bi bi-check-circle-fill"></i><span>Elektrik tesisat tamir ve yenileme</span></li><li><i class="bi bi-check-circle-fill"></i><span>Akü testi, alternatör, marş motoru</span></li><li><i class="bi bi-check-circle-fill"></i><span>Sinyal, korna ve iç aydınlatma</span></li></ul><a href="contact.html" class="btn btn-mc-primary mt-3"><i class="bi bi-calendar-check me-2"></i>Randevu Al</a>'
  }
};

function openSvcModal(key) {
  const d = svcDetails[key];
  if (!d) return;
  document.getElementById('svcModalTitle').textContent = d.title;
  document.getElementById('svcModalBody').innerHTML = d.body;
  document.getElementById('svcModal').classList.add('is-open');
  document.body.style.overflow = 'hidden';
}
function closeSvcModal() {
  document.getElementById('svcModal').classList.remove('is-open');
  document.body.style.overflow = '';
}
document.getElementById('svcModal').addEventListener('click', function(e) {
  if (e.target === this) closeSvcModal();
});
</script>

<footer class="mc-footer">
  <div class="container">
    <div class="footer-grid row g-5">
      <div class="footer-col col-lg-4">
        <a href="index.php" class="mc-brand navbar-brand mb-3 d-inline-flex"><span class="brand-mark">M</span>Mas-Car Auto</a>
        <p>Kocaali'de araç kiralama ve özel oto servis alanında güvenilir çözüm ortağınız.</p>
        <div class="footer-social"><a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a><a href="#" aria-label="Facebook"><i class="bi bi-facebook"></i></a><a href="https://wa.me/905424495454" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a></div>
      </div>
      <div class="footer-col col-lg-2 col-md-4 col-6">
        <h4>Hızlı Menü</h4>
        <a href="index.php">Ana Sayfa</a>
        <a href="service.php">Hizmetler</a>
        <a href="rent.php">Araç Kiralama</a>
        <a href="gallery.php">Galeri</a>
      </div>
      <div class="footer-col col-lg-2 col-md-4 col-6">
        <h4>Kurumsal</h4>
        <a href="about.html">Hakkımızda</a>
        <a href="faq.html">S.S.S.</a>
        <a href="contact.html">İletişim</a>
      </div>
      <div class="footer-col col-lg-4 col-md-4">
        <h4>İletişim</h4>
        <p><i class="bi bi-geo-alt-fill"></i> Yayla Mah. Gaffar Okkan Cad. No:1, Kocaali/Sakarya</p>
        <p><i class="bi bi-telephone-fill"></i> <a href="tel:+905424495454">0 (542) 449 5454</a></p>
        <p><i class="bi bi-envelope-fill"></i> <a href="mailto:info@mascarauto.com.tr">info@mascarauto.com.tr</a></p>
        <p><i class="bi bi-clock-fill"></i> Pzt-Cmt: 08:30-19:00</p>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <span data-current-year></span> Mas-Car Auto Özel Servis Kocaali. Tüm hakları saklıdır.</span>
    </div>
  </div>
</footer>

<div class="floating-actions">
  <a href="#" class="fab fab-top" id="scrollTopBtn" aria-label="Yukarı çık"><i class="bi bi-arrow-up"></i></a>
  <a href="tel:+905424495454" class="fab fab-phone" aria-label="Ara"><i class="bi bi-telephone-fill"></i></a>
  <a href="https://wa.me/905424495454" target="_blank" rel="noopener" class="fab fab-whatsapp" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a>
</div>

<div class="mc-cookie" id="mc-cookie">
  <div class="cookie-content" style="display:flex;align-items:flex-start;gap:.75rem;">
    <i class="bi bi-shield-lock-fill" style="color:var(--mc-red);font-size:1.2rem;flex-shrink:0;margin-top:.15rem;"></i>
    <p>Sitemizde çerezler kullanılmaktadır. KVKK kapsamında <a href="javascript:void(0)" onclick="alert('Kişisel Verilerin Korunması Kanunu (KVKK) kapsamında kişisel verileriniz, site kullanımınızı iyileştirmek ve yasal yükümlülükleri yerine getirmek amacıyla işlenmektedir. Detaylı bilgi için bizimle iletişime geçebilirsiniz.')">açıklama</a> için tıklayın.</p>
  </div>
  <button class="btn btn-mc-primary btn-sm-pill" data-cookie-accept>Kabul Et</button>
</div>

<script src="js/main.js" defer></script>
</body>
</html>

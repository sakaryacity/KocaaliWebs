<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
function respond(bool $ok, string $msg): void { echo json_encode(['success'=>$ok,'message'=>$msg], JSON_UNESCAPED_UNICODE); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); respond(false, 'Gecersiz istek.'); }
$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
$isJson = stripos($contentType, 'application/json') !== false;
if ($isJson) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $input['csrf_token'] ?? '')) { http_response_code(400); respond(false, 'CSRF dogrulamasi basarisiz.'); }
    $vid=isset($input['vehicle_id'])&&ctype_digit((string)$input['vehicle_id'])?(int)$input['vehicle_id']:null;
    $fn=trim($input['full_name']??''); $ph=trim($input['phone']??''); $vt=trim($input['vehicle']??'');
    $du=trim($input['duration']??''); $sd=$input['start_date']??null; $ed=$input['end_date']??null;
    $pt=trim($input['pickup_time']??''); $rt=trim($input['return_time']??''); $ms=trim($input['message']??'');
} else {
    csrf_check();
    $vid=isset($_POST['vehicle_id'])&&ctype_digit($_POST['vehicle_id'])?(int)$_POST['vehicle_id']:null;
    $fn=trim($_POST['full_name']??''); $ph=trim($_POST['phone']??''); $vt=trim($_POST['vehicle']??'');
    $du=trim($_POST['duration']??''); $sd=$_POST['start_date']??null; $ed=$_POST['end_date']??null;
    $pt=trim($_POST['pickup_time']??''); $rt=trim($_POST['return_time']??''); $ms=trim($_POST['message']??'');
}
if ($fn===''||$ph==='') respond(false, 'Ad soyad ve telefon zorunludur.');
if (!preg_match('/^[\d\s\+\-\(\)]{7,30}$/', $ph)) respond(false, 'Gecerli bir telefon numarasi girin.');
$validDate = fn($d) => $d && DateTime::createFromFormat('Y-m-d', $d) !== false;
$sd = $validDate($sd) ? $sd : null;
$ed = $validDate($ed) ? $ed : null;
$validTime = fn($t) => $t && preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $t);
$pt = $validTime($pt) ? $pt.':00' : null;
$rt = $validTime($rt) ? $rt.':00' : null;
try {
    db()->prepare("INSERT INTO reservation_requests (vehicle_id,full_name,phone,vehicle_text,duration_text,start_date,end_date,pickup_time,return_time,message) VALUES (?,?,?,?,?,?,?,?,?,?)")
        ->execute([$vid,h($fn),h($ph),h($vt)?:null,h($du)?:null,$sd,$ed,$pt,$rt,h($ms)?:null]);
    respond(true, 'Rezervasyon talebiniz alindi! Onay icin sizi arayacagiz.');
} catch (Throwable $e) { respond(false, 'Bir hata olustu. Lutfen bizi arayin.'); }

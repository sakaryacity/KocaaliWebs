<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();
$pdo = db();
$user = admin_current_user();

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $fullName = trim($_POST['full_name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $current  = $_POST['current_password'] ?? '';
    $new1     = $_POST['new_password'] ?? '';
    $new2     = $_POST['new_password_confirm'] ?? '';

    if ($fullName === '') {
        $errors[] = 'Ad soyad bos birakilamaz.';
    }

    if ($new1 !== '' || $new2 !== '' || $current !== '') {
        $stmt = $pdo->prepare('SELECT password_hash FROM admin_users WHERE id = ?');
        $stmt->execute([$user['id']]);
        $row = $stmt->fetch();
        if (!$current || !password_verify($current, $row['password_hash'])) {
            $errors[] = 'Mevcut sifreniz hatali.';
        } elseif (strlen($new1) < 6) {
            $errors[] = 'Yeni sifre en az 6 karakter olmalidir.';
        } elseif ($new1 !== $new2) {
            $errors[] = 'Yeni sifreler eslesmiyor.';
        }
    }

    if (!$errors) {
        if ($new1 !== '') {
            $pdo->prepare('UPDATE admin_users SET full_name=?, email=?, password_hash=? WHERE id=?')
                ->execute([$fullName, $email, password_hash($new1, PASSWORD_BCRYPT), $user['id']]);
            log_activity('Sifre degistirildi');
        } else {
            $pdo->prepare('UPDATE admin_users SET full_name=?, email=? WHERE id=?')
                ->execute([$fullName, $email, $user['id']]);
        }
        $success = 'Hesap bilgileriniz guncellendi.';
        $user = admin_current_user();
    }
}

$page_title  = 'Hesap Ayarlari';
$active_menu = 'account';
require __DIR__ . '/includes/header.php';
?>

<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= h($e) ?></div><?php endforeach; ?>
<?php if ($success): ?><div class="alert alert-success"><?= h($success) ?></div><?php endif; ?>

<div class="card" style="max-width:520px;">
  <h2 class="h6 mb-2">Profil Bilgileri</h2>
  <form method="post">
    <?= generateCsrfField() ?>
    <div class="form-group"><label>Kullanici Adi</label><input type="text" class="form-control" value="<?= h($user['username']) ?>" disabled></div>
    <div class="form-group"><label>Ad Soyad</label><input type="text" name="full_name" class="form-control" value="<?= h($user['full_name']) ?>" required></div>
    <div class="form-group"><label>E-posta</label><input type="email" name="email" class="form-control" value="<?= h($user['email']) ?>"></div>

    <hr style="border:none;border-top:1px solid var(--a-fog);margin:1.4rem 0;">
    <h2 class="h6 mb-2">Sifre Degistir <small style="font-weight:400;color:var(--a-gray)">(opsiyonel)</small></h2>
    <div class="form-group"><label>Mevcut Sifre</label><input type="password" name="current_password" class="form-control"></div>
    <div class="form-group"><label>Yeni Sifre</label><input type="password" name="new_password" class="form-control"></div>
    <div class="form-group"><label>Yeni Sifre (Tekrar)</label><input type="password" name="new_password_confirm" class="form-control"></div>

    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Kaydet</button>
  </form>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>

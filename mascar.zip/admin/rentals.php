<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/../includes/availability.php';
admin_require_login();
$pdo = db();

$errors = [];
$prefill = [
    'vehicle_id' => $_GET['vehicle_id'] ?? '', 'customer_name' => $_GET['customer_name'] ?? '',
    'customer_phone' => $_GET['customer_phone'] ?? '', 'start_date' => $_GET['start_date'] ?? '',
    'end_date' => $_GET['end_date'] ?? '',
];

// Yeni kiralama kaydi ekleme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_rental'])) {
    csrf_check();
    $vehicleId    = (int)$_POST['vehicle_id'];
    $customerName = trim($_POST['customer_name'] ?? '');
    $customerPhone= trim($_POST['customer_phone'] ?? '');
    $startDate    = $_POST['start_date'] ?? '';
    $endDate      = $_POST['end_date'] ?? '';
    $pickupTime   = $_POST['pickup_time'] ?? '';
    $returnTime   = $_POST['return_time'] ?? '';
    $dailyPrice   = (float)str_replace(',', '.', $_POST['daily_price'] ?? 0);

    $pickupTime = $pickupTime ? $pickupTime . ':00' : null;
    $returnTime = $returnTime ? $returnTime . ':00' : null;

    if (!$vehicleId || $customerName === '' || $customerPhone === '' || !$startDate || !$endDate) {
        $errors[] = 'Lutfen tum zorunlu alanlari doldurun.';
    } elseif (strtotime($endDate) < strtotime($startDate)) {
        $errors[] = 'Teslim tarihi, alis tarihinden once olamaz.';
    } else {
        // Cakisma kontrolu
        $busy = get_busy_ranges($pdo, $vehicleId, $startDate, $endDate);
        $conflict = find_conflict($busy, $startDate, $endDate);
        if ($conflict) {
            $errors[] = sprintf(
                'Bu arac icin %s – %s tarihleri arasinda zaten onaylanmis bir kiralama/randevu bulunuyor. Lutfen farkli bir tarih secin.',
                date('d.m.Y', strtotime($conflict['start'])), date('d.m.Y', strtotime($conflict['end']))
            );
        }
    }

    if (!$errors) {
        $days = max(1, (strtotime($endDate) - strtotime($startDate)) / 86400);
        $total = round($days * $dailyPrice, 2);

        $pdo->prepare("INSERT INTO rentals (vehicle_id, customer_name, customer_phone, start_date, end_date, pickup_time, return_time, daily_price, total_price, status)
                        VALUES (?,?,?,?,?,?,?,?,?, 'aktif')")
            ->execute([$vehicleId, $customerName, $customerPhone, $startDate, $endDate, $pickupTime, $returnTime, $dailyPrice, $total]);
        $pdo->prepare("UPDATE vehicles SET status = 'kirada' WHERE id = ?")->execute([$vehicleId]);
        log_activity("Yeni kiralama eklendi: $customerName (Arac ID: $vehicleId)");
        $_SESSION['flash_success'] = 'Kiralama kaydi olusturuldu ve arac durumu "Kirada" olarak guncellendi.';
        header('Location: rentals.php');
        exit;
    }
}

// Durum guncelleme (tamamlandi / iptal → araci tekrar musait yap)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    csrf_check();
    $id = (int)$_POST['id'];
    $status = $_POST['status'];
    if (in_array($status, ['rezervasyon','aktif','tamamlandi','iptal'], true)) {
        $stmt = $pdo->prepare('SELECT vehicle_id FROM rentals WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        $pdo->prepare('UPDATE rentals SET status = ? WHERE id = ?')->execute([$status, $id]);
        if ($row) {
            if (in_array($status, ['tamamlandi','iptal'], true)) {
                $pdo->prepare("UPDATE vehicles SET status = 'musait' WHERE id = ?")->execute([$row['vehicle_id']]);
            } elseif ($status === 'aktif') {
                $pdo->prepare("UPDATE vehicles SET status = 'kirada' WHERE id = ?")->execute([$row['vehicle_id']]);
            }
        }
        log_activity("Kiralama durumu guncellendi (ID: $id -> $status)");
        $_SESSION['flash_success'] = 'Kiralama durumu guncellendi.';
    }
    header('Location: rentals.php');
    exit;
}

$statusFilter = $_GET['status'] ?? 'all';
$sql = "SELECT r.*, v.brand, v.model, v.main_image FROM rentals r JOIN vehicles v ON v.id = r.vehicle_id WHERE 1=1";
$params = [];
if ($statusFilter !== 'all') { $sql .= " AND r.status = ?"; $params[] = $statusFilter; }
$sql .= " ORDER BY r.start_date DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rentals = $stmt->fetchAll();

$availableVehicles = $pdo->query("SELECT * FROM vehicles WHERE status IN ('musait','kirada') ORDER BY brand, model")->fetchAll();

$statusBadge = ['rezervasyon'=>'badge-blue','aktif'=>'badge-amber','tamamlandi'=>'badge-green','iptal'=>'badge-red'];
$statusLabel = ['rezervasyon'=>'Rezervasyon','aktif'=>'Aktif Kirada','tamamlandi'=>'Tamamlandi','iptal'=>'Iptal'];

$page_title  = 'Kiralama Takibi';
$active_menu = 'rentals';
require __DIR__ . '/includes/header.php';
?>

<?php if (!empty($_SESSION['flash_success'])): ?>
  <div class="alert alert-success"><?= h($_SESSION['flash_success']) ?></div>
  <?php unset($_SESSION['flash_success']); ?>
<?php endif; ?>
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?= h($err) ?></div><?php endforeach; ?>

<div class="card" id="top">
  <div class="card-title"><h2 class="h6 mb-0">Yeni Kiralama Kaydi Olustur</h2></div>
  <form method="post" class="form-grid">
    <?= generateCsrfField() ?>
    <div class="form-group">
      <label>Arac *</label>
      <select name="vehicle_id" id="rentalVehicleSelect" class="form-control" required onchange="document.getElementById('dailyPriceInput').value = this.options[this.selectedIndex].dataset.price || ''; checkAdminAvailability();">
        <option value="">Seciniz</option>
        <?php foreach ($availableVehicles as $v): ?>
          <option value="<?= (int)$v['id'] ?>" data-price="<?= h((string)$v['daily_price']) ?>" <?= (string)$prefill['vehicle_id'] === (string)$v['id'] ? 'selected' : '' ?>><?= h($v['brand'].' '.$v['model'].' ('.$v['year'].')') ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group"><label>Musteri Adi Soyadi *</label><input type="text" name="customer_name" class="form-control" value="<?= h($prefill['customer_name']) ?>" required></div>
    <div class="form-group"><label>Musteri Telefonu *</label><input type="tel" name="customer_phone" class="form-control" value="<?= h($prefill['customer_phone']) ?>" required></div>
    <div class="form-group"><label>Alis Tarihi *</label><input type="date" name="start_date" id="rentalStartDate" class="form-control" value="<?= h($prefill['start_date']) ?>" onchange="checkAdminAvailability()" required></div>
    <div class="form-group"><label>Alis Saati</label><input type="time" name="pickup_time" class="form-control" value="10:00"></div>
    <div class="form-group"><label>Teslim Tarihi *</label><input type="date" name="end_date" id="rentalEndDate" class="form-control" value="<?= h($prefill['end_date']) ?>" onchange="checkAdminAvailability()" required></div>
    <div class="form-group"><label>Teslim Saati</label><input type="time" name="return_time" class="form-control" value="10:00"></div>
    <div class="form-group"><label>Gunluk Fiyat (₺) *</label><input type="text" id="dailyPriceInput" name="daily_price" class="form-control" required></div>
    <div class="form-group" style="align-self:flex-end;"><button type="submit" name="add_rental" value="1" class="btn btn-primary btn-block"><i class="bi bi-plus-lg"></i> Kiralama Ekle</button></div>
    <div class="form-group" style="grid-column:1/-1;" id="adminAvailabilityPanel"></div>
  </form>
  <script>
    async function checkAdminAvailability() {
      const vId = document.getElementById('rentalVehicleSelect').value;
      const start = document.getElementById('rentalStartDate').value;
      const end = document.getElementById('rentalEndDate').value;
      const panel = document.getElementById('adminAvailabilityPanel');
      if (!vId || !start || !end) { panel.innerHTML = ''; return; }
      panel.innerHTML = '<div style="font-size:.85rem;color:var(--a-gray)">Kontrol ediliyor...</div>';
      try {
        const res = await fetch(`../check-availability.php?vehicle_id=${vId}&start=${start}&end=${end}`);
        const data = await res.json();
        if (data.requested && !data.requested.available) {
          const c = data.requested.conflict;
          panel.innerHTML = `<div class="alert alert-error" style="margin:0;">
            <i class="bi bi-exclamation-triangle-fill me-1"></i>Bu arac icin ${c.start.split('-').reverse().join('.')} – ${c.end.split('-').reverse().join('.')}
            tarihleri arasinda zaten onayli bir kiralama var. Farkli bir tarih secin.
          </div>`;
        } else if (data.requested) {
          panel.innerHTML = '<div class="alert alert-success" style="margin:0;"><i class="bi bi-check-circle-fill me-1"></i>Bu tarih araliginda arac musait.</div>';
        }
      } catch (e) { panel.innerHTML = ''; }
    }
    document.addEventListener('DOMContentLoaded', checkAdminAvailability);
  </script>
</div>

<div class="card">
  <form method="get" class="filters">
    <select name="status" onchange="this.form.submit()">
      <option value="all" <?= $statusFilter==='all'?'selected':'' ?>>Tum Durumlar</option>
      <option value="rezervasyon" <?= $statusFilter==='rezervasyon'?'selected':'' ?>>Rezervasyon</option>
      <option value="aktif" <?= $statusFilter==='aktif'?'selected':'' ?>>Aktif Kirada</option>
      <option value="tamamlandi" <?= $statusFilter==='tamamlandi'?'selected':'' ?>>Tamamlandi</option>
      <option value="iptal" <?= $statusFilter==='iptal'?'selected':'' ?>>Iptal</option>
    </select>
  </form>

  <?php if (!$rentals): ?>
    <div class="empty-state"><i class="bi bi-clipboard-x"></i>Kayitli kiralama bulunamadi.</div>
  <?php else: ?>
  <!-- Desktop: Table -->
  <div class="table-wrap desktop-only">
    <table class="admin-table">
      <thead><tr><th>Arac</th><th>Musteri</th><th>Tarih Araligi</th><th>Gunluk</th><th>Toplam</th><th>Durum</th></tr></thead>
      <tbody>
      <?php foreach ($rentals as $r):
        $days = max(1, round((strtotime($r['end_date']) - strtotime($r['start_date'])) / 86400)); ?>
        <tr>
          <td><img class="thumb" src="<?= $r['main_image'] ? '../uploads/' . h($r['main_image']) : 'https://placehold.co/80x56?text=Foto' ?>" alt=""> <?= h($r['brand'].' '.$r['model']) ?></td>
          <td><?= h($r['customer_name']) ?><br><span style="color:var(--a-gray);font-size:.78rem"><a href="tel:<?= h($r['customer_phone']) ?>"><?= h($r['customer_phone']) ?></a></span></td>
          <td><?= date('d.m.Y', strtotime($r['start_date'])) ?><?= $r['pickup_time'] ? ' ' . substr($r['pickup_time'],0,5) : '' ?> – <?= date('d.m.Y', strtotime($r['end_date'])) ?><?= $r['return_time'] ? ' ' . substr($r['return_time'],0,5) : '' ?><br><span style="color:var(--a-gray);font-size:.78rem"><?= $days ?> gun</span></td>
          <td><?= number_format((float)$r['daily_price'], 0, ',', '.') ?> ₺</td>
          <td><strong><?= number_format((float)$r['total_price'], 0, ',', '.') ?> ₺</strong></td>
          <td>
            <form method="post" style="display:flex;gap:.4rem;align-items:center;">
              <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <select name="status" class="form-control" style="padding:.3rem .5rem;font-size:.78rem;" onchange="this.form.submit()">
                <?php foreach ($statusLabel as $k=>$l): ?>
                  <option value="<?= $k ?>" <?= $r['status']===$k?'selected':'' ?>><?= $l ?></option>
                <?php endforeach; ?>
              </select>
              <input type="hidden" name="update_status" value="1">
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <!-- Mobile: iOS List -->
  <div class="ios-list mobile-only">
    <?php foreach ($rentals as $r):
      $days = max(1, round((strtotime($r['end_date']) - strtotime($r['start_date'])) / 86400)); ?>
      <div class="ios-list-item">
        <img class="thumb" src="<?= $r['main_image'] ? '../uploads/' . h($r['main_image']) : 'https://placehold.co/80x56?text=Foto' ?>" alt="" style="width:56px;height:56px;border-radius:12px;">
        <div class="item-body">
          <div class="item-title"><?= h($r['customer_name']) ?></div>
          <div class="item-sub"><?= h($r['brand'].' '.$r['model']) ?> · <?= date('d.m.Y', strtotime($r['start_date'])) ?></div>
          <div class="item-sub"><?= $days ?> gun · <strong><?= number_format((float)$r['total_price'], 0, ',', '.') ?> ₺</strong></div>
        </div>
        <div class="item-action">
          <form method="post" style="display:flex;gap:.4rem;align-items:center;">
            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <select name="status" class="form-control" style="padding:.3rem .5rem;font-size:.78rem;" onchange="this.form.submit()">
              <?php foreach ($statusLabel as $k=>$l): ?>
                <option value="<?= $k ?>" <?= $r['status']===$k?'selected':'' ?>><?= $l ?></option>
              <?php endforeach; ?>
            </select>
            <input type="hidden" name="update_status" value="1">
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>

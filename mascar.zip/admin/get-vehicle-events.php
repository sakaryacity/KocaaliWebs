<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();

header('Content-Type: application/json');

$vehicleId = isset($_GET['vehicle_id']) ? (int)$_GET['vehicle_id'] : 0;
$events = [];

if ($vehicleId > 0) {
    $pdo = db();

    $stmt = $pdo->prepare("SELECT customer_name, start_date, end_date, status FROM rentals WHERE vehicle_id = ?");
    $stmt->execute([$vehicleId]);
    $rentals = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rentals as $res) {
        $color = '';
        $title = '';

        if ($res['status'] === 'aktif') {
            $color = '#ef4444';
            $title = 'Kirada: ' . h($res['customer_name']);
        } elseif (in_array($res['status'], ['rezervasyon', 'beklemede', 'onaylandi'])) {
            $color = '#3b82f6';
            $title = 'Rezerve: ' . h($res['customer_name']);
        } else {
            continue;
        }

        $events[] = [
            'title' => $title,
            'start' => $res['start_date'],
            'end'   => $res['end_date'],
            'color' => $color,
            'allDay'=> true
        ];
    }
}

echo json_encode($events);
exit;

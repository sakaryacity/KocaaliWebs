<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    csrf_check();
    $id = (int)$_POST['id'];
    $status = $_POST['status'];
    if (in_array($status, ['beklemede','onaylandi','tamamlandi','iptal'], true)) {
        $pdo->prepare('UPDATE appointments SET status = ? WHERE id = ?')->execute([$status, $id]);
        log_activity("Randevu durumu guncellendi (ID: $id -> $status)");
        $_SESSION['flash_success'] = 'Randevu durumu guncellendi.';
    }
    header('Location: appointments.php' . (isset($_GET['status']) ? '?status=' . urlencode($_GET['status']) : ''));
    exit;
}

if (isset($_GET['delete']) && ctype_digit($_GET['delete'])) {
    $pdo->prepare('DELETE FROM appointments WHERE id = ?')->execute([(int)$_GET['delete']]);
    $_SESSION['flash_success'] = 'Randevu kaydi silindi.';
    header('Location: appointments.php');
    exit;
}

$statusFilter = $_GET['status'] ?? 'all';
$sql = "SELECT * FROM appointments WHERE 1=1";
$params = [];
if ($statusFilter !== 'all') { $sql .= " AND status = ?"; $params[] = $statusFilter; }
$sql .= " ORDER BY appointment_date ASC, appointment_time ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$appointments = $stmt->fetchAll();

$statusBadge = ['beklemede'=>'badge-amber','onaylandi'=>'badge-blue','tamamlandi'=>'badge-green','iptal'=>'badge-red'];
$statusLabel = ['beklemede'=>'Beklemede','onaylandi'=>'Onaylandi','tamamlandi'=>'Tamamlandi','iptal'=>'Iptal'];

$page_title  = 'Servis Randevulari';
$active_menu = 'appointments';
require __DIR__ . '/includes/header.php';
?>

<?php if (!empty($_SESSION['flash_success'])): ?>
  <div class="alert alert-success"><?= h($_SESSION['flash_success']) ?></div>
  <?php unset($_SESSION['flash_success']); ?>
<?php endif; ?>

<div class="card">
  <form method="get" class="filters">
    <select name="status" onchange="this.form.submit()">
      <option value="all" <?= $statusFilter==='all'?'selected':'' ?>>Tum Durumlar</option>
      <option value="beklemede" <?= $statusFilter==='beklemede'?'selected':'' ?>>Beklemede</option>
      <option value="onaylandi" <?= $statusFilter==='onaylandi'?'selected':'' ?>>Onaylandi</option>
      <option value="tamamlandi" <?= $statusFilter==='tamamlandi'?'selected':'' ?>>Tamamlandi</option>
      <option value="iptal" <?= $statusFilter==='iptal'?'selected':'' ?>>Iptal</option>
    </select>
  </form>

  <?php if (!$appointments): ?>
    <div class="empty-state"><i class="bi bi-calendar-x"></i>Kayitli randevu bulunamadi.</div>
  <?php else: ?>
  <!-- Desktop: Table -->
  <div class="table-wrap desktop-only">
    <table class="admin-table">
      <thead><tr><th>Musteri</th><th>Arac</th><th>Hizmet</th><th>Tarih / Saat</th><th>Not</th><th>Durum</th><th>Islemler</th></tr></thead>
      <tbody>
      <?php foreach ($appointments as $a): ?>
        <tr>
          <td><?= h($a['full_name']) ?><br><span style="color:var(--a-gray);font-size:.78rem"><a href="tel:<?= h($a['phone']) ?>"><?= h($a['phone']) ?></a></span></td>
          <td><?= h($a['vehicle_info'] ?: '—') ?></td>
          <td><?= h($a['service_type']) ?></td>
          <td><?= date('d.m.Y', strtotime($a['appointment_date'])) ?><br><span style="color:var(--a-gray);font-size:.78rem"><?= substr($a['appointment_time'],0,5) ?></span></td>
          <td style="max-width:220px;white-space:normal;"><?= h($a['message'] ?: '—') ?></td>
          <td>
            <form method="post" style="display:flex;gap:.4rem;align-items:center;">
              <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
              <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
              <select name="status" class="form-control" style="padding:.3rem .5rem;font-size:.78rem;" onchange="this.form.submit()">
                <?php foreach ($statusLabel as $k=>$l): ?>
                  <option value="<?= $k ?>" <?= $a['status']===$k?'selected':'' ?>><?= $l ?></option>
                <?php endforeach; ?>
              </select>
              <input type="hidden" name="update_status" value="1">
            </form>
          </td>
          <td><a href="appointments.php?delete=<?= (int)$a['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bu randevu kaydini silmek istiyor musunuz?')"><i class="bi bi-trash3-fill"></i></a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <!-- Mobile: iOS List -->
  <div class="ios-list mobile-only">
    <?php foreach ($appointments as $a): ?>
      <div class="ios-list-item">
        <div class="item-icon" style="background:var(--a-amber-light);color:var(--a-amber);"><i class="bi bi-calendar-check-fill"></i></div>
        <div class="item-body">
          <div class="item-title"><?= h($a['full_name']) ?></div>
          <div class="item-sub"><?= h($a['service_type']) ?> · <?= date('d.m.Y', strtotime($a['appointment_date'])) ?></div>
          <?php if ($a['message']): ?>
            <div class="item-sub"><?= h(mb_substr($a['message'], 0, 60)) ?></div>
          <?php endif; ?>
        </div>
        <div class="item-action" style="display:flex;flex-direction:column;gap:6px;">
          <span class="badge <?= $statusBadge[$a['status']] ?? 'badge-amber' ?>"><?= $statusLabel[$a['status']] ?? $a['status'] ?></span>
          <div style="display:flex;gap:6px;">
            <form method="post" style="display:flex;gap:.2rem;">
              <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
              <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
              <select name="status" style="padding:.2rem .3rem;font-size:.72rem;border:1px solid var(--a-fog);border-radius:8px;" onchange="this.form.submit()">
                <?php foreach ($statusLabel as $k=>$l): ?>
                  <option value="<?= $k ?>" <?= $a['status']===$k?'selected':'' ?>><?= $l ?></option>
                <?php endforeach; ?>
              </select>
              <input type="hidden" name="update_status" value="1">
            </form>
            <a href="appointments.php?delete=<?= (int)$a['id'] ?>" class="btn btn-danger btn-sm" style="padding:4px 8px;" onclick="return confirm('Silinsin mi?')"><i class="bi bi-trash3-fill"></i></a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>

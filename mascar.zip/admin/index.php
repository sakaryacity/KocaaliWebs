<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();

$pdo = db();

// ==========================================
// AKILLI OTOMASYON SISTEMI
// ==========================================
// 1. Baslangic tarihi bugun veya gecmis olan "Rezervasyon"lari (Mavi), "Aktif Kirada"ya (Kirmizi) cevirir.
$pdo->exec("UPDATE rentals SET status = 'aktif' WHERE status = 'rezervasyon' AND start_date <= CURDATE()");

// 2. Aktif kirada olan araclarin ana durumunu 'kirada' olarak guncelleyerek sistemi senkronize eder.
$pdo->exec("UPDATE vehicles SET status = 'kirada' WHERE id IN (SELECT vehicle_id FROM rentals WHERE status = 'aktif' AND end_date >= CURDATE())");
// ==========================================

$totalVehicles   = (int)$pdo->query("SELECT COUNT(*) c FROM vehicles")->fetch()['c'];
$availableCount  = (int)$pdo->query("SELECT COUNT(*) c FROM vehicles WHERE status='musait'")->fetch()['c'];
$rentedCount     = (int)$pdo->query("SELECT COUNT(*) c FROM vehicles WHERE status='kirada'")->fetch()['c'];
$pendingAppts    = (int)$pdo->query("SELECT COUNT(*) c FROM appointments WHERE status='beklemede'")->fetch()['c'];
$activeRentals   = (int)$pdo->query("SELECT COUNT(*) c FROM rentals WHERE status='aktif'")->fetch()['c'];
$unreadMessages  = (int)$pdo->query("SELECT COUNT(*) c FROM contact_messages WHERE is_read=0")->fetch()['c'];
$newReservations = (int)$pdo->query("SELECT COUNT(*) c FROM reservation_requests WHERE status='yeni'")->fetch()['c'];

$monthIncome = (float)$pdo->query(
    "SELECT COALESCE(SUM(total_price),0) s FROM rentals
     WHERE status IN ('tamamlandi','aktif') AND MONTH(start_date)=MONTH(CURDATE()) AND YEAR(start_date)=YEAR(CURDATE())"
)->fetch()['s'];

$recentAppointments = $pdo->query(
    "SELECT * FROM appointments ORDER BY created_at DESC LIMIT 5"
)->fetchAll();

$recentRentals = $pdo->query(
    "SELECT r.*, v.brand, v.model FROM rentals r
     JOIN vehicles v ON v.id = r.vehicle_id
     ORDER BY r.created_at DESC LIMIT 5"
)->fetchAll();

$fleetVehicles = $pdo->query(
    "SELECT * FROM vehicles ORDER BY id ASC"
)->fetchAll();

$statusBadge = [
    'beklemede'   => 'badge-amber',  'onaylandi' => 'badge-blue', 'tamamlandi' => 'badge-green', 'iptal' => 'badge-red',
    'rezervasyon' => 'badge-blue',   'aktif'     => 'badge-red', 'musait' => 'badge-green', 'kirada' => 'badge-red',
];
$statusLabel = [
    'beklemede' => 'Beklemede', 'onaylandi' => 'Onaylandi', 'tamamlandi' => 'Tamamlandi', 'iptal' => 'Iptal',
    'rezervasyon' => 'Rezervasyon', 'aktif' => 'Aktif Kirada', 'musait' => 'Su An Musait', 'kirada' => 'Aktif Kirada',
];

$page_title  = 'Genel Bakis';
$active_menu = 'dashboard';
require __DIR__ . '/includes/header.php';
?>

<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-icon" style="background:var(--a-red)"><i class="bi bi-car-front-fill"></i></div>
    <div class="stat-value"><?= $totalVehicles ?></div>
    <div class="stat-label">Toplam Arac · <?= $availableCount ?> musait</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:var(--a-amber)"><i class="bi bi-clipboard-check-fill"></i></div>
    <div class="stat-value"><?= $activeRentals ?></div>
    <div class="stat-label">Aktif Kiralama (<?= $rentedCount ?> arac kirada)</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:var(--a-blue)"><i class="bi bi-calendar-check-fill"></i></div>
    <div class="stat-value"><?= $pendingAppts ?></div>
    <div class="stat-label">Bekleyen Servis Randevusu</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:var(--a-green)"><i class="bi bi-cash-coin"></i></div>
    <div class="stat-value"><?= number_format($monthIncome, 0, ',', '.') ?> ₺</div>
    <div class="stat-label">Bu Ayki Gelir</div>
  </div>
</div>

<?php if ($newReservations > 0): ?>
<div class="alert alert-warning">
  <i class="bi bi-inbox-fill me-1"></i><?= $newReservations ?> adet yeni rezervasyon talebiniz var.
  <a href="reservations.php" style="font-weight:600;">Goruntule →</a>
</div>
<?php endif; ?>

<?php if ($unreadMessages > 0): ?>
<div class="alert alert-info">
  <i class="bi bi-envelope-fill me-1"></i><?= $unreadMessages ?> adet okunmamis iletisim mesajiniz var.
  <a href="messages.php" style="font-weight:600;">Goruntule →</a>
</div>
<?php endif; ?>

<!-- FILO TAKIP TABLOSU -->
<div class="card">
    <div class="card-title">
        <h2 class="h6 mb-0"><i class="bi bi-car-front-fill me-2"></i> Arac Filo Takip Durumu</h2>
    </div>
    <div class="table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Arac Modeli</th>
                    <th>Mevcut Durum</th>
                    <th>Bilgi</th>
                    <th style="text-align: right;">Takvim Islemi</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!$fleetVehicles): ?>
                    <tr><td colspan="4" class="text-center text-muted">Sistemde kayitli arac bulunamadi.</td></tr>
                <?php else: ?>
                    <?php foreach ($fleetVehicles as $v):
                        $icon = $v['status'] == 'musait' ? 'bi-check-circle-fill' : ($v['status'] == 'kirada' ? 'bi-key-fill' : 'bi-info-circle-fill');
                        $badgeClass = $statusBadge[$v['status']] ?? 'badge-amber';
                        $labelText  = $statusLabel[$v['status']] ?? ucfirst($v['status']);
                    ?>
                    <tr style="cursor:pointer;" onclick="openVehicleCalendar(<?= (int)$v['id'] ?>)">
                        <td style="font-weight:600;font-size:0.95rem;">
                            <?= h($v['brand'] . ' ' . $v['model']) ?>
                            <?php if(!empty($v['plate'])): ?>
                                <span style="font-size:0.8rem;color:var(--a-gray);font-weight:normal;">(<?= h($v['plate']) ?>)</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge <?= $badgeClass ?>" style="padding:6px 14px;border-radius:50px;font-weight:500;">
                                <i class="bi <?= $icon ?> me-1"></i> <?= $labelText ?>
                            </span>
                        </td>
                        <td style="color:var(--a-gray);font-size:0.9rem;">
                            <i class="bi bi-clock-history me-1"></i> Detayli musaitlik icin takvime tiklayin
                        </td>
                        <td style="text-align:right;">
                            <button type="button" class="btn btn-outline btn-sm" onclick="openVehicleCalendar(<?= (int)$v['id'] ?>)">
                                <i class="bi bi-calendar-week"></i> Takvimi Gor
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- YAN YANA IKILI DUGEN: Son Randevular + Son Kiralamalar -->
<div class="dual-grid mt-2">
  <!-- SOL: Son Servis Randevulari -->
  <div class="card">
    <div class="card-title">
      <h2 class="h6 mb-0">Son Servis Randevulari</h2>
      <a href="appointments.php" class="btn btn-outline btn-sm">Tumu</a>
    </div>
    <?php if (!$recentAppointments): ?>
      <div class="empty-state"><i class="bi bi-calendar-x"></i>Henüz randevu talebi yok.</div>
    <?php else: ?>
    <div class="ios-list">
      <?php foreach ($recentAppointments as $a): ?>
        <div class="ios-list-item">
          <div class="item-icon" style="background:var(--a-blue-light);color:var(--a-blue);"><i class="bi bi-calendar-check-fill"></i></div>
          <div class="item-body">
            <div class="item-title"><?= h($a['full_name']) ?></div>
            <div class="item-sub"><?= h($a['service_type']) ?> · <?= date('d.m.Y', strtotime($a['appointment_date'])) ?></div>
          </div>
          <div class="item-action">
            <span class="badge <?= $statusBadge[$a['status']] ?? 'badge-amber' ?>"><?= $statusLabel[$a['status']] ?? $a['status'] ?></span>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <!-- SAG: Son Kiralamalar -->
  <div class="card">
    <div class="card-title">
      <h2 class="h6 mb-0">Son Kiralamalar</h2>
      <a href="rentals.php" class="btn btn-outline btn-sm">Tumu</a>
    </div>
    <?php if (!$recentRentals): ?>
      <div class="empty-state"><i class="bi bi-car-front"></i>Henüz kiralama kaydi yok.</div>
    <?php else: ?>
    <div class="ios-list">
      <?php foreach ($recentRentals as $r): ?>
        <div class="ios-list-item">
          <div class="item-icon" style="background:var(--a-red-light);color:var(--a-red);"><i class="bi bi-car-front-fill"></i></div>
          <div class="item-body">
            <div class="item-title"><?= h($r['customer_name']) ?></div>
            <div class="item-sub"><?= h($r['brand'] . ' ' . $r['model']) ?> · <?= date('d.m.Y', strtotime($r['start_date'])) ?></div>
          </div>
          <div class="item-action">
            <span class="badge <?= $statusBadge[$r['status']] ?? 'badge-amber' ?>"><?= $statusLabel[$r['status']] ?? $r['status'] ?></span>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>

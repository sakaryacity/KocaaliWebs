<?php
 $page_title  = $page_title  ?? 'Yonetim Paneli';
 $active_menu = $active_menu ?? '';
 $user = admin_current_user();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<title><?= h($page_title) ?> | Yonetim</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<div class="sidebar-backdrop" id="sidebarBackdrop" onclick="toggleSidebar(false)"></div>
<aside class="admin-sidebar" id="adminSidebar">
  <div class="brand"><span class="mark">M</span> Mas-Car Auto</div>
  <nav class="admin-nav">
    <a href="index.php" class="<?= $active_menu==='dashboard'?'active':'' ?>"><i class="bi bi-grid-1x2-fill"></i> Ana Sayfa</a>
    <div class="nav-section">Araclar</div>
    <a href="vehicles.php" class="<?= $active_menu==='vehicles'?'active':'' ?>"><i class="bi bi-car-front-fill"></i> Araclar</a>
    <a href="rentals.php" class="<?= $active_menu==='rentals'?'active':'' ?>"><i class="bi bi-clipboard-check-fill"></i> Kiralama</a>
    <div class="nav-section">Islemler</div>
    <a href="appointments.php" class="<?= $active_menu==='appointments'?'active':'' ?>"><i class="bi bi-calendar-check-fill"></i> Randevular</a>
    <a href="reservations.php" class="<?= $active_menu==='reservations'?'active':'' ?>"><i class="bi bi-inbox-fill"></i> Rezervasyonlar</a>
    <a href="messages.php" class="<?= $active_menu==='messages'?'active':'' ?>"><i class="bi bi-envelope-fill"></i> Mesajlar</a>
    <div class="nav-section">Icerik</div>
    <a href="gallery.php" class="<?= $active_menu==='gallery'?'active':'' ?>"><i class="bi bi-images"></i> Galeri</a>
    <div class="nav-section">Diger</div>
    <a href="reports.php" class="<?= $active_menu==='reports'?'active':'' ?>"><i class="bi bi-graph-up-arrow"></i> Raporlar</a>
    <a href="account.php" class="<?= ($active_menu==='account'||$active_menu==='settings')?'active':'' ?>"><i class="bi bi-person-gear"></i> Ayarlar</a>
  </nav>
  <div class="sidebar-footer">
    <div class="user-name"><?= h($user['full_name'] ?? '') ?></div>
    <div style="font-size:.78rem;color:rgba(255,255,255,.5);margin-top:2px;"><a href="logout.php">Cikis Yap</a></div>
  </div>
</aside>
<div class="admin-shell">
<header class="admin-topbar">
  <div class="topbar-left">
    <button class="hamburger" onclick="toggleSidebar()" aria-label="Menu"><i class="bi bi-list"></i></button>
    <h1 class="h6 mb-0"><?= h($page_title) ?></h1>
  </div>
  <div class="topbar-right">
    <span class="badge badge-gray" style="font-size:.72rem;"><i class="bi bi-clock me-1"></i><?= date('d.m.Y') ?></span>
  </div>
</header>
<main class="admin-content">
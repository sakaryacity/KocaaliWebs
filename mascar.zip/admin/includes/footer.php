<?php
/* footer - Bottom tabs + Calendar modal */
 $active_menu = $active_menu ?? '';
 $tabs = [
  ['href'=>'index.php','icon'=>'<i class="bi bi-house-fill"></i>','label'=>'Ana Sayfa','key'=>'dashboard'],
  ['href'=>'vehicles.php','icon'=>'<i class="bi bi-car-front-fill"></i>','label'=>'Araclar','key'=>'vehicles'],
  ['href'=>'appointments.php','icon'=>'<i class="bi bi-calendar-check-fill"></i>','label'=>'Randevular','key'=>'appointments'],
  ['href'=>'gallery.php','icon'=>'<i class="bi bi-images"></i>','label'=>'Galeri','key'=>'gallery'],
  ['href'=>'account.php','icon'=>'<i class="bi bi-gear-fill"></i>','label'=>'Ayarlar','key'=>'settings'],
];
?>
  </main>

  <!-- Bottom Tab Bar (Mobile) -->
  <nav class="bottom-tabs" aria-label="Ana navigasyon">
    <?php foreach ($tabs as $t): ?>
    <a href="<?= $t['href'] ?>" class="<?= $active_menu===$t['key']?'active':'' ?>">
      <span class="tab-icon"><?= $t['icon'] ?></span>
      <span><?= $t['label'] ?></span>
    </a>
    <?php endforeach; ?>
  </nav>
</div><!-- /admin-shell -->

<!-- Sidebar Toggle Script -->
<script>
function toggleSidebar(force){
  var sb=document.getElementById('adminSidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var open=force!==undefined?force:!sb.classList.contains('is-open');
  sb.classList.toggle('is-open',open);
  bd.classList.toggle('active',open);
  document.body.style.overflow=open?'hidden':'';
}
</script>

<!-- Vehicle Calendar Modal -->
<div id="vehicleCalendarModal" class="custom-modal-overlay">
  <div class="custom-modal-box">
    <div class="custom-modal-header">
      <h5 id="modalVehicleName"><i class="bi bi-calendar3 me-2"></i> Arac Takvimi</h5>
      <button class="custom-modal-close" onclick="closeVehicleCalendar()" aria-label="Kapat">&times;</button>
    </div>
    <div class="custom-modal-body">
      <div id="availabilitySummary" class="custom-alert">Yukleniyor...</div>
      <div id="calendar"></div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js"></script>
<script>
let calendar = null;
let currentSelectedVehicleId = 0;

function closeVehicleCalendar(){
  document.getElementById('vehicleCalendarModal').classList.remove('active');
  document.body.style.overflow = '';
  if (calendar) { calendar.destroy(); calendar = null; }
}

function openVehicleCalendar(vehicleId){
  currentSelectedVehicleId = vehicleId;
  document.getElementById('vehicleCalendarModal').classList.add('active');
  document.body.style.overflow = 'hidden';
  document.getElementById('modalVehicleName').innerHTML = '<i class="bi bi-hourglass-split me-2"></i> Yukleniyor...';
  let sb = document.getElementById('availabilitySummary');
  sb.className = 'custom-alert';
  sb.style = '';
  sb.innerHTML = '<strong>Yukleniyor:</strong> Musaitlik bilgileri cekiliyor...';
  let el = document.getElementById('calendar');

  // Onceki calendar'i temizle
  if (calendar) { calendar.destroy(); calendar = null; }
  el.innerHTML = '';

  let today = new Date();
  let bugun = today.getFullYear() + '-' +
    String(today.getMonth()+1).padStart(2,'0') + '-' +
    String(today.getDate()).padStart(2,'0');

  calendar = new FullCalendar.Calendar(el, {
    initialView: 'dayGridMonth',
    locale: 'tr',
    height: 500,
    selectable: true,
    selectOverlap: false,
    validRange: { start: bugun },
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth'
    },
    buttonText: { today: 'Bugun', month: 'Ay' },
    events: function(info, successCallback, failureCallback) {
      fetch('get-vehicle-events.php?vehicle_id=' + vehicleId)
        .then(function(r) { return r.json(); })
        .then(function(data) {
          successCallback(data);
          document.getElementById('modalVehicleName').innerHTML =
            '<i class="bi bi-car-front me-2"></i> Arac Takvimi';
          if (data.length > 0) {
            sb.style.backgroundColor = '#eff6ff';
            sb.style.color = '#1e40af';
            sb.style.borderColor = '#bfdbfe';
            sb.innerHTML = '<strong>Bilgi:</strong> Bu araca ait <b>' + data.length +
              '</b> adet kayit var. Yeni randevu icin takvimden gunleri secin.';
          } else {
            sb.style.backgroundColor = '#f0fdf4';
            sb.style.color = '#166534';
            sb.style.borderColor = '#bbf7d0';
            sb.innerHTML = '<strong>Harika!</strong> Arac tamamen bos. Randevu eklemek icin gunleri secin.';
          }
        })
        .catch(failureCallback);
    },
    select: function(info) {
      let end = new Date(info.end);
      end.setDate(end.getDate() - 1);
      let sd = info.start.toLocaleDateString('tr-TR');
      let ed = end.toLocaleDateString('tr-TR');
      let sUrl = info.startStr;
      let eUrl = end.getFullYear() + '-' +
        String(end.getMonth()+1).padStart(2,'0') + '-' +
        String(end.getDate()).padStart(2,'0');
      let link = 'add-rental.php?vehicle_id=' + currentSelectedVehicleId +
        '&start=' + sUrl + '&end=' + eUrl;
      sb.style.backgroundColor = '#eef2ff';
      sb.style.color = '#3730a3';
      sb.style.borderColor = '#c7d2fe';
      sb.style.display = 'flex';
      sb.style.justifyContent = 'space-between';
      sb.style.alignItems = 'center';
      sb.innerHTML = '<div><strong>Secilen:</strong> ' + sd + ' - ' + ed + '</div>' +
        '<button onclick="window.location.href=\'' + link + '\'" ' +
        'style="border:none;border-radius:50px;font-weight:600;padding:8px 20px;' +
        'background:var(--a-red);color:#fff;cursor:pointer;font-size:.88rem;">' +
        '<i class="bi bi-calendar-plus" style="margin-right:4px;"></i> Randevu Ekle</button>';
    }
  });

  setTimeout(function() { calendar.render(); }, 200);
}
</script>
</body>
</html>
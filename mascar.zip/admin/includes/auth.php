<?php
require_once __DIR__ . '/../../config.php';

function admin_is_logged_in(): bool { return !empty($_SESSION['admin_id']); }
function admin_require_login(): void { if (!admin_is_logged_in()) { header('Location: login.php'); exit; } }
function admin_current_user(): ?array {
    if (!admin_is_logged_in()) return null;
    static $user = null;
    if ($user === null) { $stmt = db()->prepare('SELECT id, username, full_name, email, role FROM admin_users WHERE id = ?'); $stmt->execute([$_SESSION['admin_id']]); $user = $stmt->fetch() ?: null; }
    return $user;
}
function log_activity(string $action): void { try { $stmt = db()->prepare('INSERT INTO activity_log (admin_id, action) VALUES (?, ?)'); $stmt->execute([$_SESSION['admin_id'] ?? null, $action]); } catch (Throwable $e) {} }

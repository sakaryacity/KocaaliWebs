<?php
require_once __DIR__ . '/includes/auth.php';
if (admin_is_logged_in()) { header('Location: index.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = trim($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');
    if ($username === '' || $password === '') { $error = 'Lutfen kullanici adi ve sifrenizi girin.'; }
    else {
        $stmt = db()->prepare('SELECT * FROM admin_users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $account = $stmt->fetch();
        if ($account && password_verify($password, $account['password_hash'])) {
            session_regenerate_id(true); $_SESSION['admin_id'] = $account['id'];
            db()->prepare('UPDATE admin_users SET last_login_at = NOW() WHERE id = ?')->execute([$account['id']]);
            log_activity('Giris yapti'); header('Location: index.php'); exit;
        }
        $error = 'Kullanici adi veya sifre hatali.';
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<title>Giris Yap</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<div class="auth-page">
  <div class="auth-card">
    <div class="auth-brand"><span class="mark">M</span> <strong>Mas-Car Auto</strong></div>
    <h2 class="h5">Yonetici Girisi</h2>
    <p style="color:var(--a-gray);font-size:.88rem;margin-bottom:1.5rem;text-align:center;">Hesabiniza giris yapin</p>
    <?php if ($error): ?>
      <div class="alert alert-error"><i class="bi bi-exclamation-circle-fill"></i><?= h($error) ?></div>
    <?php endif; ?>
    <form method="post" novalidate>
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
      <div class="form-group">
        <label>Kullanici Adi</label>
        <input type="text" name="username" class="form-control" required autofocus>
      </div>
      <div class="form-group">
        <label>Sifre</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary btn-block" style="min-height:54px;font-size:1.05rem;border-radius:14px;"><i class="bi bi-box-arrow-in-right"></i> Giris Yap</button>
    </form>
  </div>
</div>
</body>
</html>

<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();
$pdo = db();

if (isset($_GET['read']) && ctype_digit($_GET['read'])) {
    $pdo->prepare('UPDATE contact_messages SET is_read = 1 WHERE id = ?')->execute([(int)$_GET['read']]);
    header('Location: messages.php');
    exit;
}
if (isset($_GET['delete']) && ctype_digit($_GET['delete'])) {
    $pdo->prepare('DELETE FROM contact_messages WHERE id = ?')->execute([(int)$_GET['delete']]);
    header('Location: messages.php');
    exit;
}

$messages = $pdo->query('SELECT * FROM contact_messages ORDER BY created_at DESC')->fetchAll();

$page_title  = 'Iletisim Mesajlari';
$active_menu = 'messages';
require __DIR__ . '/includes/header.php';
?>

<div class="card">
  <?php if (!$messages): ?>
    <div class="empty-state"><i class="bi bi-envelope"></i>Henüz mesaj yok.</div>
  <?php else: ?>
  <!-- Desktop: Table -->
  <div class="table-wrap desktop-only">
    <table class="admin-table">
      <thead><tr><th>Gonderen</th><th>Konu</th><th>Mesaj</th><th>Tarih</th><th>Durum</th><th>Islemler</th></tr></thead>
      <tbody>
      <?php foreach ($messages as $m): ?>
        <tr style="<?= $m['is_read'] ? '' : 'background:#fff7ed;' ?>">
          <td><?= h($m['full_name']) ?><br><span style="color:var(--a-gray);font-size:.78rem"><?= h($m['phone'] ?: $m['email']) ?></span></td>
          <td><?= h($m['subject'] ?: '—') ?></td>
          <td style="max-width:280px;white-space:normal;"><?= h($m['message']) ?></td>
          <td><?= date('d.m.Y H:i', strtotime($m['created_at'])) ?></td>
          <td><span class="badge <?= $m['is_read'] ? 'badge-gray' : 'badge-amber' ?>"><?= $m['is_read'] ? 'Okundu' : 'Yeni' ?></span></td>
          <td>
            <?php if (!$m['is_read']): ?><a href="messages.php?read=<?= (int)$m['id'] ?>" class="btn btn-outline btn-sm">Okundu Isaretle</a><?php endif; ?>
            <a href="messages.php?delete=<?= (int)$m['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Silinsin mi?')"><i class="bi bi-trash3-fill"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <!-- Mobile: iOS List -->
  <div class="ios-list mobile-only">
    <?php foreach ($messages as $m): ?>
      <div class="ios-list-item" style="<?= $m['is_read'] ? '' : 'border-left:4px solid var(--a-amber);' ?>">
        <div class="item-icon" style="background:var(--a-blue-light);color:var(--a-blue);"><i class="bi bi-envelope-fill"></i></div>
        <div class="item-body">
          <div class="item-title"><?= h($m['full_name']) ?> <small style="color:var(--a-gray);"><?= date('d.m.Y H:i', strtotime($m['created_at'])) ?></small></div>
          <div class="item-sub"><?= h($m['subject'] ?: '—') ?></div>
          <div class="item-sub"><?= h(mb_substr($m['message'], 0, 80)) ?></div>
        </div>
        <div class="item-action" style="display:flex;flex-direction:column;gap:6px;">
          <span class="badge <?= $m['is_read'] ? 'badge-gray' : 'badge-amber' ?>"><?= $m['is_read'] ? 'Okundu' : 'Yeni' ?></span>
          <div style="display:flex;gap:6px;">
            <?php if (!$m['is_read']): ?>
              <a href="messages.php?read=<?= (int)$m['id'] ?>" class="btn btn-outline btn-sm" style="padding:4px 8px;">Oku</a>
            <?php endif; ?>
            <a href="messages.php?delete=<?= (int)$m['id'] ?>" class="btn btn-danger btn-sm" style="padding:4px 8px;" onclick="return confirm('Silinsin mi?')"><i class="bi bi-trash3-fill"></i></a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();

$pdo = db();

// Istatistikler
$total_categories = (int)$pdo->query("SELECT COUNT(*) as c FROM gallery_categories")->fetch()['c'];
$total_images = (int)$pdo->query("SELECT COUNT(*) as c FROM gallery_images")->fetch()['c'];
$active_images = (int)$pdo->query("SELECT COUNT(*) as c FROM gallery_images WHERE is_active = 1")->fetch()['c'];

// Kategorileri getir
$stmt = $pdo->query("SELECT gc.*, (SELECT COUNT(*) FROM gallery_images WHERE category_id = gc.id) as image_count,
    (SELECT gi.image_path FROM gallery_images gi WHERE gi.category_id = gc.id ORDER BY gi.display_order ASC, gi.created_at DESC LIMIT 1) as first_image
    FROM gallery_categories gc ORDER BY gc.display_order ASC");
$categories = $stmt->fetchAll();

// Son eklenen resimler
$recent_images = $pdo->query(
    "SELECT gi.*, gc.name as category_name FROM gallery_images gi JOIN gallery_categories gc ON gi.category_id = gc.id ORDER BY gi.created_at DESC LIMIT 8"
)->fetchAll();

$page_title = 'Galeri Yonetimi';
$active_menu = 'gallery';
require __DIR__ . '/includes/header.php';
?>

<!-- Istatistikler -->
<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-icon" style="background:var(--a-red)"><i class="bi bi-folder-fill"></i></div>
    <div class="stat-value"><?= $total_categories ?></div>
    <div class="stat-label">Toplam Kategori</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:var(--a-blue)"><i class="bi bi-image"></i></div>
    <div class="stat-value"><?= $total_images ?></div>
    <div class="stat-label">Toplam Resim</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:var(--a-green)"><i class="bi bi-check-circle"></i></div>
    <div class="stat-value"><?= $active_images ?></div>
    <div class="stat-label">Aktif Resim</div>
  </div>
</div>

<!-- Sayfa Baslik -->
<div class="page-header">
  <div>
    <p style="color:var(--a-gray);margin:0;">Galerini yonet, kategorileri duzenle ve resimleri ekle</p>
  </div>
  <div style="display:flex;gap:.6rem;">
    <a href="gallery-categories.php" class="btn btn-outline"><i class="bi bi-folder"></i> Kategoriler</a>
    <a href="gallery-images.php" class="btn btn-primary"><i class="bi bi-image"></i> Resimleri Yonet</a>
  </div>
</div>

<!-- Kategoriler -->
<div class="card">
  <div class="card-title">
    <h2 class="h6 mb-0">Kategoriler</h2>
    <a href="gallery-categories.php" class="btn btn-outline btn-sm"><i class="bi bi-plus-lg"></i> Yeni Kategori</a>
  </div>
  <?php if (empty($categories)): ?>
    <div class="empty-state"><i class="bi bi-inbox"></i>Henüz kategori yoktur.</div>
  <?php else: ?>
  <div class="gallery-category-grid">
    <?php foreach ($categories as $cat): ?>
    <div class="gallery-category-card">
      <?php if ($cat['first_image']): ?>
        <img class="cat-thumb" src="../uploads/<?= h($cat['first_image']) ?>" alt="<?= h($cat['name']) ?>">
      <?php else: ?>
        <div class="cat-thumb" style="display:flex;align-items:center;justify-content:center;background:var(--a-fog);"><i class="bi bi-folder-fill" style="font-size:2rem;color:var(--a-gray-light);"></i></div>
      <?php endif; ?>
      <div class="cat-info">
        <div class="cat-name"><?= h($cat['name']) ?></div>
        <div class="cat-count"><?= $cat['image_count'] ?> resim</div>
        <div style="margin-top:.6rem;display:flex;gap:.4rem;">
          <a href="gallery-images.php?category=<?= (int)$cat['id'] ?>" class="btn btn-outline btn-sm" style="flex:1;"><i class="bi bi-image"></i> Resimler</a>
          <a href="gallery-categories.php" class="btn btn-outline btn-sm"><i class="bi bi-pencil"></i></a>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- Son Eklenen Resimler -->
<div class="card">
  <div class="card-title">
    <h2 class="h6 mb-0">Son Eklenen Resimler</h2>
    <a href="gallery-images.php" class="btn btn-outline btn-sm">Tumu</a>
  </div>
  <?php if (empty($recent_images)): ?>
    <div class="empty-state"><i class="bi bi-image"></i>Henüz resim yoktur.</div>
  <?php else: ?>
  <div class="gallery-image-grid">
    <?php foreach ($recent_images as $img): ?>
    <a href="gallery-images.php?category=<?= (int)$img['category_id'] ?>" style="text-decoration:none;color:inherit;">
      <div class="gallery-image-item">
        <img src="../uploads/<?= h($img['image_path']) ?>" alt="<?= h($img['alt_text']) ?>" loading="lazy">
        <div class="img-overlay show">
          <div style="text-align:center;color:#fff;">
            <div style="font-size:.8rem;font-weight:600;"><i class="bi bi-folder"></i> <?= h($img['category_name']) ?></div>
            <div style="font-size:.7rem;margin-top:.3rem;"><?= round($img['file_size'] / 1024) ?>KB</div>
          </div>
        </div>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>

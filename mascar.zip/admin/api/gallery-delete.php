<?php
/**
 * Galeri gorsel silme AJAX endpoint'i.
 * PDO prepared statements, CSRF (validateCsrfAjax).
 */
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../config.php';

// CSRF kontrolu (AJAX)
if (!validateCsrfAjax()) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Gecersiz istek (CSRF dogrulamasi basarisiz).']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Sadece POST istegi kabul edilir.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$image_id = (int)($input['image_id'] ?? 0);

if (!$image_id) {
    echo json_encode(['success' => false, 'message' => 'Resim ID\'si eksik.']);
    exit;
}

$pdo = db();

// Gorsel bilgilerini getir (PDO prepared)
$stmt = $pdo->prepare('SELECT * FROM gallery_images WHERE id = ?');
$stmt->execute([$image_id]);
$image = $stmt->fetch();

if (!$image) {
    echo json_encode(['success' => false, 'message' => 'Resim bulunamadi.']);
    exit;
}

// Disk dosyalarini sil
$upload_dir = __DIR__ . '/../../uploads/';
$files_to_delete = [
    $upload_dir . basename($image['image_path']),
    $upload_dir . basename($image['webp_path']),
    $upload_dir . basename($image['thumbnail_path']),
];

foreach ($files_to_delete as $file) {
    if (file_exists($file)) {
        @unlink($file);
    }
}

// Veritabanindan sil (PDO prepared)
$stmt = $pdo->prepare('DELETE FROM gallery_images WHERE id = ?');
$stmt->execute([$image_id]);

echo json_encode([
    'success' => true,
    'message' => 'Resim basariyla silindi.'
]);

<?php
/**
 * Galeri kategori siralama AJAX endpoint'i.
 * PDO prepared statements, CSRF (validateCsrfAjax).
 */
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../config.php';

// CSRF kontrolu (AJAX)
if (!validateCsrfAjax()) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Gecersiz istek (CSRF dogrulamasi basarisiz).']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Sadece POST istegi kabul edilir.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$category_id = (int)($input['category_id'] ?? 0);
$order = (int)($input['order'] ?? 0);

if (!$category_id) {
    echo json_encode(['success' => false, 'message' => 'Kategori ID\'si eksik.']);
    exit;
}

$pdo = db();

$stmt = $pdo->prepare('UPDATE gallery_categories SET display_order = ? WHERE id = ?');
$stmt->execute([$order, $category_id]);

echo json_encode([
    'success' => true,
    'message' => 'Sira guncellendi.'
]);

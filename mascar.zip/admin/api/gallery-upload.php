<?php
/**
 * Galeri gorsel yukleme AJAX endpoint'i.
 * Kullandigi: processImageUpload() (config.php), PDO prepared statements, CSRF.
 */
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../config.php';

// CSRF kontrolu — FormData (multipart) geldigi icin $_POST'dan oku
 $csrf_token = $_POST['csrf_token'] ?? '';
if (!hash_equals($_SESSION['csrf_token'] ?? '', $csrf_token)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Gecersiz istek (CSRF dogrulamasi basarisiz). Sayfayi yenileyip tekrar deneyin.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Sadece POST istegi kabul edilir.']);
    exit;
}

if (empty($_FILES['files']) || !isset($_POST['category_id'])) {
    echo json_encode(['success' => false, 'message' => 'Dosya veya kategori bilgisi eksik.']);
    exit;
}

 $category_id = (int)$_POST['category_id'];
 $pdo = db();

// Kategori kontrolu
 $stmt = $pdo->prepare('SELECT id FROM gallery_categories WHERE id = ?');
 $stmt->execute([$category_id]);
if (!$stmt->fetch()) {
    echo json_encode(['success' => false, 'message' => 'Kategori bulunamadi.']);
    exit;
}

 $files = $_FILES['files'];
 $uploaded_count = 0;
 $errors = [];
 $upload_dir = UPLOAD_DIR_GALLERY;

// Uploads dizini yoksa olustur
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

for ($i = 0; $i < count($files['name']); $i++) {
    try {
        $file_name = $files['name'][$i];
        $file_tmp  = $files['tmp_name'][$i];
        $file_size = $files['size'][$i];
        $file_error = $files['error'][$i];

        if ($file_error !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Dosya yukleme hatasi kodu: ' . $file_error);
        }

        if ($file_size > MAX_UPLOAD_SIZE) {
            throw new RuntimeException('Dosya boyutu 5 MB\'i asamaz.');
        }

        // processImageUpload ile WebP'ye cevir + sikistirma
        $result = processImageUpload($file_tmp, $upload_dir);

        $image_path     = 'gallery/' . $result['webp_path'];
        $thumbnail_path = 'gallery/' . $result['thumbnail_path'];
        $optimized_size = $result['file_size'];

        // Veritabanina kaydet
        $stmt = $pdo->prepare(
            "INSERT INTO gallery_images
             (category_id, image_name, image_path, webp_path, thumbnail_path, file_size, title, alt_text, display_order, is_active)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)"
        );
        $stmt->execute([
            $category_id,
            $file_name,
            $image_path,
            $image_path,
            $thumbnail_path,
            $optimized_size,
            '',
            '',
            $uploaded_count
        ]);

        $uploaded_count++;

    } catch (Throwable $e) {
        $errors[] = $file_name . ': ' . $e->getMessage();
    }
}

if ($uploaded_count > 0) {
    echo json_encode([
        'success' => true,
        'message' => "$uploaded_count resim basariyla yuklendi.",
        'count'   => $uploaded_count,
        'errors'  => $errors,
    ]);
} else {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Hicbir resim yuklenemedi: ' . implode(', ', $errors),
    ]);
}
const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('fileInput');
const categoryId = <?= $category_id ?>;

dropzone.addEventListener('click', () => fileInput.click());

dropzone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropzone.classList.add('dragover');
});

dropzone.addEventListener('dragleave', () => {
    dropzone.classList.remove('dragover');
});

dropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    handleFiles(e.dataTransfer.files);
});

fileInput.addEventListener('change', (e) => {
    handleFiles(e.target.files);
    fileInput.value = '';
});

function handleFiles(files) {
    if (categoryId === 0) {
        alert('Lutfen once bir kategori secin.');
        return;
    }

    const formData = new FormData();
    formData.append('category_id', categoryId);
    formData.append('csrf_token', '<?= csrf_token() ?>');

    Array.from(files).forEach(file => {
        formData.append('files[]', file);
    });

    const uploadProgress = document.getElementById('uploadProgress');
    const uploadList = document.getElementById('uploadList');
    const uploadStats = document.getElementById('uploadStats');
    const uploadBar = document.getElementById('uploadBar');
    const uploadPercent = document.getElementById('uploadPercent');

    uploadProgress.style.display = 'block';
    uploadList.innerHTML = '';
    uploadBar.style.width = '0%';
    uploadPercent.textContent = '0%';
    uploadStats.textContent = 'Yukleniyor...';

    Array.from(files).forEach((file, index) => {
        const item = document.createElement('div');
        item.className = 'upload-file-item';
        item.id = 'fileItem-' + index;
        item.innerHTML = '<i class="bi bi-file-image"></i>' +
            '<div style="flex:1;"><div>' + file.name + '</div>' +
            '<div class="report-bar mt-2"><div class="report-bar-fill" id="fileBar-' + index + '" style="width:0%;"></div></div></div>' +
            '<span class="upload-status" id="fileStatus-' + index + '">Hazirlaniyor...</span>';
        uploadList.appendChild(item);
    });

    const xhr = new XMLHttpRequest();

    xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable) {
            const percent = Math.round((e.loaded / e.total) * 100);
            uploadBar.style.width = percent + '%';
            uploadPercent.textContent = percent + '%';
        }
    });

    xhr.addEventListener('load', function() {
        try {
            const response = JSON.parse(xhr.responseText);
            if (response.success) {
                uploadStats.textContent = response.message;
                uploadBar.style.width = '100%';
                uploadPercent.textContent = '%100';
                // Her dosyayi basarili isaretle
                for (let i = 0; i < files.length; i++) {
                    const st = document.getElementById('fileStatus-' + i);
                    if (st) { st.textContent = 'Yuklendi'; st.style.color = 'var(--a-green)'; }
                    const bar = document.getElementById('fileBar-' + i);
                    if (bar) bar.style.width = '100%';
                }
                if (response.errors && response.errors.length > 0) {
                    uploadList.innerHTML += '<div class="alert alert-warning" style="margin-top:.5rem;">Bazi dosyalarda hata: ' + response.errors.join(', ') + '</div>';
                }
                setTimeout(() => { location.reload(); }, 1500);
            } else {
                uploadStats.textContent = 'Hata olustu';
                for (let i = 0; i < files.length; i++) {
                    const st = document.getElementById('fileStatus-' + i);
                    if (st) { st.textContent = 'Basarisiz'; st.style.color = 'var(--a-red)'; }
                }
                uploadList.innerHTML += '<div class="alert alert-error" style="margin-top:.5rem;">' + (response.message || 'Bilinmeyen hata') + '</div>';
            }
        } catch(e) {
            uploadList.innerHTML += '<div class="alert alert-error" style="margin-top:.5rem;">Sunucu yaniti okunamadi (HTTP ' + xhr.status + ').</div>';
        }
    });

    xhr.addEventListener('error', function() {
        uploadStats.textContent = 'Baglanti hatasi';
        uploadList.innerHTML += '<div class="alert alert-error" style="margin-top:.5rem;">Sunucuya baglanirken hata olustu.</div>';
    });

    xhr.addEventListener('timeout', function() {
        uploadStats.textContent = 'Zaman asimi';
        uploadList.innerHTML += '<div class="alert alert-error" style="margin-top:.5rem;">Islem zaman asimina ugradi.</div>';
    });

    xhr.open('POST', 'api/gallery-upload.php', true);
    xhr.timeout = 60000; // 60 saniye
    xhr.send(formData);
}

function editImage(img) {
    document.getElementById('imageId').value = img.id;
    document.getElementById('imageTitle').value = img.title || '';
    document.getElementById('imageAlt').value = img.alt_text || '';
    document.getElementById('imageDescription').value = img.description || '';
    document.getElementById('imageOrder').value = img.display_order;
    document.getElementById('imageActive').checked = img.is_active == 1;
    document.getElementById('imageModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeImageModal() {
    document.getElementById('imageModal').classList.remove('active');
    document.body.style.overflow = '';
}

function viewImage(src) {
    document.getElementById('viewImage').src = '../uploads/' + src;
    document.getElementById('viewModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeViewModal() {
    document.getElementById('viewModal').classList.remove('active');
    document.body.style.overflow = '';
}

function deleteImage(id) {
    if (confirm('Bu resmi silmek istediginize emin misiniz?')) {
        fetch('api/gallery-delete.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({image_id: id, csrf_token: '<?= csrf_token() ?>'})
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                document.getElementById('img-' + id).remove();
            }
        });
    }
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') { closeImageModal(); closeViewModal(); }
});
document.getElementById('imageModal')?.addEventListener('click', function(e) { if (e.target === this) closeImageModal(); });
document.getElementById('viewModal')?.addEventListener('click', function(e) { if (e.target === this) closeViewModal(); });
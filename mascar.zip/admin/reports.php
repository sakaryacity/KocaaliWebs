<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();
$pdo = db();

$year = isset($_GET['year']) && ctype_digit($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');

$rows = $pdo->prepare(
    "SELECT MONTH(start_date) AS ay, COUNT(*) AS islem_sayisi, SUM(total_price) AS gelir
     FROM rentals
     WHERE status IN ('tamamlandi','aktif') AND YEAR(start_date) = ?
     GROUP BY MONTH(start_date)
     ORDER BY ay ASC"
);
$rows->execute([$year]);
$monthData = [];
foreach ($rows->fetchAll() as $r) {
    $monthData[(int)$r['ay']] = $r;
}

$monthNames = [1=>'Ocak',2=>'Subat',3=>'Mart',4=>'Nisan',5=>'Mayis',6=>'Haziran',7=>'Temmuz',8=>'Agustos',9=>'Eylul',10=>'Ekim',11=>'Kasim',12=>'Aralik'];

$totalIncome = 0;
$totalCount  = 0;
foreach ($monthData as $m) { $totalIncome += (float)$m['gelir']; $totalCount += (int)$m['islem_sayisi']; }

$availableYears = $pdo->query("SELECT DISTINCT YEAR(start_date) y FROM rentals ORDER BY y DESC")->fetchAll();
if (!$availableYears) { $availableYears = [['y' => date('Y')]]; }

$maxMonthIncome = 0;
foreach ($monthData as $m) { $maxMonthIncome = max($maxMonthIncome, (float)$m['gelir']); }
$maxMonthIncome = $maxMonthIncome ?: 1;

$page_title  = 'Aylik Gelir Raporu';
$active_menu = 'reports';
require __DIR__ . '/includes/header.php';
?>

<div class="page-header">
  <form method="get" class="filters">
    <select name="year" onchange="this.form.submit()">
      <?php foreach ($availableYears as $y): ?>
        <option value="<?= (int)$y['y'] ?>" <?= $year === (int)$y['y'] ? 'selected' : '' ?>><?= (int)$y['y'] ?></option>
      <?php endforeach; ?>
    </select>
  </form>
</div>

<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-icon" style="background:var(--a-green)"><i class="bi bi-cash-stack"></i></div>
    <div class="stat-value"><?= number_format($totalIncome, 0, ',', '.') ?> ₺</div>
    <div class="stat-label"><?= $year ?> Yili Toplam Gelir</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:var(--a-blue)"><i class="bi bi-receipt"></i></div>
    <div class="stat-value"><?= $totalCount ?></div>
    <div class="stat-label">Toplam Kiralama Islemi</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon" style="background:var(--a-amber)"><i class="bi bi-graph-up"></i></div>
    <div class="stat-value"><?= number_format($totalCount ? $totalIncome / $totalCount : 0, 0, ',', '.') ?> ₺</div>
    <div class="stat-label">Islem Basina Ortalama Gelir</div>
  </div>
</div>

<div class="card">
  <div class="card-title"><h2 class="h6 mb-0">Aylara Gore Gelir Dagilimi — <?= $year ?></h2></div>
  <!-- Desktop: Table with bars -->
  <div class="table-wrap desktop-only">
    <table class="admin-table">
      <thead><tr><th>Ay</th><th>Islem Sayisi</th><th>Toplam Gelir</th><th style="width:35%">Gorsel Dagilim</th></tr></thead>
      <tbody>
      <?php for ($m = 1; $m <= 12; $m++):
        $data = $monthData[$m] ?? ['islem_sayisi' => 0, 'gelir' => 0];
        $pct = round(((float)$data['gelir'] / $maxMonthIncome) * 100); ?>
        <tr>
          <td><strong><?= $monthNames[$m] ?></strong></td>
          <td><?= (int)$data['islem_sayisi'] ?></td>
          <td><?= number_format((float)$data['gelir'], 0, ',', '.') ?> ₺</td>
          <td>
            <div class="report-bar">
              <div class="report-bar-fill" style="width:<?= $pct ?>%;"></div>
            </div>
          </td>
        </tr>
      <?php endfor; ?>
      </tbody>
      <tfoot>
        <tr style="font-weight:700;">
          <td>Toplam</td>
          <td><?= $totalCount ?></td>
          <td><?= number_format($totalIncome, 0, ',', '.') ?> ₺</td>
          <td></td>
        </tr>
      </tfoot>
    </table>
  </div>
  <!-- Mobile: iOS List with bars -->
  <div class="ios-list mobile-only">
    <?php for ($m = 1; $m <= 12; $m++):
      $data = $monthData[$m] ?? ['islem_sayisi' => 0, 'gelir' => 0];
      $pct = round(((float)$data['gelir'] / $maxMonthIncome) * 100); ?>
      <div class="ios-list-item">
        <div class="item-body" style="flex:1;">
          <div class="item-title"><?= $monthNames[$m] ?> <span class="badge badge-gray" style="font-size:.68rem;"><?= (int)$data['islem_sayisi'] ?> islem</span></div>
          <div style="margin-top:.5rem;">
            <div class="report-bar"><div class="report-bar-fill" style="width:<?= $pct ?>%;"></div></div>
          </div>
        </div>
        <div class="item-action">
          <strong><?= number_format((float)$data['gelir'], 0, ',', '.') ?> ₺</strong>
        </div>
      </div>
    <?php endfor; ?>
    <div class="ios-list-item" style="background:var(--a-off);font-weight:700;">
      <div class="item-body"><div class="item-title">Toplam (<?= $totalCount ?> islem)</div></div>
      <div class="item-action"><strong><?= number_format($totalIncome, 0, ',', '.') ?> ₺</strong></div>
    </div>
  </div>
  <p style="color:var(--a-gray);font-size:.82rem;margin-top:1rem;">
    * Gelir hesaplamasi, durumu "Aktif Kirada" veya "Tamamlandi" olan kiralama kayitlarinin kiralama baslangic
    tarihine gore gruplanmasiyle olusturulur.
  </p>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>

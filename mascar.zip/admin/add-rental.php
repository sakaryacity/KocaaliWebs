<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();

$pdo = db();

// FORM GONDERILDIGINDE CALISACAK KAYIT ISLEMI
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        csrf_check();

        $vehicle_id    = (int)$_POST['vehicle_id'];
        $customer_name = trim($_POST['customer_name']);
        $customer_phone = trim($_POST['phone']);
        $customer_id_no = !empty($_POST['customer_id_no']) ? trim($_POST['customer_id_no']) : null;

        $start_date    = $_POST['start_date'];
        $end_date      = $_POST['end_date'];
        $pickup_time   = $_POST['pickup_time'];
        $return_time   = $_POST['return_time'];

        $daily_price   = (float)$_POST['daily_price'];
        $total_price   = (float)$_POST['total_price'];

        $status = $_POST['status'];
        $notes  = !empty($_POST['notes']) ? trim($_POST['notes']) : null;

        $stmt = $pdo->prepare("INSERT INTO rentals (vehicle_id, customer_name, customer_phone, customer_id_no, start_date, end_date, pickup_time, return_time, daily_price, total_price, status, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$vehicle_id, $customer_name, $customer_phone, $customer_id_no, $start_date, $end_date, $pickup_time, $return_time, $daily_price, $total_price, $status, $notes]);

        $_SESSION['flash_success'] = 'Randevu takvime basariyla eklendi!';
        header('Location: index.php');
        exit;

    } catch (PDOException $e) {
        $errors[] = 'Veritabani hatasi: ' . $e->getMessage();
    }
}

// TAKVIMDEN GELEN VERILERI YAKALA
$vehicleId = isset($_GET['vehicle_id']) ? (int)$_GET['vehicle_id'] : 0;
$start = isset($_GET['start']) ? $_GET['start'] : date('Y-m-d');
$end = isset($_GET['end']) ? $_GET['end'] : date('Y-m-d', strtotime('+1 day'));

// SECILEN ARAC BILGILERI
$stmt = $pdo->prepare("SELECT brand, model, daily_price FROM vehicles WHERE id = ?");
$stmt->execute([$vehicleId]);
$vehicle = $stmt->fetch();

$dailyPrice = $vehicle ? (float)$vehicle['daily_price'] : 0;
$datetime1 = new DateTime($start);
$datetime2 = new DateTime($end);
$interval = $datetime1->diff($datetime2);
$days = $interval->days > 0 ? $interval->days : 1;
$calculatedTotal = $days * $dailyPrice;

$page_title = 'Hizli Randevu';
$active_menu = 'dashboard';
require __DIR__ . '/includes/header.php';
?>

<div class="page-header">
  <a href="index.php" class="btn btn-outline btn-sm"><i class="bi bi-arrow-left"></i> Ana Sayfa</a>
</div>

<?php if (!empty($errors)): ?>
  <?php foreach ($errors as $err): ?>
    <div class="alert alert-error"><?= h($err) ?></div>
  <?php endforeach; ?>
<?php endif; ?>

<!-- Arac Bilgi Karti -->
<div class="card" style="background:var(--a-black);color:#fff;">
  <div style="display:flex;align-items:center;gap:1rem;">
    <div style="width:50px;height:50px;border-radius:14px;background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:1.5rem;">
      <i class="bi bi-car-front-fill"></i>
    </div>
    <div>
      <div style="font-size:.78rem;color:rgba(255,255,255,.5);">Secilen Arac</div>
      <div style="font-size:1.15rem;font-weight:700;"><?= h($vehicle['brand'] ?? '') ?> <?= h($vehicle['model'] ?? '') ?></div>
    </div>
  </div>
</div>

<form method="POST" action="">
  <?= generateCsrfField() ?>
  <input type="hidden" name="vehicle_id" value="<?= $vehicleId ?>">

  <!-- Musteri Bilgileri -->
  <div class="card">
    <h2 class="h6 mb-2"><i class="bi bi-person-fill me-2"></i> Musteri Bilgileri</h2>
    <div class="form-grid">
      <div class="form-group">
        <label>Adi Soyadi *</label>
        <input type="text" name="customer_name" class="form-control" placeholder="Adi Soyadi" required>
      </div>
      <div class="form-group">
        <label>Telefon Numarasi *</label>
        <input type="tel" name="phone" class="form-control" placeholder="0 5XX XXX XX XX" required>
      </div>
      <div class="form-group">
        <label>T.C. Kimlik / Pasaport</label>
        <input type="text" name="customer_id_no" class="form-control" placeholder="Opsiyonel">
      </div>
    </div>
  </div>

  <!-- Tarih ve Saat -->
  <div class="card">
    <h2 class="h6 mb-2"><i class="bi bi-calendar-range-fill me-2"></i> Kiralama Suresi</h2>
    <div class="form-grid">
      <div class="form-group">
        <label>Alis Tarihi</label>
        <input type="date" name="start_date" class="form-control calc-trigger" value="<?= h($start) ?>" required>
      </div>
      <div class="form-group">
        <label>Alis Saati</label>
        <input type="time" name="pickup_time" class="form-control" value="10:00" required>
      </div>
      <div class="form-group">
        <label>Teslim Tarihi</label>
        <input type="date" name="end_date" class="form-control calc-trigger" value="<?= h($end) ?>" required>
      </div>
      <div class="form-group">
        <label>Teslim Saati</label>
        <input type="time" name="return_time" class="form-control" value="10:00" required>
      </div>
    </div>
  </div>

  <!-- Fiyat ve Durum -->
  <div class="card">
    <h2 class="h6 mb-2"><i class="bi bi-wallet2 me-2"></i> Ucretlendirme</h2>
    <div class="form-grid">
      <div class="form-group">
        <label>Gunluk Fiyat (₺)</label>
        <input type="number" name="daily_price" class="form-control calc-trigger" id="dailyPriceField" value="<?= $dailyPrice ?>" required>
      </div>
      <div class="form-group">
        <label>Toplam Tutar (₺)</label>
        <input type="number" name="total_price" class="form-control" id="totalPriceField" value="<?= $calculatedTotal ?>" readonly style="background:var(--a-green-light);font-weight:700;font-size:1.2rem;color:var(--a-green);">
      </div>
      <div class="form-group" style="grid-column:1/-1;">
        <label>Durum</label>
        <select name="status" class="form-control">
          <option value="rezervasyon" selected>Rezervasyon (Musteri Gelecek)</option>
          <option value="aktif">Aktif Kirada (Araci Teslim Aldi)</option>
        </select>
      </div>
      <div class="form-group" style="grid-column:1/-1;">
        <label>Istege Bagli Notlar</label>
        <textarea name="notes" class="form-control" rows="3" placeholder="Ek notlar..."></textarea>
      </div>
    </div>
  </div>

  <button type="submit" class="btn btn-primary btn-block"><i class="bi bi-check2-circle me-1"></i> Randevuyu Onayla</button>
</form>

<!-- Dinamik Fiyat Hesaplama -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const inputs = document.querySelectorAll('.calc-trigger');
    const startInput = document.querySelector('input[name="start_date"]');
    const endInput = document.querySelector('input[name="end_date"]');
    const dailyPriceInput = document.getElementById('dailyPriceField');
    const totalPriceInput = document.getElementById('totalPriceField');

    function calculateTotal() {
        let start = new Date(startInput.value);
        let end = new Date(endInput.value);
        let daily = parseFloat(dailyPriceInput.value) || 0;

        if (start && end && start <= end) {
            let diffTime = Math.abs(end - start);
            let diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            if(diffDays === 0) diffDays = 1;
            totalPriceInput.value = diffDays * daily;
        }
    }

    inputs.forEach(input => {
        input.addEventListener('change', calculateTotal);
    });
});
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>

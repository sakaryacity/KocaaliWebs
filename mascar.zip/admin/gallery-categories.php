<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();

$pdo = db();

// Kategori Ekle/Guncelle
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = $_POST['id'] ?? null;
    $name = trim($_POST['name'] ?? '');
    $slug = strtolower(trim($_POST['slug'] ?? preg_replace('/[^a-z0-9]+/', '-', $name)));
    $description = trim($_POST['description'] ?? '');
    $display_order = (int)($_POST['display_order'] ?? 0);
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    if (empty($name)) {
        $_SESSION['flash_error'] = 'Kategori adi zorunludur.';
    } else {
        try {
            if ($id) {
                $stmt = $pdo->prepare("UPDATE gallery_categories SET name=?, slug=?, description=?, display_order=?, is_active=? WHERE id=?");
                $stmt->execute([$name, $slug, $description, $display_order, $is_active, $id]);
                log_activity("Galeri kategorisi guncellendi (ID: $id)");
                $_SESSION['flash_success'] = 'Kategori guncellendi.';
            } else {
                $stmt = $pdo->prepare("INSERT INTO gallery_categories (name, slug, description, display_order, is_active) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$name, $slug, $description, $display_order, $is_active]);
                log_activity("Yeni galeri kategorisi eklendi: $name");
                $_SESSION['flash_success'] = 'Kategori eklendi.';
            }
            header('Location: gallery-categories.php');
            exit;
        } catch (PDOException $e) {
            $_SESSION['flash_error'] = 'Veritabani hatasi: ' . $e->getMessage();
        }
    }
}

// Kategori Sil
if (isset($_GET['delete']) && ctype_digit($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $pdo->prepare('DELETE FROM gallery_images WHERE category_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM gallery_categories WHERE id = ?')->execute([$id]);
        log_activity("Galeri kategorisi silindi (ID: $id)");
        $_SESSION['flash_success'] = 'Kategori silindi.';
        header('Location: gallery-categories.php');
        exit;
    } catch (PDOException $e) {
        $_SESSION['flash_error'] = 'Silme hatasi: ' . $e->getMessage();
    }
}

// Kategorileri Listele
$categories = $pdo->query(
    "SELECT gc.*, (SELECT COUNT(*) FROM gallery_images WHERE category_id = gc.id) as image_count
     FROM gallery_categories gc ORDER BY gc.display_order ASC, gc.created_at DESC"
)->fetchAll();

$page_title = 'Galeri Kategorileri';
$active_menu = 'gallery';
require __DIR__ . '/includes/header.php';
?>

<div class="page-header">
  <div>
    <p style="color:var(--a-gray);margin:0;">Galeri kategorilerini yonetin ve duzenleyin</p>
  </div>
  <button type="button" class="btn btn-primary" onclick="openCategoryModal()"><i class="bi bi-plus-lg"></i> Yeni Kategori</button>
</div>

<?php if (!empty($_SESSION['flash_error'])): ?>
  <div class="alert alert-error"><?= h($_SESSION['flash_error']) ?></div>
  <?php unset($_SESSION['flash_error']); ?>
<?php endif; ?>
<?php if (!empty($_SESSION['flash_success'])): ?>
  <div class="alert alert-success"><?= h($_SESSION['flash_success']) ?></div>
  <?php unset($_SESSION['flash_success']); ?>
<?php endif; ?>

<div class="card">
  <?php if (empty($categories)): ?>
    <div class="empty-state">
      <i class="bi bi-inbox"></i>
      <p>Henüz kategori eklememisseniz.</p>
      <button type="button" class="btn btn-primary mt-2" onclick="openCategoryModal()"><i class="bi bi-plus-lg"></i> Ilk Kategoriyi Ekle</button>
    </div>
  <?php else: ?>
  <!-- Desktop: Table -->
  <div class="table-wrap desktop-only">
    <table class="admin-table">
      <thead>
        <tr><th>Kategori Adi</th><th>Slug</th><th>Resim Sayisi</th><th>Sira</th><th>Durum</th><th style="text-align:center;">Islemler</th></tr>
      </thead>
      <tbody>
        <?php foreach ($categories as $cat): ?>
        <tr>
          <td>
            <strong><?= h($cat['name']) ?></strong>
            <?php if (!empty($cat['description'])): ?>
            <br><span style="font-size:.85rem;color:var(--a-gray);"><?= h(mb_substr($cat['description'], 0, 50)) ?></span>
            <?php endif; ?>
          </td>
          <td><code style="background:var(--a-off);padding:.25rem .5rem;border-radius:6px;font-size:.85rem;"><?= h($cat['slug']) ?></code></td>
          <td><span class="badge badge-blue"><?= $cat['image_count'] ?> resim</span></td>
          <td>
            <input type="number" value="<?= (int)$cat['display_order'] ?>" style="width:60px;padding:.5rem;border:1.5px solid var(--a-fog);border-radius:10px;font-size:.88rem;" onchange="updateOrder(<?= (int)$cat['id'] ?>, this.value)">
          </td>
          <td>
            <?php if ($cat['is_active']): ?>
            <span class="badge badge-green">Aktif</span>
            <?php else: ?>
            <span class="badge badge-gray">Deaktif</span>
            <?php endif; ?>
          </td>
          <td style="text-align:center;">
            <button class="btn btn-outline btn-sm" onclick="editCategory(<?= htmlspecialchars(json_encode($cat), ENT_QUOTES, 'UTF-8') ?>"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-danger btn-sm" onclick="deleteCategory(<?= (int)$cat['id'] ?>)"><i class="bi bi-trash3-fill"></i></button>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <!-- Mobile: iOS List -->
  <div class="ios-list mobile-only">
    <?php foreach ($categories as $cat): ?>
    <div class="ios-list-item">
      <div class="item-icon" style="background:var(--a-red-light);color:var(--a-red);"><i class="bi bi-folder-fill"></i></div>
      <div class="item-body">
        <div class="item-title"><?= h($cat['name']) ?></div>
        <div class="item-sub"><?= $cat['image_count'] ?> resim · Sira: <?= (int)$cat['display_order'] ?></div>
      </div>
      <div class="item-action" style="display:flex;flex-direction:column;gap:6px;">
        <span class="badge <?= $cat['is_active'] ? 'badge-green' : 'badge-gray' ?>"><?= $cat['is_active'] ? 'Aktif' : 'Deaktif' ?></span>
        <div style="display:flex;gap:6px;">
          <button class="btn btn-outline btn-sm" style="padding:4px 8px;" onclick="editCategory(<?= htmlspecialchars(json_encode($cat), ENT_QUOTES, 'UTF-8') ?>"><i class="bi bi-pencil"></i></button>
          <button class="btn btn-danger btn-sm" style="padding:4px 8px;" onclick="deleteCategory(<?= (int)$cat['id'] ?>)"><i class="bi bi-trash3-fill"></i></button>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- Kategori Modal -->
<div class="modal-overlay" id="categoryModal">
  <div class="modal-box">
    <div class="modal-header">
      <h3 id="modalTitle">Yeni Kategori Ekle</h3>
      <button class="modal-close" onclick="closeCategoryModal()">&times;</button>
    </div>
    <form method="POST" id="categoryForm">
      <div class="modal-body">
        <input type="hidden" name="id" id="categoryId">
        <?= generateCsrfField() ?>

        <div class="form-group">
          <label>Kategori Adi *</label>
          <input type="text" name="name" id="categoryName" class="form-control" required onkeyup="updateSlug()">
          <small style="color:var(--a-gray);">Orn: Motor, Kaporta & Boya, Fren vb.</small>
        </div>

        <div class="form-group">
          <label>Slug (URL Dostu Adi)</label>
          <input type="text" name="slug" id="categorySlug" class="form-control" placeholder="motor, kaporta-boya, fren">
          <small style="color:var(--a-gray);">Otomatik olusturulur, gerekirse duzenleyebilirsiniz.</small>
        </div>

        <div class="form-group">
          <label>Aciklama</label>
          <textarea name="description" id="categoryDescription" class="form-control" placeholder="Kategori aciklamasi"></textarea>
        </div>

        <div class="form-group">
          <label>Sira Numarasi</label>
          <input type="number" name="display_order" id="categoryOrder" class="form-control" value="0" min="0">
          <small style="color:var(--a-gray);">Kucuk sayilar once gosterilir.</small>
        </div>

        <div class="form-group">
          <label class="toggle-label"><input type="checkbox" name="is_active" id="categoryActive" checked> Aktif</label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeCategoryModal()">Iptal</button>
        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Kaydet</button>
      </div>
    </form>
  </div>
</div>

<script>
function openCategoryModal() {
    document.getElementById('categoryId').value = '';
    document.getElementById('categoryForm').reset();
    document.getElementById('modalTitle').textContent = 'Yeni Kategori Ekle';
    document.getElementById('categoryModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeCategoryModal() {
    document.getElementById('categoryModal').classList.remove('active');
    document.body.style.overflow = '';
}

function editCategory(cat) {
    document.getElementById('categoryId').value = cat.id;
    document.getElementById('categoryName').value = cat.name;
    document.getElementById('categorySlug').value = cat.slug;
    document.getElementById('categoryDescription').value = cat.description || '';
    document.getElementById('categoryOrder').value = cat.display_order;
    document.getElementById('categoryActive').checked = cat.is_active == 1;
    document.getElementById('modalTitle').textContent = 'Kategoriyi Duzenle';
    document.getElementById('categoryModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function deleteCategory(id) {
    if (confirm('Bu kategoriyi silmek istediginize emin misiniz? Kategoriye ait tum resimler de silinecektir.')) {
        window.location.href = 'gallery-categories.php?delete=' + id;
    }
}

function updateSlug() {
    const name = document.getElementById('categoryName').value;
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    document.getElementById('categorySlug').value = slug;
}

function updateOrder(id, order) {
    fetch('api/gallery-update-order.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({category_id: id, order: order, csrf_token: '<?= csrf_token() ?>'})
    });
}

document.getElementById('categoryModal')?.addEventListener('click', function(e) {
    if (e.target === this) closeCategoryModal();
});
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeCategoryModal();
});
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>

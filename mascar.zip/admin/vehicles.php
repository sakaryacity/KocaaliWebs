<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();
$pdo = db();

// Silme islemi
if (isset($_GET['delete']) && ctype_digit($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare('SELECT COUNT(*) c FROM rentals WHERE vehicle_id = ?');
    $stmt->execute([$id]);
    if ((int)$stmt->fetch()['c'] > 0) {
        $_SESSION['flash_error'] = 'Bu araca ait kiralama kayitlari bulundugu icin silinemedi. Bunun yerine durumunu "Pasif" yapabilirsiniz.';
    } else {
        $pdo->prepare('DELETE FROM vehicles WHERE id = ?')->execute([$id]);
        log_activity("Arac silindi (ID: $id)");
        $_SESSION['flash_success'] = 'Arac basariyla silindi.';
    }
    header('Location: vehicles.php');
    exit;
}

$statusFilter  = $_GET['status'] ?? 'all';
$segmentFilter = $_GET['segment'] ?? 'all';

$sql = "SELECT * FROM vehicles WHERE 1=1";
$params = [];
if ($statusFilter !== 'all') { $sql .= " AND status = ?"; $params[] = $statusFilter; }
if ($segmentFilter !== 'all') { $sql .= " AND segment = ?"; $params[] = $segmentFilter; }
$sql .= " ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$vehicles = $stmt->fetchAll();

$statusBadge = ['musait'=>'badge-green','kirada'=>'badge-amber','bakimda'=>'badge-blue','pasif'=>'badge-gray'];
$statusLabel = ['musait'=>'Musait','kirada'=>'Kirada','bakimda'=>'Bakimda','pasif'=>'Pasif'];

$page_title  = 'Kiralik Araclar';
$active_menu = 'vehicles';
require __DIR__ . '/includes/header.php';
?>

<div class="page-header">
  <div>
    <p style="color:var(--a-gray);margin:0;">Filonuzu buradan yonetin: marka, model, fiyat ve gorselleri guncelleyin.</p>
  </div>
  <a href="vehicle-form.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Yeni Arac Ekle</a>
</div>

<?php if (!empty($_SESSION['flash_success'])): ?>
  <div class="alert alert-success"><?= h($_SESSION['flash_success']) ?></div>
  <?php unset($_SESSION['flash_success']); ?>
<?php endif; ?>
<?php if (!empty($_SESSION['flash_error'])): ?>
  <div class="alert alert-error"><?= h($_SESSION['flash_error']) ?></div>
  <?php unset($_SESSION['flash_error']); ?>
<?php endif; ?>

<div class="card">
  <form method="get" class="filters">
    <select name="status" onchange="this.form.submit()">
      <option value="all" <?= $statusFilter==='all'?'selected':'' ?>>Tum Durumlar</option>
      <option value="musait" <?= $statusFilter==='musait'?'selected':'' ?>>Musait</option>
      <option value="kirada" <?= $statusFilter==='kirada'?'selected':'' ?>>Kirada</option>
      <option value="bakimda" <?= $statusFilter==='bakimda'?'selected':'' ?>>Bakimda</option>
      <option value="pasif" <?= $statusFilter==='pasif'?'selected':'' ?>>Pasif</option>
    </select>
    <select name="segment" onchange="this.form.submit()">
      <option value="all" <?= $segmentFilter==='all'?'selected':'' ?>>Tum Segmentler</option>
      <option value="ekonomik" <?= $segmentFilter==='ekonomik'?'selected':'' ?>>Ekonomik</option>
      <option value="sedan" <?= $segmentFilter==='sedan'?'selected':'' ?>>Sedan</option>
      <option value="suv" <?= $segmentFilter==='suv'?'selected':'' ?>>SUV</option>
      <option value="hatchback" <?= $segmentFilter==='hatchback'?'selected':'' ?>>Hatchback</option>
    </select>
  </form>

  <?php if (!$vehicles): ?>
    <div class="empty-state"><i class="bi bi-car-front"></i>Kayitli arac bulunamadi.</div>
  <?php else: ?>
  <!-- Desktop: Table -->
  <div class="table-wrap desktop-only">
    <table class="admin-table">
      <thead>
        <tr><th>Gorsel</th><th>Marka / Model</th><th>Segment</th><th>Yakit / Vites</th><th>Gunluk Fiyat</th><th>Durum</th><th>Islemler</th></tr>
      </thead>
      <tbody>
      <?php foreach ($vehicles as $v): ?>
        <tr>
          <td><img class="thumb" src="<?= $v['main_image'] ? '../uploads/' . h($v['main_image']) : 'https://placehold.co/80x56?text=Foto' ?>" alt="<?= h($v['brand'].' '.$v['model']) ?>"></td>
          <td><strong><?= h($v['brand']) ?> <?= h($v['model']) ?></strong><br><span style="color:var(--a-gray);font-size:.78rem"><?= (int)$v['year'] ?></span></td>
          <td><?= h(ucfirst($v['segment'])) ?></td>
          <td><?= h(ucfirst($v['fuel_type'])) ?> · <?= h(ucfirst($v['gear_type'])) ?></td>
          <td><?= number_format((float)$v['daily_price'], 0, ',', '.') ?> ₺</td>
          <td><span class="badge <?= $statusBadge[$v['status']] ?>"><?= $statusLabel[$v['status']] ?></span></td>
          <td>
            <a href="vehicle-form.php?id=<?= (int)$v['id'] ?>" class="btn btn-outline btn-sm"><i class="bi bi-pencil-fill"></i></a>
            <a href="vehicles.php?delete=<?= (int)$v['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bu araci silmek istediginize emin misiniz?')"><i class="bi bi-trash3-fill"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <!-- Mobile: iOS List -->
  <div class="ios-list mobile-only">
    <?php foreach ($vehicles as $v): ?>
      <div class="ios-list-item">
        <img class="thumb" src="<?= $v['main_image'] ? '../uploads/' . h($v['main_image']) : 'https://placehold.co/80x56?text=Foto' ?>" alt="" style="width:56px;height:56px;border-radius:12px;">
        <div class="item-body">
          <div class="item-title"><?= h($v['brand']) ?> <?= h($v['model']) ?> <small style="color:var(--a-gray);">(<?= (int)$v['year'] ?>)</small></div>
          <div class="item-sub"><?= h(ucfirst($v['segment'])) ?> · <?= h(ucfirst($v['fuel_type'])) ?> · <?= number_format((float)$v['daily_price'], 0, ',', '.') ?> ₺/gun</div>
        </div>
        <div class="item-action" style="display:flex;flex-direction:column;gap:6px;">
          <span class="badge <?= $statusBadge[$v['status']] ?>"><?= $statusLabel[$v['status']] ?></span>
          <div style="display:flex;gap:6px;">
            <a href="vehicle-form.php?id=<?= (int)$v['id'] ?>" class="btn btn-outline btn-sm"><i class="bi bi-pencil-fill"></i></a>
            <a href="vehicles.php?delete=<?= (int)$v['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Silinsin mi?')"><i class="bi bi-trash3-fill"></i></a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>

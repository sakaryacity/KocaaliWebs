<?php
require_once __DIR__ . '/includes/auth.php';

if (admin_is_logged_in()) {
    log_activity('Cikis yapti');
}

$_SESSION = [];
session_destroy();
header('Location: login.php');
exit;

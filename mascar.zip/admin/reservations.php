<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    csrf_check();
    $id = (int)$_POST['id'];
    $status = $_POST['status'];
    if (in_array($status, ['yeni','incelendi','donusturuldu','iptal'], true)) {
        $pdo->prepare('UPDATE reservation_requests SET status = ? WHERE id = ?')->execute([$status, $id]);
        $_SESSION['flash_success'] = 'Talep durumu guncellendi.';
    }
    header('Location: reservations.php');
    exit;
}
if (isset($_GET['delete']) && ctype_digit($_GET['delete'])) {
    $pdo->prepare('DELETE FROM reservation_requests WHERE id = ?')->execute([(int)$_GET['delete']]);
    header('Location: reservations.php');
    exit;
}

$requests = $pdo->query('SELECT * FROM reservation_requests ORDER BY created_at DESC')->fetchAll();

$statusBadge = ['yeni'=>'badge-amber','incelendi'=>'badge-blue','donusturuldu'=>'badge-green','iptal'=>'badge-red'];
$statusLabel = ['yeni'=>'Yeni','incelendi'=>'Incelendi','donusturuldu'=>'Kiralamaya Donusturuldu','iptal'=>'Iptal'];

$page_title  = 'Rezervasyon Talepleri';
$active_menu = 'reservations';
require __DIR__ . '/includes/header.php';
?>

<?php if (!empty($_SESSION['flash_success'])): ?>
  <div class="alert alert-success"><?= h($_SESSION['flash_success']) ?></div>
  <?php unset($_SESSION['flash_success']); ?>
<?php endif; ?>

<div class="card">
  <p style="color:var(--a-gray);">Web sitesindeki rezervasyon formundan gelen on talepler burada listelenir. Bir talebi onayladiktan sonra <a href="rentals.php">Kiralama Takibi</a> sayfasindan gercek bir kiralama kaydi olusturabilirsiniz.</p>
  <?php if (!$requests): ?>
    <div class="empty-state"><i class="bi bi-inbox"></i>Henüz rezervasyon talebi yok.</div>
  <?php else: ?>
  <!-- Desktop: Table -->
  <div class="table-wrap desktop-only">
    <table class="admin-table">
      <thead><tr><th>Musteri</th><th>Istenen Arac</th><th>Sure</th><th>Tarih / Saat Araligi</th><th>Not</th><th>Durum</th><th>Islemler</th></tr></thead>
      <tbody>
      <?php foreach ($requests as $r): ?>
        <tr>
          <td><?= h($r['full_name']) ?><br><span style="color:var(--a-gray);font-size:.78rem"><a href="tel:<?= h($r['phone']) ?>"><?= h($r['phone']) ?></a></span></td>
          <td><?= h($r['vehicle_text'] ?: '—') ?></td>
          <td><?= h($r['duration_text'] ?: '—') ?></td>
          <td>
            <?= $r['start_date'] ? date('d.m.Y', strtotime($r['start_date'])) : '—' ?><?= $r['pickup_time'] ? ' ' . substr($r['pickup_time'],0,5) : '' ?>
            <?= $r['end_date'] ? ' – ' . date('d.m.Y', strtotime($r['end_date'])) : '' ?><?= $r['return_time'] ? ' ' . substr($r['return_time'],0,5) : '' ?>
          </td>
          <td style="max-width:200px;white-space:normal;"><?= h($r['message'] ?: '—') ?></td>
          <td>
            <form method="post" style="display:flex;gap:.4rem;align-items:center;">
              <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <select name="status" class="form-control" style="padding:.3rem .5rem;font-size:.78rem;" onchange="this.form.submit()">
                <?php foreach ($statusLabel as $k=>$l): ?>
                  <option value="<?= $k ?>" <?= $r['status']===$k?'selected':'' ?>><?= $l ?></option>
                <?php endforeach; ?>
              </select>
              <input type="hidden" name="update_status" value="1">
            </form>
          </td>
          <td style="white-space:nowrap;">
            <?php if ($r['vehicle_id'] && $r['status'] !== 'donusturuldu'): ?>
              <a href="rentals.php?vehicle_id=<?= (int)$r['vehicle_id'] ?>&customer_name=<?= urlencode($r['full_name']) ?>&customer_phone=<?= urlencode($r['phone']) ?>&start_date=<?= h($r['start_date'] ?? '') ?>&end_date=<?= h($r['end_date'] ?? '') ?>#top"
                 class="btn btn-outline btn-sm" title="Kiralamaya Donustur"><i class="bi bi-arrow-right-circle-fill"></i></a>
            <?php endif; ?>
            <a href="reservations.php?delete=<?= (int)$r['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Silinsin mi?')"><i class="bi bi-trash3-fill"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <!-- Mobile: iOS List -->
  <div class="ios-list mobile-only">
    <?php foreach ($requests as $r): ?>
      <div class="ios-list-item">
        <div class="item-icon" style="background:<?= $statusBadge[$r['status']] === 'badge-amber' ? 'var(--a-amber-light)' : ($statusBadge[$r['status']] === 'badge-green' ? 'var(--a-green-light)' : 'var(--a-blue-light)') ?>;color:<?= $statusBadge[$r['status']] === 'badge-amber' ? 'var(--a-amber)' : ($statusBadge[$r['status']] === 'badge-green' ? 'var(--a-green)' : 'var(--a-blue)') ?>;"><i class="bi bi-inbox-fill"></i></div>
        <div class="item-body">
          <div class="item-title"><?= h($r['full_name']) ?></div>
          <div class="item-sub"><?= h($r['vehicle_text'] ?: 'Belirtilmemis') ?> · <?= h($r['duration_text'] ?: '—') ?></div>
          <?php if ($r['start_date']): ?>
            <div class="item-sub"><?= date('d.m.Y', strtotime($r['start_date'])) ?><?= $r['end_date'] ? ' – ' . date('d.m.Y', strtotime($r['end_date'])) : '' ?></div>
          <?php endif; ?>
          <?php if ($r['message']): ?>
            <div class="item-sub"><?= h(mb_substr($r['message'], 0, 50)) ?></div>
          <?php endif; ?>
        </div>
        <div class="item-action" style="display:flex;flex-direction:column;gap:6px;">
          <span class="badge <?= $statusBadge[$r['status']] ?? 'badge-amber' ?>"><?= $statusLabel[$r['status']] ?? $r['status'] ?></span>
          <div style="display:flex;gap:6px;">
            <form method="post" style="display:flex;gap:.2rem;">
              <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <select name="status" style="padding:.2rem .3rem;font-size:.72rem;border:1px solid var(--a-fog);border-radius:8px;" onchange="this.form.submit()">
                <?php foreach ($statusLabel as $k=>$l): ?>
                  <option value="<?= $k ?>" <?= $r['status']===$k?'selected':'' ?>><?= $l ?></option>
                <?php endforeach; ?>
              </select>
              <input type="hidden" name="update_status" value="1">
            </form>
            <?php if ($r['vehicle_id'] && $r['status'] !== 'donusturuldu'): ?>
              <a href="rentals.php?vehicle_id=<?= (int)$r['vehicle_id'] ?>&customer_name=<?= urlencode($r['full_name']) ?>&customer_phone=<?= urlencode($r['phone']) ?>&start_date=<?= h($r['start_date'] ?? '') ?>&end_date=<?= h($r['end_date'] ?? '') ?>#top" class="btn btn-outline btn-sm" style="padding:4px 8px;" title="Donustur"><i class="bi bi-arrow-right-circle-fill"></i></a>
            <?php endif; ?>
            <a href="reservations.php?delete=<?= (int)$r['id'] ?>" class="btn btn-danger btn-sm" style="padding:4px 8px;" onclick="return confirm('Silinsin mi?')"><i class="bi bi-trash3-fill"></i></a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>

<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();
$pdo = db();

$vehicleId = isset($_GET['id']) && ctype_digit($_GET['id']) ? (int)$_GET['id'] : null;
$vehicle = [
    'brand' => '', 'model' => '', 'year' => date('Y'), 'segment' => 'ekonomik', 'fuel_type' => 'dizel',
    'gear_type' => 'manuel', 'seats' => 5, 'luggage_liters' => '', 'has_ac' => 1, 'daily_price' => '',
    'monthly_price' => '', 'description' => '', 'main_image' => '', 'status' => 'musait', 'is_featured' => 0,
];
$gallery = [];

if ($vehicleId) {
    $stmt = $pdo->prepare('SELECT * FROM vehicles WHERE id = ?');
    $stmt->execute([$vehicleId]);
    $found = $stmt->fetch();
    if (!$found) { header('Location: vehicles.php'); exit; }
    $vehicle = $found;
    $g = $pdo->prepare('SELECT * FROM vehicle_gallery WHERE vehicle_id = ? ORDER BY sort_order, id');
    $g->execute([$vehicleId]);
    $gallery = $g->fetchAll();
}

$errors = [];

/** Yuklenen gorseli diske kaydeder, goreli dosya yolunu dondurur. */
function handle_upload(string $fieldName, string $subdir): ?string
{
    if (empty($_FILES[$fieldName]['name']) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    $file = $_FILES[$fieldName];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Gorsel yuklenirken bir hata olustu.');
    }
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        throw new RuntimeException('Gorsel boyutu 5 MB\'i asamaz.');
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    if (!in_array($mime, ALLOWED_IMAGE_TYPES, true)) {
        throw new RuntimeException('Sadece JPG, PNG veya WEBP formatinda gorsel yukleyebilirsiniz.');
    }
    $ext = match ($mime) {
        'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', default => 'jpg',
    };
    $filename = $subdir . '/' . bin2hex(random_bytes(8)) . '.' . $ext;
    $destination = __DIR__ . '/../uploads/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        throw new RuntimeException('Gorsel sunucuya kaydedilemedi. Klasor izinlerini kontrol edin.');
    }
    return $filename;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $vehicle['brand']          = trim($_POST['brand'] ?? '');
    $vehicle['model']          = trim($_POST['model'] ?? '');
    $vehicle['year']           = (int)($_POST['year'] ?? date('Y'));
    $vehicle['segment']        = $_POST['segment'] ?? 'ekonomik';
    $vehicle['fuel_type']      = $_POST['fuel_type'] ?? 'dizel';
    $vehicle['gear_type']      = $_POST['gear_type'] ?? 'manuel';
    $vehicle['seats']          = (int)($_POST['seats'] ?? 5);
    $vehicle['luggage_liters'] = $_POST['luggage_liters'] !== '' ? (int)$_POST['luggage_liters'] : null;
    $vehicle['has_ac']         = isset($_POST['has_ac']) ? 1 : 0;
    $vehicle['daily_price']    = (float)str_replace(',', '.', $_POST['daily_price'] ?? 0);
    $vehicle['monthly_price']  = $_POST['monthly_price'] !== '' ? (float)str_replace(',', '.', $_POST['monthly_price']) : null;
    $vehicle['description']    = trim($_POST['description'] ?? '');
    $vehicle['status']         = $_POST['status'] ?? 'musait';
    $vehicle['is_featured']    = isset($_POST['is_featured']) ? 1 : 0;

    if ($vehicle['brand'] === '' || $vehicle['model'] === '') {
        $errors[] = 'Marka ve model alanlari zorunludur.';
    }
    if ($vehicle['daily_price'] <= 0) {
        $errors[] = 'Gunluk fiyat 0\'dan buyuk olmalidir.';
    }

    if (!$errors) {
        try {
            $newMainImage = handle_upload('main_image', 'vehicles');
            if ($newMainImage) {
                $vehicle['main_image'] = $newMainImage;
            }

            if ($vehicleId) {
                $sql = "UPDATE vehicles SET brand=?, model=?, year=?, segment=?, fuel_type=?, gear_type=?, seats=?,
                        luggage_liters=?, has_ac=?, daily_price=?, monthly_price=?, description=?, main_image=?,
                        status=?, is_featured=? WHERE id=?";
                $pdo->prepare($sql)->execute([
                    $vehicle['brand'], $vehicle['model'], $vehicle['year'], $vehicle['segment'], $vehicle['fuel_type'],
                    $vehicle['gear_type'], $vehicle['seats'], $vehicle['luggage_liters'], $vehicle['has_ac'],
                    $vehicle['daily_price'], $vehicle['monthly_price'], $vehicle['description'], $vehicle['main_image'],
                    $vehicle['status'], $vehicle['is_featured'], $vehicleId,
                ]);
                log_activity("Arac guncellendi: {$vehicle['brand']} {$vehicle['model']} (ID: $vehicleId)");
            } else {
                $sql = "INSERT INTO vehicles (brand, model, year, segment, fuel_type, gear_type, seats, luggage_liters,
                        has_ac, daily_price, monthly_price, description, main_image, status, is_featured)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $pdo->prepare($sql)->execute([
                    $vehicle['brand'], $vehicle['model'], $vehicle['year'], $vehicle['segment'], $vehicle['fuel_type'],
                    $vehicle['gear_type'], $vehicle['seats'], $vehicle['luggage_liters'], $vehicle['has_ac'],
                    $vehicle['daily_price'], $vehicle['monthly_price'], $vehicle['description'], $vehicle['main_image'],
                    $vehicle['status'], $vehicle['is_featured'],
                ]);
                $vehicleId = (int)$pdo->lastInsertId();
                log_activity("Yeni arac eklendi: {$vehicle['brand']} {$vehicle['model']} (ID: $vehicleId)");
            }

            // Ek galeri gorselleri (coklu yukleme)
            if (!empty($_FILES['gallery_images']['name'][0])) {
                $count = count($_FILES['gallery_images']['name']);
                for ($i = 0; $i < $count; $i++) {
                    if ($_FILES['gallery_images']['error'][$i] !== UPLOAD_ERR_OK) continue;
                    $single = [
                        'name' => $_FILES['gallery_images']['name'][$i],
                        'type' => $_FILES['gallery_images']['type'][$i],
                        'tmp_name' => $_FILES['gallery_images']['tmp_name'][$i],
                        'error' => $_FILES['gallery_images']['error'][$i],
                        'size' => $_FILES['gallery_images']['size'][$i],
                    ];
                    $_FILES['__tmp_single'] = $single;
                    $path = handle_upload('__tmp_single', 'gallery');
                    if ($path) {
                        $pdo->prepare('INSERT INTO vehicle_gallery (vehicle_id, image_path, sort_order) VALUES (?,?,?)')
                            ->execute([$vehicleId, $path, $i]);
                    }
                }
            }

            // Galeriden gorsel silme
            if (!empty($_POST['remove_gallery']) && is_array($_POST['remove_gallery'])) {
                foreach ($_POST['remove_gallery'] as $gid) {
                    $pdo->prepare('DELETE FROM vehicle_gallery WHERE id = ? AND vehicle_id = ?')->execute([(int)$gid, $vehicleId]);
                }
            }

            $_SESSION['flash_success'] = 'Arac bilgileri basariyla kaydedildi.';
            header('Location: vehicles.php');
            exit;
        } catch (RuntimeException $e) {
            $errors[] = $e->getMessage();
        }
    }
}

$page_title  = $vehicleId ? 'Araci Duzenle' : 'Yeni Arac Ekle';
$active_menu = 'vehicles';
require __DIR__ . '/includes/header.php';
?>

<div class="page-header">
  <a href="vehicles.php" class="btn btn-outline btn-sm"><i class="bi bi-arrow-left"></i> Arac Listesi</a>
</div>

<?php foreach ($errors as $err): ?>
  <div class="alert alert-error"><?= h($err) ?></div>
<?php endforeach; ?>

<form method="post" enctype="multipart/form-data">
  <?= generateCsrfField() ?>

  <div class="card">
    <h2 class="h6 mb-2">Temel Bilgiler</h2>
    <div class="form-grid">
      <div class="form-group"><label>Marka *</label><input type="text" name="brand" class="form-control" value="<?= h($vehicle['brand']) ?>" required></div>
      <div class="form-group"><label>Model *</label><input type="text" name="model" class="form-control" value="<?= h($vehicle['model']) ?>" required></div>
      <div class="form-group"><label>Model Yili</label><input type="number" name="year" class="form-control" value="<?= h((string)$vehicle['year']) ?>" min="1990" max="2100"></div>
      <div class="form-group">
        <label>Segment</label>
        <select name="segment" class="form-control">
          <?php foreach (['ekonomik'=>'Ekonomik','sedan'=>'Sedan','suv'=>'SUV','hatchback'=>'Hatchback'] as $k=>$l): ?>
            <option value="<?= $k ?>" <?= $vehicle['segment']===$k?'selected':'' ?>><?= $l ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Yakit Turu</label>
        <select name="fuel_type" class="form-control">
          <?php foreach (['benzin'=>'Benzin','dizel'=>'Dizel','hibrit'=>'Hibrit','elektrik'=>'Elektrik','lpg'=>'LPG'] as $k=>$l): ?>
            <option value="<?= $k ?>" <?= $vehicle['fuel_type']===$k?'selected':'' ?>><?= $l ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Vites</label>
        <select name="gear_type" class="form-control">
          <?php foreach (['manuel'=>'Manuel','otomatik'=>'Otomatik'] as $k=>$l): ?>
            <option value="<?= $k ?>" <?= $vehicle['gear_type']===$k?'selected':'' ?>><?= $l ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group"><label>Koltuk Sayisi</label><input type="number" name="seats" class="form-control" value="<?= h((string)$vehicle['seats']) ?>" min="1" max="9"></div>
      <div class="form-group"><label>Bagaj Hacmi (Lt)</label><input type="number" name="luggage_liters" class="form-control" value="<?= h((string)$vehicle['luggage_liters']) ?>"></div>
      <div class="form-group">
        <label>Durum</label>
        <select name="status" class="form-control">
          <?php foreach (['musait'=>'Musait','kirada'=>'Kirada','bakimda'=>'Bakimda','pasif'=>'Pasif'] as $k=>$l): ?>
            <option value="<?= $k ?>" <?= $vehicle['status']===$k?'selected':'' ?>><?= $l ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div class="form-group mt-2">
      <label class="toggle-label"><input type="checkbox" name="has_ac" <?= $vehicle['has_ac'] ? 'checked' : '' ?>> Klima mevcut</label>
      <label class="toggle-label"><input type="checkbox" name="is_featured" <?= $vehicle['is_featured'] ? 'checked' : '' ?>> Ana sayfada one cikar</label>
    </div>
  </div>

  <div class="card">
    <h2 class="h6 mb-2">Fiyatlandirma</h2>
    <div class="form-grid">
      <div class="form-group"><label>Gunluk Fiyat (₺) *</label><input type="text" name="daily_price" class="form-control" value="<?= h((string)$vehicle['daily_price']) ?>" required></div>
      <div class="form-group"><label>Aylik Fiyat (₺)</label><input type="text" name="monthly_price" class="form-control" value="<?= h((string)$vehicle['monthly_price']) ?>"></div>
    </div>
  </div>

  <div class="card">
    <h2 class="h6 mb-2">Aciklama</h2>
    <div class="form-group"><textarea name="description" class="form-control" rows="4"><?= h($vehicle['description']) ?></textarea></div>
  </div>

  <div class="card">
    <h2 class="h6 mb-2">Gorseller</h2>
    <div class="form-group">
      <label>Ana Gorsel</label><br>
      <?php if ($vehicle['main_image']): ?>
        <img class="img-preview mb-2" src="../uploads/<?= h($vehicle['main_image']) ?>" alt="Mevcut gorsel">
      <?php endif; ?>
      <input type="file" name="main_image" class="form-control" accept="image/jpeg,image/png,image/webp">
      <small style="color:var(--a-gray)">JPG, PNG veya WEBP · maks. 5 MB</small>
    </div>

    <div class="form-group">
      <label>Galeri Gorselleri (birden fazla secabilirsiniz)</label>
      <input type="file" name="gallery_images[]" class="form-control" accept="image/jpeg,image/png,image/webp" multiple>
      <?php if ($gallery): ?>
        <div class="gallery-thumbs">
          <?php foreach ($gallery as $g): ?>
            <div class="g-item">
              <img src="../uploads/<?= h($g['image_path']) ?>" alt="Galeri gorseli">
              <label style="position:absolute;bottom:-4px;left:0;background:#fff;border-radius:6px;padding:1px 4px;font-size:.65rem;display:flex;align-items:center;gap:2px;box-shadow:0 2px 6px rgba(0,0,0,.15);">
                <input type="checkbox" name="remove_gallery[]" value="<?= (int)$g['id'] ?>"> Sil
              </label>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Kaydet</button>
  <a href="vehicles.php" class="btn btn-outline">Iptal</a>
</form>

<?php require __DIR__ . '/includes/footer.php'; ?>

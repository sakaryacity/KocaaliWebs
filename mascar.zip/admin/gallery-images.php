<?php
require_once __DIR__ . '/includes/auth.php';
admin_require_login();

$pdo = db();
$category_id = (int)($_GET['category'] ?? 0);

// Kategorileri getir
$categories = $pdo->query("SELECT * FROM gallery_categories WHERE is_active = 1 ORDER BY display_order ASC")->fetchAll();

// Secili kategoriye ait resimleri getir
$images = [];
$selectedCategory = null;
if ($category_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM gallery_images WHERE category_id = ? ORDER BY display_order ASC, created_at DESC");
    $stmt->execute([$category_id]);
    $images = $stmt->fetchAll();

    $stmt = $pdo->prepare("SELECT * FROM gallery_categories WHERE id = ?");
    $stmt->execute([$category_id]);
    $selectedCategory = $stmt->fetch();
}

$page_title = 'Galeri Resim Yonetimi';
$active_menu = 'gallery';
require __DIR__ . '/includes/header.php';
?>

<div class="page-header">
  <div>
    <p style="color:var(--a-gray);margin:0;">Galeri kategorilerine resim ekleyin ve yonetin</p>
  </div>
</div>

<!-- Kategori Secim Alani -->
<div class="card">
  <div class="card-title"><h2 class="h6 mb-0">Kategori Sec</h2></div>
  <?php if (empty($categories)): ?>
    <div class="empty-state">
      <i class="bi bi-inbox"></i>Henüz kategori yoktur.
      <a href="gallery-categories.php" style="color:var(--a-red);font-weight:600;">Kategori ekleyin</a>
    </div>
  <?php else: ?>
  <div class="gallery-category-grid" style="grid-template-columns:repeat(auto-fill,minmax(140px,1fr));">
    <?php foreach ($categories as $cat):
      $count = $pdo->prepare("SELECT COUNT(*) as c FROM gallery_images WHERE category_id = ?");
      $count->execute([$cat['id']]);
      $imgCount = (int)$count->fetch()['c'];
    ?>
    <a href="gallery-images.php?category=<?= (int)$cat['id'] ?>" class="gallery-category-card" style="border:2px solid <?= $category_id == $cat['id'] ? 'var(--a-red)' : 'transparent' ?>;">
      <div class="cat-thumb" style="display:flex;align-items:center;justify-content:center;<?= $category_id == $cat['id'] ? 'background:var(--a-red-light);' : '' ?>">
        <i class="bi bi-folder-fill" style="font-size:2rem;color:<?= $category_id == $cat['id'] ? 'var(--a-red)' : 'var(--a-gray-light)' ?>;"></i>
      </div>
      <div class="cat-info">
        <div class="cat-name"><?= h($cat['name']) ?></div>
        <div class="cat-count"><?= $imgCount ?> resim</div>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<?php if ($category_id > 0 && $selectedCategory): ?>

<!-- Resim Yukleme Alani -->
<div class="card">
  <div class="card-title">
    <h2 class="h6 mb-0">Resimleri Yukle — <strong><?= h($selectedCategory['name']) ?></strong></h2>
  </div>
  <div class="dropzone" id="dropzone">
    <i class="bi bi-cloud-arrow-up"></i>
    <p>Resimleri buraya surukleyin veya <strong>tiklayarak secin</strong></p>
    <small style="color:var(--a-gray);">JPG, PNG, WebP - Maks. 5MB (Otomatik sikistirilacak)</small>
  </div>
  <input type="file" id="fileInput" multiple accept="image/*" style="display:none;">

  <!-- Yukleme Durumu -->
  <div id="uploadProgress" style="display:none;" class="upload-progress-wrap">
    <div class="progress-header">
      <span id="uploadStats">0 / 0 dosya yuklendi</span>
      <span id="uploadPercent">0%</span>
    </div>
    <div class="progress-bar-bg">
      <div class="progress-bar-fill" id="uploadBar" style="width:0%;"></div>
    </div>
    <div id="uploadList" style="margin-top:.8rem;"></div>
  </div>
</div>

<!-- Yuklenen Resimlerin Galerisi -->
<?php if (!empty($images)): ?>
<div class="card">
  <div class="card-title">
    <h2 class="h6 mb-0">Yuklenen Resimler (<?= count($images) ?>)</h2>
  </div>
  <div class="gallery-image-grid" id="galleryGrid">
    <?php foreach ($images as $img): ?>
    <div class="gallery-image-item" id="img-<?= (int)$img['id'] ?>">
      <img src="../uploads/<?= h($img['image_path']) ?>" alt="<?= h($img['alt_text']) ?>" loading="lazy">
      <span class="img-size-badge"><?= round($img['file_size'] / 1024) ?>KB</span>
      <div class="img-overlay">
        <button class="btn-view" onclick="viewImage('<?= h($img['image_path']) ?>')" title="Goruntule"><i class="bi bi-eye"></i></button>
        <button class="btn-edit" onclick="editImage(<?= htmlspecialchars(json_encode($img), ENT_QUOTES, 'UTF-8') ?>)" title="Duzenle"><i class="bi bi-pencil"></i></button>
        <button class="btn-del" onclick="deleteImage(<?= (int)$img['id'] ?>)" title="Sil"><i class="bi bi-trash3"></i></button>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php else: ?>
<div class="card">
  <div class="empty-state"><i class="bi bi-image"></i>Bu kategoriye henüz resim yuklenmemis.</div>
</div>
<?php endif; ?>

<?php endif; ?>

<!-- Resim Duzenleme Modal -->
<div class="modal-overlay" id="imageModal">
  <div class="modal-box">
    <div class="modal-header">
      <h3>Resmi Duzenle</h3>
      <button class="modal-close" onclick="closeImageModal()">&times;</button>
    </div>
    <form method="POST" id="imageForm" action="api/gallery-update-image.php">
      <div class="modal-body">
        <input type="hidden" name="image_id" id="imageId">
        <?= generateCsrfField() ?>

        <div class="form-group">
          <label>Resim Basligi</label>
          <input type="text" name="title" id="imageTitle" class="form-control" placeholder="Detayli Motor Bakimi">
        </div>
        <div class="form-group">
          <label>Alt Metni (SEO)</label>
          <input type="text" name="alt_text" id="imageAlt" class="form-control" placeholder="Resmin aciklamasi">
        </div>
        <div class="form-group">
          <label>Aciklama</label>
          <textarea name="description" id="imageDescription" class="form-control" placeholder="Resim hakkinda detayli bilgi"></textarea>
        </div>
        <div class="form-group">
          <label>Sira Numarasi</label>
          <input type="number" name="display_order" id="imageOrder" class="form-control" value="0" min="0">
        </div>
        <div class="form-group">
          <label class="toggle-label"><input type="checkbox" name="is_active" id="imageActive" checked> Aktif</label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeImageModal()">Iptal</button>
        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Kaydet</button>
      </div>
    </form>
  </div>
</div>

<!-- Resim Goruntuleme Modal -->
<div class="modal-overlay" id="viewModal">
  <div class="modal-box" style="max-width:800px;">
    <div class="modal-header">
      <h3>Resmi Goruntule</h3>
      <button class="modal-close" onclick="closeViewModal()">&times;</button>
    </div>
    <div class="modal-body" style="text-align:center;">
      <img id="viewImage" src="" alt="" style="max-width:100%;max-height:600px;border-radius:var(--a-radius-sm);">
    </div>
  </div>
</div>

<script>
const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('fileInput');
const categoryId = <?= $category_id ?>;

dropzone.addEventListener('click', () => fileInput.click());

dropzone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropzone.classList.add('dragover');
});

dropzone.addEventListener('dragleave', () => {
    dropzone.classList.remove('dragover');
});

dropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    handleFiles(e.dataTransfer.files);
});

fileInput.addEventListener('change', (e) => {
    handleFiles(e.target.files);
});

function handleFiles(files) {
    if (categoryId === 0) {
        alert('Lutfen once bir kategori secin.');
        return;
    }

    const formData = new FormData();
    formData.append('category_id', categoryId);
    formData.append('csrf_token', '<?= csrf_token() ?>');

    Array.from(files).forEach(file => {
        formData.append('files[]', file);
    });

    const uploadProgress = document.getElementById('uploadProgress');
    const uploadList = document.getElementById('uploadList');
    const uploadStats = document.getElementById('uploadStats');
    const uploadBar = document.getElementById('uploadBar');
    const uploadPercent = document.getElementById('uploadPercent');

    uploadProgress.style.display = 'block';
    uploadList.innerHTML = '';

    Array.from(files).forEach((file, index) => {
        const item = document.createElement('div');
        item.className = 'upload-file-item';
        item.innerHTML = `
            <i class="bi bi-file-image"></i>
            <div style="flex:1;">
                <div>${file.name}</div>
                <div class="report-bar mt-2"><div class="report-bar-fill" id="fileBar-${index}" style="width:0%;"></div></div>
            </div>
            <span class="upload-status">Hazirlaniyor...</span>
        `;
        uploadList.appendChild(item);
    });

    const xhr = new XMLHttpRequest();

    xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable) {
            const percent = Math.round((e.loaded / e.total) * 100);
            uploadBar.style.width = percent + '%';
            uploadPercent.textContent = percent + '%';
        }
    });

    xhr.addEventListener('load', function() {
        if (xhr.status === 200) {
            try {
                const response = JSON.parse(xhr.responseText);
                if (response.success) {
                    uploadStats.textContent = response.message;
                    setTimeout(() => { location.reload(); }, 1500);
                } else {
                    uploadList.innerHTML = '<div class="alert alert-error">' + response.message + '</div>';
                }
            } catch(e) {
                uploadList.innerHTML = '<div class="alert alert-error">Yukleme sirinda hata olustu.</div>';
            }
        }
    });

    xhr.addEventListener('error', function() {
        uploadList.innerHTML = '<div class="alert alert-error">Yukleme sirasinda hata olustu.</div>';
    });

    xhr.open('POST', 'api/gallery-upload.php', true);
    xhr.send(formData);
}

function editImage(img) {
    document.getElementById('imageId').value = img.id;
    document.getElementById('imageTitle').value = img.title || '';
    document.getElementById('imageAlt').value = img.alt_text || '';
    document.getElementById('imageDescription').value = img.description || '';
    document.getElementById('imageOrder').value = img.display_order;
    document.getElementById('imageActive').checked = img.is_active == 1;
    document.getElementById('imageModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeImageModal() {
    document.getElementById('imageModal').classList.remove('active');
    document.body.style.overflow = '';
}

function viewImage(src) {
    document.getElementById('viewImage').src = '../uploads/' + src;
    document.getElementById('viewModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeViewModal() {
    document.getElementById('viewModal').classList.remove('active');
    document.body.style.overflow = '';
}

function deleteImage(id) {
    if (confirm('Bu resmi silmek istediginize emin misiniz?')) {
        fetch('api/gallery-delete.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({image_id: id, csrf_token: '<?= csrf_token() ?>'})
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                document.getElementById('img-' + id).remove();
            }
        });
    }
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') { closeImageModal(); closeViewModal(); }
});
document.getElementById('imageModal')?.addEventListener('click', function(e) { if (e.target === this) closeImageModal(); });
document.getElementById('viewModal')?.addEventListener('click', function(e) { if (e.target === this) closeViewModal(); });
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>

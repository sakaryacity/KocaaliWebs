/* =====================================================================
   MAS-CAR AUTO — main.js
   Vanilla JS — No Bootstrap dependency
   ===================================================================== */
(() => {
  'use strict';

  /* ---------- 1. LOADING SCREEN ---------- */
  window.addEventListener('load', () => {
    const loader = document.getElementById('loading-screen');
    if (loader) setTimeout(() => loader.classList.add('is-hidden'), 350);
  });

  /* ---------- 2. STICKY HEADER ---------- */
  const header = document.querySelector('.mc-header');
  const onScrollHeader = () => {
    if (!header) return;
    header.classList.toggle('is-scrolled', window.scrollY > 40);
  };
  document.addEventListener('scroll', onScrollHeader, { passive: true });
  onScrollHeader();

  /* ---------- 3. SCROLL REVEAL ---------- */
  const revealEls = document.querySelectorAll('.reveal');
  if (revealEls.length) {
    const revealObs = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('is-visible'); revealObs.unobserve(e.target); } });
    }, { threshold: 0.12 });
    revealEls.forEach(el => revealObs.observe(el));
  }

  /* ---------- 4. COUNTER ANIMATION ---------- */
  const counters = document.querySelectorAll('.counter[data-target]');
  if (counters.length) {
    const animateCounter = (el) => {
      const target = parseInt(el.dataset.target, 10);
      const duration = 1800;
      const startTime = performance.now();
      const numSpan = el.querySelector('.num') || el;
      const step = (now) => {
        const progress = Math.min((now - startTime) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        numSpan.textContent = Math.floor(eased * target).toLocaleString('tr-TR');
        if (progress < 1) requestAnimationFrame(step);
        else numSpan.textContent = target.toLocaleString('tr-TR');
      };
      requestAnimationFrame(step);
    };
    const counterObs = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) { animateCounter(e.target); counterObs.unobserve(e.target); } });
    }, { threshold: 0.4 });
    counters.forEach(c => counterObs.observe(c));
  }

  /* ---------- 5. SCROLL TO TOP ---------- */
  const fabTop = document.querySelector('.fab-top');
  if (fabTop) {
    document.addEventListener('scroll', () => {
      fabTop.classList.toggle('is-visible', window.scrollY > 600);
    }, { passive: true });
    fabTop.addEventListener('click', (e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
  }

  /* ---------- 6. SMOOTH SCROLL ---------- */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', (e) => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth' }); }
    });
  });

  /* ---------- 7. OFFCANVAS MENU ---------- */
  const offToggle = document.querySelector('.navbar-toggler');
  const offPanel = document.querySelector('.offcanvas-panel');
  const offOverlay = document.querySelector('.offcanvas-overlay');
  const offClose = document.querySelector('.offcanvas-close');

  function openOffcanvas() {
    offPanel?.classList.add('is-open');
    offOverlay?.classList.add('is-open');
    document.body.style.overflow = 'hidden';
  }
  function closeOffcanvas() {
    offPanel?.classList.remove('is-open');
    offOverlay?.classList.remove('is-open');
    document.body.style.overflow = '';
  }

  offToggle?.addEventListener('click', openOffcanvas);
  offClose?.addEventListener('click', closeOffcanvas);
  offOverlay?.addEventListener('click', closeOffcanvas);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeOffcanvas(); });

  // Close offcanvas on link click
  offPanel?.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', closeOffcanvas);
  });

  /* ---------- 8. ACCORDION ---------- */
  document.querySelectorAll('.accordion-button').forEach(btn => {
    btn.addEventListener('click', () => {
      const collapse = btn.nextElementSibling;
      const isOpen = collapse.classList.contains('show');
      // Close siblings
      const parent = btn.closest('.mc-accordion') || btn.parentElement.parentElement;
      parent.querySelectorAll('.accordion-collapse.show').forEach(c => {
        c.classList.remove('show');
        c.previousElementSibling.classList.add('collapsed');
      });
      if (!isOpen) {
        collapse.classList.add('show');
        btn.classList.remove('collapsed');
      }
    });
  });

  /* ---------- 9. COOKIE / KVKK CONSENT ---------- */
  const cookieBar = document.getElementById('mc-cookie');
  if (cookieBar) {
    if (!localStorage.getItem('mascar_kvkk_onay')) {
      setTimeout(() => cookieBar.classList.add('is-visible'), 1200);
    }
    cookieBar.querySelectorAll('[data-cookie-accept]').forEach(btn => {
      btn.addEventListener('click', () => {
        localStorage.setItem('mascar_kvkk_onay', '1');
        cookieBar.classList.remove('is-visible');
      });
    });
  }

  /* ---------- 10. KVKK POPUP ---------- */
  const kvkkBtns = document.querySelectorAll('[data-kvkk-open]');
  const kvkkPopup = document.getElementById('kvkkPopup');
  kvkkBtns.forEach(btn => {
    btn.addEventListener('click', () => kvkkPopup?.classList.add('is-open'));
  });
  kvkkPopup?.querySelector('.mc-modal-close')?.addEventListener('click', () => kvkkPopup.classList.remove('is-open'));
  kvkkPopup?.addEventListener('click', (e) => { if (e.target === kvkkPopup) kvkkPopup.classList.remove('is-open'); });

  /* ---------- 11. TOAST NOTIFICATION ---------- */
  window.mcToast = (message, isError) => {
    let wrap = document.querySelector('.mc-toast-wrap');
    if (!wrap) { wrap = document.createElement('div'); wrap.className = 'mc-toast-wrap'; document.body.appendChild(wrap); }
    const toast = document.createElement('div');
    toast.className = 'mc-toast' + (isError ? ' error' : '');
    toast.innerHTML = `<i class="bi bi-${isError ? 'exclamation-circle' : 'check-circle'}-fill"></i><span>${message}</span>`;
    wrap.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add('is-visible'));
    setTimeout(() => { toast.classList.remove('is-visible'); setTimeout(() => toast.remove(), 400); }, 3800);
  };

  /* ---------- 12. FORM HANDLING (AJAX with CSRF) ---------- */
  // Inject CSRF token into forms that don't have one (for static HTML pages)
  document.querySelectorAll('form[data-mc-form]').forEach(form => {
    if (!form.querySelector('input[name="csrf_token"]')) {
      const input = document.createElement('input');
      input.type = 'hidden';
      input.name = 'csrf_token';
      input.value = localStorage.getItem('mascar_csrf') || '';
      form.appendChild(input);
    }
  });

  document.querySelectorAll('form[data-mc-form]').forEach(form => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!form.checkValidity()) { form.classList.add('was-validated'); return; }

      const submitBtn = form.querySelector('button[type="submit"]');
      const originalText = submitBtn ? submitBtn.innerHTML : '';
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border"></span> G\u00f6nderiliyor...';
      }

      try {
        const action = form.getAttribute('action') || '';
        if (!action) {
          window.mcToast('Bu form \u015fu an bir sunucuya ba\u011fl\u0131 de\u011fil.', true);
          return;
        }
        const formData = new FormData(form);

        // Fetch CSRF token for AJAX requests
        try {
          const csrfResp = await fetch('api/get-csrf.php');
          if (csrfResp.ok) {
            const csrfData = await csrfResp.json();
            if (csrfData.token) {
              formData.set('csrf_token', csrfData.token);
              localStorage.setItem('mascar_csrf', csrfData.token);
            }
          }
        } catch(_) { /* CSRF fetch failed, continue with existing token */ }

        const response = await fetch(action, { method: 'POST', body: formData });
        const data = await response.json().catch(() => null);

        if (data && data.success) {
          window.mcToast(data.message || 'Talebiniz ba\u015far\u0131yla al\u0131nd\u0131.');
          form.reset();
          form.classList.remove('was-validated');
        } else {
          window.mcToast((data && data.message) || 'Bir hata olu\u015ftu, l\u00fctfen tekrar deneyin.', true);
        }
      } catch (err) {
        window.mcToast('Ba\u011flant\u0131 hatas\u0131. L\u00fctfen tekrar deneyin veya bizi aray\u0131n.', true);
      } finally {
        if (submitBtn) { submitBtn.disabled = false; submitBtn.innerHTML = originalText; }
      }
    });
  });

  /* ---------- 13. DYNAMIC YEAR ---------- */
  document.querySelectorAll('[data-current-year]').forEach(el => {
    el.textContent = new Date().getFullYear();
  });

  /* ---------- 14. LAZY LOADING ---------- */
  const lazyImages = document.querySelectorAll('img[data-src]');
  if (lazyImages.length) {
    const lazyObs = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          const img = e.target;
          img.src = img.dataset.src;
          if (img.dataset.srcset) img.srcset = img.dataset.srcset;
          img.removeAttribute('data-src');
          lazyObs.unobserve(img);
        }
      });
    }, { rootMargin: '200px' });
    lazyImages.forEach(img => lazyObs.observe(img));
  }

  // Set loading=lazy on images without it
  document.querySelectorAll('img:not([loading])').forEach(img => img.setAttribute('loading', 'lazy'));

  /* ---------- 15. LIGHTBOX ---------- */
  const lightbox = document.getElementById('mc-lightbox');
  if (lightbox) {
    const lbImg = lightbox.querySelector('img');
    let lbImages = [];
    let lbIndex = 0;

    document.querySelectorAll('[data-lightbox]').forEach(trigger => {
      trigger.addEventListener('click', (e) => {
        e.preventDefault();
        lbImages = Array.from(document.querySelectorAll('[data-lightbox]')).map(t => ({ src: t.dataset.lightbox, alt: t.dataset.lightboxAlt || '' }));
        lbIndex = lbImages.findIndex(i => i.src === trigger.dataset.lightbox);
        lbImg.src = lbImages[lbIndex].src;
        lbImg.alt = lbImages[lbIndex].alt;
        lightbox.classList.add('is-open');
        document.body.style.overflow = 'hidden';
      });
    });

    // Open lightbox directly
    window.openLightbox = (src, alt) => {
      lbImg.src = src; lbImg.alt = alt || '';
      lightbox.classList.add('is-open');
      document.body.style.overflow = 'hidden';
    };
    window.closeLightbox = () => {
      lightbox.classList.remove('is-open');
      document.body.style.overflow = '';
    };

    const closeLb = () => { lightbox.classList.remove('is-open'); document.body.style.overflow = ''; };
    lightbox.querySelector('.lb-close')?.addEventListener('click', closeLb);
    lightbox.addEventListener('click', (e) => { if (e.target === lightbox) closeLb(); });

    const lbPrev = lightbox.querySelector('.lb-prev');
    const lbNext = lightbox.querySelector('.lb-next');
    if (lbPrev && lbNext && lbImages.length) {
      lbPrev.addEventListener('click', () => {
        if (lbImages.length === 0) return;
        lbIndex = (lbIndex - 1 + lbImages.length) % lbImages.length;
        lbImg.src = lbImages[lbIndex].src; lbImg.alt = lbImages[lbIndex].alt;
      });
      lbNext.addEventListener('click', () => {
        if (lbImages.length === 0) return;
        lbIndex = (lbIndex + 1) % lbImages.length;
        lbImg.src = lbImages[lbIndex].src; lbImg.alt = lbImages[lbIndex].alt;
      });
    }

    document.addEventListener('keydown', (e) => {
      if (!lightbox.classList.contains('is-open')) return;
      if (e.key === 'Escape') closeLb();
      if (e.key === 'ArrowLeft' && lbPrev) lbPrev.click();
      if (e.key === 'ArrowRight' && lbNext) lbNext.click();
    });
  }

  /* ---------- 16. VEHICLE FILTERING ---------- */
  const vFilterForm = document.getElementById('vehicle-filter-form');
  const vehicleCards = document.querySelectorAll('[data-vehicle-card]');
  if (vFilterForm && vehicleCards.length) {
    const applyFilters = () => {
      const brand = document.getElementById('filter-brand')?.value || 'all';
      const fuel = document.getElementById('filter-fuel')?.value || 'all';
      const gear = document.getElementById('filter-gear')?.value || 'all';
      const type = document.getElementById('filter-type')?.value || 'all';
      vehicleCards.forEach(card => {
        const matches =
          (brand === 'all' || card.dataset.brand === brand) &&
          (fuel === 'all' || card.dataset.fuel === fuel) &&
          (gear === 'all' || card.dataset.gear === gear) &&
          (type === 'all' || card.dataset.type === type);
        card.closest('[class*="col"]') ? (card.closest('[class*="col"]').style.display = matches ? '' : 'none') : (card.style.display = matches ? '' : 'none');
      });
    };
    vFilterForm.querySelectorAll('select').forEach(sel => sel.addEventListener('change', applyFilters));
  }

  /* ---------- 17. GALLERY AJAX LOADING ---------- */
  const galleryGrid = document.getElementById('galleryGrid');
  const galleryFilters = document.getElementById('galleryFilters');
  if (galleryGrid && galleryGrid.dataset.ajax === 'true') {
    loadGallery('all');
  }

  window.loadGallery = async function(categoryId) {
    try {
      const response = await fetch('api/get-gallery.php');
      const data = await response.json();
      if (!data.success) throw new Error(data.message);

      const { categories, images } = data;

      // Build filter chips
      if (galleryFilters) {
        galleryFilters.innerHTML = '<button class="filter-chip active" data-filter="all">T\u00fcm\u00fc</button>';
        categories.forEach(cat => {
          const btn = document.createElement('button');
          btn.className = 'filter-chip';
          btn.textContent = cat.name;
          btn.dataset.filter = cat.id;
          btn.addEventListener('click', () => {
            galleryFilters.querySelectorAll('.filter-chip').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            filterGalleryItems(cat.id);
          });
          galleryFilters.appendChild(btn);
        });
        galleryFilters.querySelector('[data-filter="all"]')?.addEventListener('click', () => {
          galleryFilters.querySelectorAll('.filter-chip').forEach(b => b.classList.remove('active'));
          galleryFilters.querySelector('[data-filter="all"]').classList.add('active');
          filterGalleryItems('all');
        });
      }

      displayImages(images);
    } catch (error) {
      galleryGrid.innerHTML = `<div class="gallery-loading"><div class="spinner"></div><p class="text-muted">${error.message}</p></div>`;
    }
  };

  function displayImages(images) {
    if (!images || !images.length) {
      galleryGrid.innerHTML = '<div class="gallery-loading"><p class="text-muted">Hen\u00fcz resim yok</p></div>';
      return;
    }
    galleryGrid.innerHTML = images.map(img => `
      <div class="gallery-item" data-category="${img.category_id}" onclick="openLightbox('${img.webp_path || img.image_path}', '${img.alt_text}')">
        <img src="${img.webp_path || img.image_path}" alt="${img.alt_text}" loading="lazy" width="280" height="210">
        <div class="gallery-overlay">
          <span class="g-tag">${img.category_name}</span>
          <div>${img.title || img.category_name}</div>
        </div>
      </div>
    `).join('');
  }

  function filterGalleryItems(categoryId) {
    const items = document.querySelectorAll('.gallery-item');
    items.forEach(item => {
      const show = categoryId === 'all' || item.dataset.category == categoryId;
      item.style.display = show ? '' : 'none';
      if (show) { item.style.opacity = '0'; requestAnimationFrame(() => item.style.opacity = '1'); }
    });
  }

  /* ---------- 18. VEHICLE SELECT FOR RESERVATION ---------- */
  const resVehicleSelect = document.getElementById('resVehicleSelect');
  const resVehicleId = document.getElementById('resVehicleId');
  if (resVehicleSelect && resVehicleId) {
    resVehicleSelect.addEventListener('change', () => {
      const opt = resVehicleSelect.selectedOptions[0];
      if (opt) resVehicleId.value = opt.dataset.vehicleId || '';
    });
  }

})();

/**
 * Mas-Car Auto — Arac Musaitlik Kontrolu (Frontend)
 */
const MasCarAvailability = (() => {
    const ENDPOINT = 'check-availability.php';

    function getCsrfToken() {
        const input = document.querySelector('input[name="csrf_token"]');
        if (input) return input.value;
        return null;
    }

    async function check(vehicleId, startDate, endDate, onSuccess, onError) {
        if (!vehicleId || !startDate || !endDate) { if(onError) onError('Tum alanlari doldurun.'); return; }
        if (new Date(endDate) < new Date(startDate)) { if(onError) onError('Bitis tarihi baslangictan once olamaz.'); return; }
        let token = getCsrfToken();
        const params = new URLSearchParams({ vehicle_id: vehicleId, start_date: startDate, end_date: endDate });
        try {
            const r = await fetch(ENDPOINT + '?' + params.toString());
            const data = await r.json();
            if (data.success) { if(onSuccess) onSuccess(data); } else { if(onError) onError(data.message); }
        } catch(e) { if(onError) onError('Baglanti hatasi.'); }
    }

    function initFormListener(config) {
        const { vehicleId, startDateSelector, endDateSelector, uiElements } = config;
        const sI = document.querySelector(startDateSelector), eI = document.querySelector(endDateSelector);
        if (!sI || !eI) return;
        let timer = null;
        function onChange() {
            if (!sI.value || !eI.value || new Date(eI.value) < new Date(sI.value)) return;
            clearTimeout(timer);
            timer = setTimeout(() => {
                check(vehicleId, sI.value, eI.value, (data) => {
                    const req = data.requested || {};
                    if (req.available) {
                        if(uiElements.statusText) { uiElements.statusText.textContent = 'Bu tarihlerde musait!'; uiElements.statusText.className = 'avail-status avail-ok'; }
                        if(uiElements.submitBtn) uiElements.submitBtn.disabled = false;
                    } else {
                        if(uiElements.statusText) { uiElements.statusText.textContent = 'Bu tarihlerde mesgul.'; uiElements.statusText.className = 'avail-status avail-no'; }
                        if(uiElements.submitBtn) uiElements.submitBtn.disabled = true;
                        if(uiElements.suggestText && req.suggestion) {
                            const s = req.suggestion;
                            uiElements.suggestText.innerHTML = '<strong>Oneri:</strong> ' + new Date(s.start).toLocaleDateString('tr-TR') + ' - ' + new Date(s.end).toLocaleDateString('tr-TR') + ' arasinda musait.';
                            uiElements.suggestText.style.display = 'block';
                        }
                    }
                }, (msg) => { if(uiElements.statusText) { uiElements.statusText.textContent = msg; uiElements.statusText.className = 'avail-status avail-no'; } });
            }, 500);
        }
        sI.addEventListener('change', onChange);
        eI.addEventListener('change', onChange);
    }

    return { check, initFormListener };
})();

-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 23 Tem 2026, 15:45:05
-- Sunucu sürümü: 8.0.43
-- PHP Sürümü: 8.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `mascar_auto`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int UNSIGNED NOT NULL,
  `admin_id` int UNSIGNED DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `activity_log`
--

INSERT INTO `activity_log` (`id`, `admin_id`, `action`, `created_at`) VALUES
(1, 1, 'Giriş yaptı', '2026-07-23 10:55:56'),
(2, 1, 'Araç güncellendi: Renault Clio (ID: 1)', '2026-07-23 10:58:15'),
(3, 1, 'Randevu durumu güncellendi (ID: 1 -> onaylandi)', '2026-07-23 11:02:47'),
(4, 1, 'Randevu durumu güncellendi (ID: 1 -> tamamlandi)', '2026-07-23 11:02:54'),
(5, 1, 'Randevu durumu güncellendi (ID: 1 -> iptal)', '2026-07-23 11:02:57'),
(6, 1, 'Randevu durumu güncellendi (ID: 1 -> tamamlandi)', '2026-07-23 11:03:00'),
(7, 1, 'Araç güncellendi: Fiat Egea (ID: 2)', '2026-07-23 11:04:36'),
(8, 1, 'Araç güncellendi: Volkswagen Passat (ID: 3)', '2026-07-23 11:04:50'),
(9, 1, 'Araç güncellendi: Hyundai Tucson (ID: 4)', '2026-07-23 11:05:13'),
(10, 1, 'Araç silindi (ID: 5)', '2026-07-23 11:05:18'),
(11, 1, 'Araç silindi (ID: 6)', '2026-07-23 11:05:21'),
(12, 1, 'Araç güncellendi: Hyundai Tucson (ID: 4)', '2026-07-23 11:05:35'),
(13, 1, 'Araç güncellendi: Renault Clio (ID: 1)', '2026-07-23 11:05:48'),
(14, 1, 'Araç güncellendi: Hyundai Tucson (ID: 4)', '2026-07-23 11:06:01'),
(15, 1, 'Kiralama durumu güncellendi (ID: 1 -> iptal)', '2026-07-23 11:06:18'),
(16, 1, 'Araç güncellendi: Renault Clio (ID: 1)', '2026-07-23 11:07:29'),
(17, 1, 'Kiralama durumu güncellendi (ID: 2 -> aktif)', '2026-07-23 11:17:29'),
(18, 1, 'Kiralama durumu güncellendi (ID: 2 -> rezervasyon)', '2026-07-23 11:17:31'),
(19, 1, 'Kiralama durumu güncellendi (ID: 2 -> tamamlandi)', '2026-07-23 11:17:33'),
(20, 1, 'Kiralama durumu güncellendi (ID: 3 -> iptal)', '2026-07-23 11:17:39'),
(21, 1, 'Kiralama durumu güncellendi (ID: 2 -> iptal)', '2026-07-23 11:17:41'),
(22, 1, 'Yeni kiralama eklendi: Salih Çakır (Araç ID: 3)', '2026-07-23 11:26:47'),
(23, 1, 'Yeni kiralama eklendi: casca csac (Araç ID: 3)', '2026-07-23 11:29:24'),
(24, 1, 'Kiralama durumu güncellendi (ID: 1 -> rezervasyon)', '2026-07-23 11:33:34'),
(25, 1, 'Kiralama durumu güncellendi (ID: 5 -> rezervasyon)', '2026-07-23 11:33:37'),
(26, 1, 'Kiralama durumu güncellendi (ID: 1 -> tamamlandi)', '2026-07-23 11:34:11'),
(27, 1, 'Randevu durumu güncellendi (ID: 2 -> beklemede)', '2026-07-23 12:36:28'),
(28, 1, 'Kiralama durumu güncellendi (ID: 8 -> tamamlandi)', '2026-07-23 14:00:34'),
(29, 1, 'Kiralama durumu güncellendi (ID: 7 -> iptal)', '2026-07-23 14:00:36'),
(30, 1, 'Kiralama durumu güncellendi (ID: 6 -> iptal)', '2026-07-23 14:00:37'),
(31, 1, 'Kiralama durumu güncellendi (ID: 5 -> iptal)', '2026-07-23 14:00:38'),
(32, 1, 'Kiralama durumu güncellendi (ID: 4 -> iptal)', '2026-07-23 14:00:40'),
(33, 1, 'Kiralama durumu güncellendi (ID: 9 -> iptal)', '2026-07-23 14:00:42'),
(34, 1, 'Kiralama durumu güncellendi (ID: 1 -> iptal)', '2026-07-23 14:00:45'),
(35, 1, 'Kiralama durumu güncellendi (ID: 8 -> iptal)', '2026-07-23 14:00:48');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int UNSIGNED NOT NULL,
  `username` varchar(60) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `role` enum('super_admin','editor') NOT NULL DEFAULT 'editor',
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password_hash`, `full_name`, `email`, `role`, `last_login_at`, `created_at`) VALUES
(1, 'admin', '$2y$10$q47HmfBwbkfORM6rTf.wj.9w.xtb70wiixj6kkebLKvG8AsPaiPTy', 'Site Yöneticisi', 'info@mascarauto.com.tr', 'super_admin', '2026-07-23 10:55:56', '2026-07-23 10:54:29');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `appointments`
--

CREATE TABLE `appointments` (
  `id` int UNSIGNED NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `vehicle_info` varchar(150) DEFAULT NULL,
  `service_type` varchar(80) NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `message` text,
  `status` enum('beklemede','onaylandi','tamamlandi','iptal') NOT NULL DEFAULT 'beklemede',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `appointments`
--

INSERT INTO `appointments` (`id`, `full_name`, `phone`, `vehicle_info`, `service_type`, `appointment_date`, `appointment_time`, `message`, `status`, `created_at`) VALUES
(1, 'Erdem Yılmaz', '0532 111 2233', 'Renault Clio 2018', 'Periyodik Bakım', '2026-07-24', '10:00:00', 'Yağ ve filtre değişimi istiyorum.', 'tamamlandi', '2026-07-23 10:54:30'),
(2, 'Ayşe Turan', '0543 222 3344', 'Fiat Egea 2020', 'Klima', '2026-07-25', '14:30:00', NULL, 'beklemede', '2026-07-23 10:54:30');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int UNSIGNED NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `subject` varchar(150) DEFAULT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `rentals`
--

CREATE TABLE `rentals` (
  `id` int UNSIGNED NOT NULL,
  `vehicle_id` int UNSIGNED NOT NULL,
  `customer_name` varchar(120) NOT NULL,
  `customer_phone` varchar(30) NOT NULL,
  `customer_id_no` varchar(20) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `pickup_time` time DEFAULT NULL,
  `return_time` time DEFAULT NULL,
  `daily_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('rezervasyon','aktif','tamamlandi','iptal') NOT NULL DEFAULT 'rezervasyon',
  `notes` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `rentals`
--

INSERT INTO `rentals` (`id`, `vehicle_id`, `customer_name`, `customer_phone`, `customer_id_no`, `start_date`, `end_date`, `pickup_time`, `return_time`, `daily_price`, `total_price`, `status`, `notes`, `created_at`) VALUES
(1, 4, 'Burak Aydın', '0532 444 5566', NULL, '2026-07-21', '2026-07-26', NULL, NULL, 2650.00, 13250.00, 'iptal', NULL, '2026-07-23 10:54:30'),
(2, 1, 'Selin Kaya', '0543 555 6677', NULL, '2026-07-03', '2026-07-08', NULL, NULL, 1450.00, 7250.00, 'iptal', NULL, '2026-07-23 10:54:30'),
(3, 3, 'Caner Öztürk', '0532 666 7788', NULL, '2026-06-08', '2026-06-13', NULL, NULL, 2150.00, 10750.00, 'iptal', NULL, '2026-07-23 10:54:30'),
(4, 3, 'Salih Çakır', '43434343', NULL, '2026-07-24', '2026-07-29', '12:00:00', '12:00:00', 2000.00, 10000.00, 'iptal', NULL, '2026-07-23 11:26:47'),
(5, 3, 'casca csac', '233232', NULL, '2026-07-30', '2026-07-31', '10:00:00', '10:00:00', 3000.00, 3000.00, 'iptal', NULL, '2026-07-23 11:29:24'),
(6, 3, 'Salih Çakır', '433 343 44 44', NULL, '2026-08-09', '2026-08-15', NULL, NULL, 0.00, 2000.00, 'iptal', NULL, '2026-07-23 12:25:20'),
(7, 3, 'mehmet', '5415151', '1385655', '2026-08-24', '2026-08-29', '10:00:00', '10:00:00', 2000.00, 10000.00, 'iptal', 'test', '2026-07-23 12:25:51'),
(8, 2, 'wefewf', '433 343 44 44', NULL, '2026-07-15', '2026-07-15', '10:00:00', '10:00:00', 2500.00, 2500.00, 'iptal', 'eferfer', '2026-07-23 12:28:43'),
(9, 4, '32d23', 'd32d32', NULL, '2026-07-23', '2026-07-25', '10:00:00', '10:00:00', 2000.00, 4000.00, 'iptal', NULL, '2026-07-23 12:34:45');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `reservation_requests`
--

CREATE TABLE `reservation_requests` (
  `id` int UNSIGNED NOT NULL,
  `vehicle_id` int UNSIGNED DEFAULT NULL,
  `full_name` varchar(120) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `vehicle_text` varchar(150) DEFAULT NULL,
  `duration_text` varchar(40) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `pickup_time` time DEFAULT NULL,
  `return_time` time DEFAULT NULL,
  `message` text,
  `status` enum('yeni','incelendi','donusturuldu','iptal') NOT NULL DEFAULT 'yeni',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `reservation_requests`
--

INSERT INTO `reservation_requests` (`id`, `vehicle_id`, `full_name`, `phone`, `vehicle_text`, `duration_text`, `start_date`, `end_date`, `pickup_time`, `return_time`, `message`, `status`, `created_at`) VALUES
(3, 3, 'casca csac', '233232', 'Volkswagen Passat', NULL, '2026-07-30', '2026-07-31', '10:00:00', '10:00:00', NULL, 'donusturuldu', '2026-07-23 11:28:47'),
(4, 3, 'brtbrtb', '520520', 'Volkswagen Passat', NULL, '2026-08-01', '2026-08-06', '10:00:00', '10:00:00', NULL, 'donusturuldu', '2026-07-23 13:42:25');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int UNSIGNED NOT NULL,
  `brand` varchar(60) NOT NULL,
  `model` varchar(100) NOT NULL,
  `year` smallint UNSIGNED NOT NULL,
  `segment` enum('ekonomik','sedan','suv','hatchback') NOT NULL DEFAULT 'ekonomik',
  `fuel_type` enum('benzin','dizel','hibrit','elektrik','lpg') NOT NULL DEFAULT 'dizel',
  `gear_type` enum('manuel','otomatik') NOT NULL DEFAULT 'manuel',
  `seats` tinyint UNSIGNED NOT NULL DEFAULT '5',
  `luggage_liters` smallint UNSIGNED DEFAULT NULL,
  `has_ac` tinyint(1) NOT NULL DEFAULT '1',
  `daily_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `monthly_price` decimal(10,2) DEFAULT NULL,
  `description` text,
  `main_image` varchar(255) DEFAULT NULL,
  `status` enum('musait','kirada','bakimda','pasif') NOT NULL DEFAULT 'musait',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `vehicles`
--

INSERT INTO `vehicles` (`id`, `brand`, `model`, `year`, `segment`, `fuel_type`, `gear_type`, `seats`, `luggage_liters`, `has_ac`, `daily_price`, `monthly_price`, `description`, `main_image`, `status`, `is_featured`, `created_at`, `updated_at`) VALUES
(1, 'Renault', 'Clio', 2023, 'hatchback', 'dizel', 'manuel', 5, 300, 1, 2000.00, 40000.00, 'Şehir içi kullanım için ekonomik ve konforlu hatchback.', 'vehicles/bf163eac54a422a8.png', 'musait', 1, '2026-07-23 10:54:30', '2026-07-23 11:17:33'),
(2, 'Fiat', 'Egea', 2022, 'sedan', 'benzin', 'manuel', 5, 520, 1, 1350.00, 27000.00, 'Geniş bagaj hacmi ve düşük yakıt tüketimiyle öne çıkan sedan.', 'vehicles/fd5b1aea83ba0158.png', 'musait', 0, '2026-07-23 10:54:30', '2026-07-23 11:04:36'),
(3, 'Volkswagen', 'Passat', 2023, 'sedan', 'dizel', 'otomatik', 5, 530, 1, 2150.00, 43000.00, 'Konforlu iç mekanı ile uzun yol yolculukları için ideal.', 'vehicles/d4cb937b334882fa.jpg', 'musait', 1, '2026-07-23 10:54:30', '2026-07-23 14:00:36'),
(4, 'Hyundai', 'Tucson', 2023, 'suv', 'dizel', 'otomatik', 5, 616, 1, 2000.00, 53000.00, 'Geniş iç hacmi ve yüksek sürüş konforuyla aile SUV\'u.', 'vehicles/hyundai-tucson.jpg', 'musait', 1, '2026-07-23 10:54:30', '2026-07-23 14:00:42');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `vehicle_gallery`
--

CREATE TABLE `vehicle_gallery` (
  `id` int UNSIGNED NOT NULL,
  `vehicle_id` int UNSIGNED NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `sort_order` smallint UNSIGNED NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `vehicle_gallery`
--

INSERT INTO `vehicle_gallery` (`id`, `vehicle_id`, `image_path`, `sort_order`, `created_at`) VALUES
(1, 1, 'gallery/7d8a9ca17a782f17.png', 0, '2026-07-23 10:58:15'),
(2, 1, 'gallery/137239989685b66b.png', 1, '2026-07-23 10:58:15'),
(3, 1, 'gallery/c162736bbd6ac7c8.jpg', 2, '2026-07-23 10:58:15'),
(4, 2, 'gallery/d090f9476e31a117.png', 0, '2026-07-23 11:04:36'),
(5, 2, 'gallery/260f7c1b336164c4.jpg', 1, '2026-07-23 11:04:36'),
(6, 3, 'gallery/89eb6954732a75f1.png', 0, '2026-07-23 11:04:50'),
(7, 3, 'gallery/5d7a26d4c21c7762.png', 1, '2026-07-23 11:04:50'),
(8, 3, 'gallery/8ea29363bb54de3a.jpg', 2, '2026-07-23 11:04:50');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_username` (`username`);

--
-- Tablo için indeksler `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_date` (`appointment_date`);

--
-- Tablo için indeksler `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_vehicle` (`vehicle_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_vehicle_dates` (`vehicle_id`,`start_date`,`end_date`);

--
-- Tablo için indeksler `reservation_requests`
--
ALTER TABLE `reservation_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_vehicle` (`vehicle_id`);

--
-- Tablo için indeksler `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_segment` (`segment`);

--
-- Tablo için indeksler `vehicle_gallery`
--
ALTER TABLE `vehicle_gallery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_vehicle` (`vehicle_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Tablo için AUTO_INCREMENT değeri `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `rentals`
--
ALTER TABLE `rentals`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Tablo için AUTO_INCREMENT değeri `reservation_requests`
--
ALTER TABLE `reservation_requests`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `vehicle_gallery`
--
ALTER TABLE `vehicle_gallery`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `fk_rentals_vehicle` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE RESTRICT;

--
-- Tablo kısıtlamaları `reservation_requests`
--
ALTER TABLE `reservation_requests`
  ADD CONSTRAINT `fk_reservation_vehicle` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE SET NULL;

--
-- Tablo kısıtlamaları `vehicle_gallery`
--
ALTER TABLE `vehicle_gallery`
  ADD CONSTRAINT `fk_gallery_vehicle` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- Galeri Kategorileri Tablosu
CREATE TABLE IF NOT EXISTS `gallery_categories` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL UNIQUE,
  `description` text,
  `display_order` smallint UNSIGNED DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Galeri Resimleri Tablosu
CREATE TABLE IF NOT EXISTS `gallery_images` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` int UNSIGNED NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `thumbnail_path` varchar(255),
  `webp_path` varchar(255),
  `title` varchar(255),
  `alt_text` varchar(255),
  `description` text,
  `file_size` int UNSIGNED DEFAULT 0,
  `display_order` smallint UNSIGNED DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `view_count` int UNSIGNED DEFAULT 0,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `is_active` (`is_active`),
  KEY `display_order` (`display_order`),
  FOREIGN KEY (`category_id`) REFERENCES `gallery_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Varsayılan Kategorileri Ekle
INSERT INTO `gallery_categories` (`name`, `slug`, `description`, `display_order`) VALUES
('Motor', 'motor', 'Motor bakım ve onarım işlemleri', 1),
('Kaporta & Boya', 'kaporta-boya', 'Kaporta çektirim ve boya işlemleri', 2),
('Fren', 'fren', 'Fren sistemi bakım ve onarımı', 3),
('Araç Teslim', 'arac-teslim', 'Bakım sonrası araç teslim fotoğrafları', 4),
('Atölye', 'atolye', 'Atölye tesisatı ve ekipmanları', 5);
--- Gallery tables appended ---

CREATE TABLE IF NOT EXISTS gallery_categories (
  id int UNSIGNED NOT NULL AUTO_INCREMENT,
  name varchar(100) NOT NULL,
  slug varchar(100) NOT NULL UNIQUE,
  description text,
  display_order smallint UNSIGNED DEFAULT 0,
  is_active tinyint(1) DEFAULT 1,
  created_at datetime DEFAULT CURRENT_TIMESTAMP,
  updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY slug (slug),
  KEY is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS gallery_images (
  id int UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id int UNSIGNED NOT NULL,
  image_name varchar(255) NOT NULL,
  image_path varchar(255) NOT NULL,
  thumbnail_path varchar(255),
  webp_path varchar(255),
  title varchar(255),
  alt_text varchar(255),
  description text,
  file_size int UNSIGNED DEFAULT 0,
  display_order smallint UNSIGNED DEFAULT 0,
  is_active tinyint(1) DEFAULT 1,
  view_count int UNSIGNED DEFAULT 0,
  created_at datetime DEFAULT CURRENT_TIMESTAMP,
  updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY category_id (category_id),
  KEY is_active (is_active),
  KEY display_order (display_order),
  FOREIGN KEY (category_id) REFERENCES gallery_categories (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT IGNORE INTO gallery_categories (name, slug, description, display_order) VALUES
('Motor', 'motor', 'Motor bakim ve onarim islemleri', 1),
('Kaporta & Boya', 'kaporta-boya', 'Kaporta cektirim ve boya islemleri', 2),
('Fren', 'fren', 'Fren sistemi bakim ve onarimi', 3),
('Arac Teslim', 'arac-teslim', 'Bakim sonrasi arac teslim fotograflari', 4),
('Atolye', 'atolye', 'Atolye tesisati ve ekipmanlari', 5);


<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
try {
    $pdo = db();
    $categories = $pdo->query("SELECT id, name, slug, description FROM gallery_categories WHERE is_active = 1 ORDER BY display_order ASC")->fetchAll();
    $images = $pdo->query("
        SELECT gi.id, gi.category_id, gi.image_path, gi.webp_path, gi.thumbnail_path,
               gi.title, gi.alt_text, gi.description, gi.display_order,
               gc.name AS category_name, gc.slug AS category_slug
        FROM gallery_images gi
        JOIN gallery_categories gc ON gi.category_id = gc.id
        WHERE gi.is_active = 1 AND gc.is_active = 1
        ORDER BY gi.display_order ASC, gi.created_at DESC
    ")->fetchAll();
    echo json_encode([
        'success' => true,
        'categories' => array_map(function($c){ return ['id'=>(int)$c['id'],'name'=>$c['name'],'slug'=>$c['slug'],'description'=>$c['description']]; }, $categories),
        'images' => array_map(function($img){ return ['id'=>(int)$img['id'],'category_id'=>(int)$img['category_id'],'category_name'=>$img['category_name'],'category_slug'=>$img['category_slug'],'title'=>$img['title'],'alt_text'=>$img['alt_text'],'image_path'=>$img['image_path'],'webp_path'=>$img['webp_path'],'thumbnail_path'=>$img['thumbnail_path'],'display_order'=>(int)$img['display_order']]; }, $images),
    ], JSON_UNESCAPED_SLASHES);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Veri yukleme hatasi']);
}

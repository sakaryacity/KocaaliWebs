<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/availability.php';
header('Content-Type: application/json; charset=utf-8');
function respond(int $code, array $data): void { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }
$input = array_merge($_GET, $_POST);
if (isset($_SERVER['CONTENT_TYPE']) && stripos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) { $input = array_merge($input, json_decode(file_get_contents('php://input'), true) ?? []); }
$vehicleId = isset($input['vehicle_id']) && ctype_digit((string)$input['vehicle_id']) ? (int)$input['vehicle_id'] : null;
$startDate = $input['start_date'] ?? ''; $endDate = $input['end_date'] ?? '';
if (!$vehicleId) respond(400, ['success'=>false,'message'=>'Arac ID belirtilmedi.']);
$validDate = fn($d) => $d && DateTime::createFromFormat('Y-m-d', $d) !== false;
if (!$validDate($startDate) || !$validDate($endDate)) respond(400, ['success'=>false,'message'=>'Gecerli tarihler belirtilmedi.']);
if (strtotime($endDate) < strtotime($startDate)) respond(400, ['success'=>false,'message'=>'Bitis tarihi baslangictan once olamaz.']);
try {
    $report = build_availability_report(db(), $vehicleId, $startDate, $endDate);
    respond(200, array_merge(['success'=>true], $report));
} catch (Throwable $e) { respond(500, ['success'=>false,'message'=>'Bir hata olustu.']); }

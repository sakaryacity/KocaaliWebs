<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,viewport-fit=cover">
<meta name="description" content="Mas-Car Auto bakım onarım galerisi. Kaporta, boya, mekanik ve elektrik hizmetlerimizden örnek çalışma fotoğrafları.">
<meta name="keywords" content="oto servis galeri, bakım onarım fotoğrafları, kocaali oto galeri, mascar auto">
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="https://www.mascarauto.com.tr/gallery.php">
<meta property="og:title" content="Galeri | Mas-Car Auto Özel Servis Kocaali">
<meta property="og:description" content="Bakım, onarım ve detaylandırma çalışmalarımızdan fotoğraflar.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.mascarauto.com.tr/gallery.php">
<meta property="og:site_name" content="Mas-Car Auto">
<meta property="og:locale" content="tr_TR">
<title>Galeri | Mas-Car Auto Özel Servis Kocaali</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="css/style.css">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {"@type":"ListItem","position":1,"name":"Ana Sayfa","item":"https://www.mascarauto.com.tr/"},
    {"@type":"ListItem","position":2,"name":"Galeri","item":"https://www.mascarauto.com.tr/gallery.php"}
  ]
}
</script>
</head>
<body>
<a href="#main-content" class="skip-link">İçeriğe geç</a>
<div id="loading-screen" aria-hidden="true"><div class="loader-mark">MAS-CAR AUTO<div class="loader-bar"><span></span></div></div></div>

<header class="mc-header">
  <nav class="mc-nav container">
    <a class="mc-brand navbar-brand" href="index.php"><span class="brand-mark">M</span>Mas-Car <span class="hide-sm d-none d-sm-inline">Auto</span></a>
    <button class="nav-toggle navbar-toggler" id="navToggle" aria-label="Menü"><i class="bi bi-list"></i></button>
    <ul class="nav-links" id="navLinks">
      <li><a href="index.php" class="nav-link">Ana Sayfa</a></li>
      <li><a href="service.php" class="nav-link">Hizmetler</a></li>
      <li><a href="gallery.php" class="nav-link active">Galeri</a></li>
      <li><a href="rent.php" class="nav-link">Araç Kiralama</a></li>
      <li><a href="about.html" class="nav-link">Hakkımızda</a></li>
      <li><a href="contact.html" class="nav-link">İletişim</a></li>
    </ul>
    <div class="header-actions">
      <a href="tel:+905424495454" class="icon-btn" aria-label="Ara"><i class="bi bi-telephone-fill"></i></a>
      <a href="contact.html" class="btn btn-mc-primary btn-sm-pill">Randevu Al</a>
    </div>
  </nav>
</header>

<!-- Offcanvas Mobile Menu -->
<div class="offcanvas-overlay"></div>
<div class="offcanvas-panel">
  <div class="offcanvas-header">
    <a href="index.php" class="navbar-brand" style="color:var(--mc-black)"><span class="brand-mark">M</span>Mas-Car Auto</a>
    <button class="offcanvas-close" aria-label="Kapat"><i class="bi bi-x-lg"></i></button>
  </div>
  <nav class="offcanvas-nav">
    <a href="index.php">Ana Sayfa</a>
    <a href="service.php">Hizmetler</a>
    <a href="gallery.php" class="active">Galeri</a>
    <a href="rent.php">Araç Kiralama</a>
    <a href="about.html">Hakkımızda</a>
    <a href="contact.html">İletişim</a>
  </nav>
  <div style="margin-top:1.5rem; display:flex; flex-direction:column; gap:.75rem;">
    <a href="tel:+905424495454" class="btn btn-mc-outline w-100"><i class="bi bi-telephone-fill me-2"></i>0 (542) 449 5454</a>
    <a href="https://wa.me/905424495454" target="_blank" rel="noopener" class="btn btn-mc-primary w-100"><i class="bi bi-whatsapp me-2"></i>WhatsApp</a>
  </div>
</div>

<div class="page-hero">
  <div class="container">
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="index.php">Ana Sayfa</a></li><li class="breadcrumb-item active" aria-current="page">Galeri</li></ol></nav>
    <h1 class="display-5">Galeri</h1>
  </div>
</div>

<main id="main-content">
<section>
  <div class="container">
    <div class="row justify-content-center text-center mb-4">
      <div class="col-lg-7 reveal">
        <span class="eyebrow justify-content-center">Atölyeden</span>
        <h2 class="section-title">Bakım Onarım Çalışmalarımız</h2>
        <p class="section-lead mx-auto">Hizmet verdiğimiz tüm çalışmalardan örnek fotoğraflar. Kalitemizi görsel olarak inceleyebilirsiniz.</p>
      </div>
    </div>

    <div class="gallery-filters reveal" id="galleryFilters">
      <button class="filter-chip active" data-filter="all">Tümü</button>
    </div>

    <div class="gallery-grid" id="galleryGrid" data-ajax="true">
      <div class="gallery-loading">
        <div class="spinner"></div>
        <p class="text-muted">Galeri yükleniyor...</p>
      </div>
    </div>
  </div>
</section>

  <!-- CTA -->
  <section class="bg-fog">
    <div class="container">
      <div class="cta-box reveal">
        <h2 class="section-title" style="color:#fff;">Aracınıza Bakım İhtiyacı mı Var?</h2>
        <p style="color:rgba(255,255,255,.65);max-width:560px;margin:1rem auto 2rem;">Hizmetlerimizden memnun kaldığınızı görmek isteriz. Hemen randevu alarak aracınıza profesyonel bakım yaptırın.</p>
        <div style="display:flex;gap:.75rem;justify-content:center;flex-wrap:wrap;">
          <a href="contact.html" class="btn btn-mc-primary"><i class="bi bi-calendar-check me-2"></i>Randevu Al</a>
          <a href="tel:+905424495454" class="btn btn-mc-outline-light"><i class="bi bi-telephone-fill me-2"></i>Bizi Ara</a>
        </div>
      </div>
    </div>
  </section>
</main>

<!-- Lightbox -->
<div class="mc-lightbox" id="mc-lightbox">
  <button class="lb-close" aria-label="Kapat"><i class="bi bi-x-lg"></i></button>
  <button class="lb-nav lb-prev" aria-label="Önceki"><i class="bi bi-chevron-left"></i></button>
  <button class="lb-nav lb-next" aria-label="Sonraki"><i class="bi bi-chevron-right"></i></button>
  <img src="" alt="">
</div>

<footer class="mc-footer">
  <div class="container">
    <div class="footer-grid row g-5">
      <div class="footer-col col-lg-4">
        <a href="index.php" class="mc-brand navbar-brand mb-3 d-inline-flex"><span class="brand-mark">M</span>Mas-Car Auto</a>
        <p>Kocaali'de araç kiralama ve özel oto servis alanında güvenilir çözüm ortağınız.</p>
        <div class="footer-social"><a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a><a href="#" aria-label="Facebook"><i class="bi bi-facebook"></i></a><a href="https://wa.me/905424495454" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a></div>
      </div>
      <div class="footer-col col-lg-2 col-md-4 col-6">
        <h4>Hızlı Menü</h4>
        <a href="index.php">Ana Sayfa</a>
        <a href="service.php">Hizmetler</a>
        <a href="rent.php">Araç Kiralama</a>
        <a href="gallery.php">Galeri</a>
      </div>
      <div class="footer-col col-lg-2 col-md-4 col-6">
        <h4>Kurumsal</h4>
        <a href="about.html">Hakkımızda</a>
        <a href="faq.html">S.S.S.</a>
        <a href="contact.html">İletişim</a>
      </div>
      <div class="footer-col col-lg-4 col-md-4">
        <h4>İletişim</h4>
        <p><i class="bi bi-geo-alt-fill"></i> Yayla Mah. Gaffar Okkan Cad. No:1, Kocaali/Sakarya</p>
        <p><i class="bi bi-telephone-fill"></i> <a href="tel:+905424495454">0 (542) 449 5454</a></p>
        <p><i class="bi bi-envelope-fill"></i> <a href="mailto:info@mascarauto.com.tr">info@mascarauto.com.tr</a></p>
        <p><i class="bi bi-clock-fill"></i> Pzt-Cmt: 08:30-19:00</p>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <span data-current-year></span> Mas-Car Auto Özel Servis Kocaali. Tüm hakları saklıdır.</span>
    </div>
  </div>
</footer>

<div class="floating-actions">
  <a href="#" class="fab fab-top" id="scrollTopBtn" aria-label="Yukarı çık"><i class="bi bi-arrow-up"></i></a>
  <a href="tel:+905424495454" class="fab fab-phone" aria-label="Ara"><i class="bi bi-telephone-fill"></i></a>
  <a href="https://wa.me/905424495454" target="_blank" rel="noopener" class="fab fab-whatsapp" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a>
</div>

<div class="mc-cookie" id="mc-cookie">
  <div class="cookie-content" style="display:flex;align-items:flex-start;gap:.75rem;">
    <i class="bi bi-shield-lock-fill" style="color:var(--mc-red);font-size:1.2rem;flex-shrink:0;margin-top:.15rem;"></i>
    <p>Sitemizde çerezler kullanılmaktadır. KVKK kapsamında <a href="javascript:void(0)" onclick="alert('Kişisel Verilerin Korunması Kanunu (KVKK) kapsamında kişisel verileriniz, site kullanımınızı iyileştirmek ve yasal yükümlülükleri yerine getirmek amacıyla işlenmektedir. Detaylı bilgi için bizimle iletişime geçebilirsiniz.')">açıklama</a> için tıklayın.</p>
  </div>
  <button class="btn btn-mc-primary btn-sm-pill" data-cookie-accept>Kabul Et</button>
</div>

<script src="js/main.js" defer></script>
</body>
</html>

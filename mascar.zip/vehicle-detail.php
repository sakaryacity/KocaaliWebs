<?php
require_once __DIR__ . '/config.php';

$id = isset($_GET['id']) && ctype_digit($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = db()->prepare('SELECT * FROM vehicles WHERE id = ?');
$stmt->execute([$id]);
$v = $stmt->fetch();

if (!$v) {
    header('Location: rent.php');
    exit;
}

$g = db()->prepare('SELECT * FROM vehicle_gallery WHERE vehicle_id = ? ORDER BY sort_order, id');
$g->execute([$id]);
$gallery = $g->fetchAll();

$mainImg = $v['main_image'] ? 'uploads/' . h($v['main_image']) : 'https://images.unsplash.com/photo-1493238792000-8113da705763?auto=format&fit=crop&w=1200&q=85';
$title = h($v['brand'] . ' ' . $v['model']);
$segmentLabels = ['ekonomik'=>'Ekonomik','sedan'=>'Sedan','suv'=>'SUV','hatchback'=>'Hatchback'];
$statusLabels  = ['musait'=>'Müsait','kirada'=>'Kirada','bakimda'=>'Bakımda','pasif'=>'Pasif'];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,viewport-fit=cover">
<meta name="description" content="<?= $title ?> kiralık <?= h($segmentLabels[$v['segment']] ?? '') ?> detayları, teknik özellikleri ve günlük/aylık fiyatları. Kocaali'de Mas-Car Auto güvencesiyle.">
<meta name="keywords" content="<?= $title ?> kiralık, <?= h($v['brand']) ?> <?= h($v['model']) ?> kiralama, kocaali rent a car">
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="https://www.mascarauto.com.tr/vehicle-detail.php?id=<?= (int)$v['id'] ?>">
<meta property="og:title" content="<?= $title ?> Kiralama | Mas-Car Auto">
<meta property="og:description" content="<?= $title ?> kiralık araç detayları. Günlük ve aylık fiyatlar.">
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.mascarauto.com.tr/vehicle-detail.php?id=<?= (int)$v['id'] ?>">
<meta property="og:site_name" content="Mas-Car Auto">
<meta property="og:locale" content="tr_TR">
<title><?= $title ?> Kiralama | Mas-Car Auto</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="css/style.css">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        {"@type":"ListItem","position":1,"name":"Ana Sayfa","item":"https://www.mascarauto.com.tr/"},
        {"@type":"ListItem","position":2,"name":"Araç Kiralama","item":"https://www.mascarauto.com.tr/rent.php"},
        {"@type":"ListItem","position":3,"name":"<?= $title ?>","item":"https://www.mascarauto.com.tr/vehicle-detail.php?id=<?= (int)$v['id'] ?>"}
      ]
    },
    {
      "@type": "Car",
      "name": "<?= $title ?>",
      "brand": "<?= h($v['brand']) ?>",
      "model": "<?= h($v['model']) ?>",
      "vehicleModelDate": "<?= (int)$v['year'] ?>",
      "fuelType": "<?= h($v['fuel_type']) ?>",
      "vehicleTransmission": "<?= h($v['gear_type']) ?>",
      "seatingCapacity": "<?= (int)$v['seats'] ?>",
      "offers": {
        "@type": "Offer",
        "priceCurrency": "TRY",
        "price": "<?= (float)$v['daily_price'] ?>",
        "availability": "<?= $v['status']==='musait' ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock' ?>"
      }
    }
  ]
}
</script>
</head>
<body>
<a href="#main-content" class="skip-link">İçeriğe geç</a>
<div id="loading-screen" aria-hidden="true"><div class="loader-mark">MAS-CAR AUTO<div class="loader-bar"><span></span></div></div></div>

<header class="mc-header">
  <nav class="mc-nav container">
    <a class="mc-brand navbar-brand" href="index.php"><span class="brand-mark">M</span>Mas-Car <span class="hide-sm d-none d-sm-inline">Auto</span></a>
    <button class="nav-toggle navbar-toggler" id="navToggle" aria-label="Menü"><i class="bi bi-list"></i></button>
    <ul class="nav-links" id="navLinks">
      <li><a href="index.php" class="nav-link">Ana Sayfa</a></li>
      <li><a href="service.php" class="nav-link">Hizmetler</a></li>
      <li><a href="gallery.php" class="nav-link">Galeri</a></li>
      <li><a href="rent.php" class="nav-link active">Araç Kiralama</a></li>
      <li><a href="about.html" class="nav-link">Hakkımızda</a></li>
      <li><a href="contact.html" class="nav-link">İletişim</a></li>
    </ul>
    <div class="header-actions">
      <a href="tel:+905424495454" class="icon-btn" aria-label="Ara"><i class="bi bi-telephone-fill"></i></a>
      <a href="contact.html" class="btn btn-mc-primary btn-sm-pill">Randevu Al</a>
    </div>
  </nav>
</header>

<!-- Offcanvas Mobile Menu -->
<div class="offcanvas-overlay"></div>
<div class="offcanvas-panel">
  <div class="offcanvas-header">
    <a href="index.php" class="navbar-brand" style="color:var(--mc-black)"><span class="brand-mark">M</span>Mas-Car Auto</a>
    <button class="offcanvas-close" aria-label="Kapat"><i class="bi bi-x-lg"></i></button>
  </div>
  <nav class="offcanvas-nav">
    <a href="index.php">Ana Sayfa</a>
    <a href="service.php">Hizmetler</a>
    <a href="gallery.php">Galeri</a>
    <a href="rent.php" class="active">Araç Kiralama</a>
    <a href="about.html">Hakkımızda</a>
    <a href="contact.html">İletişim</a>
  </nav>
  <div style="margin-top:1.5rem; display:flex; flex-direction:column; gap:.75rem;">
    <a href="tel:+905424495454" class="btn btn-mc-outline w-100"><i class="bi bi-telephone-fill me-2"></i>0 (542) 449 5454</a>
    <a href="https://wa.me/905424495454" target="_blank" rel="noopener" class="btn btn-mc-primary w-100"><i class="bi bi-whatsapp me-2"></i>WhatsApp</a>
  </div>
</div>

<div class="page-hero" style="padding-bottom:2rem;">
  <div class="container">
    <nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="index.php">Ana Sayfa</a></li><li class="breadcrumb-item"><a href="rent.php">Araç Kiralama</a></li><li class="breadcrumb-item active" aria-current="page"><?= $title ?></li></ol></nav>
    <h1 class="display-6"><?= $title ?></h1>
  </div>
</div>

<main id="main-content" style="padding-top:2rem; padding-bottom:4rem;">
<section>
  <div class="container">
    <div class="row g-5">

      <!-- SOL: GALERİ & DETAY -->
      <div class="col-lg-7">

        <!-- Galeri -->
        <div class="mb-4 reveal">
          <div class="shadow rounded-4 overflow-hidden mb-3">
            <img id="mainGalleryImage" src="<?= $mainImg ?>" alt="<?= $title ?> kiralık araç" class="gallery-main-img">
          </div>
          <?php if ($gallery || $mainImg): ?>
          <div class="thumbnail-wrapper" id="thumbnailContainer">
            <img src="<?= $mainImg ?>" onclick="changeMainImage(this)" class="thumbnail-img active" alt="<?= $title ?> Görsel 1">
            <?php foreach ($gallery as $index => $img): ?>
              <img src="uploads/<?= h($img['image_path']) ?>" onclick="changeMainImage(this)" class="thumbnail-img" alt="<?= $title ?> Görsel <?= $index + 2 ?>">
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        </div>

        <!-- Araç Hakkında -->
        <h2 class="h4 fw-bold mt-5 mb-3 reveal">Araç Hakkında</h2>
        <p class="text-muted reveal" style="line-height:1.8;">
          <?= $v['description'] ? nl2br(h($v['description'])) : $title . ', düzenli bakımdan geçmiş, temiz ve sigortalı halde günlük veya aylık kiralama seçenekleriyle hizmetinizdedir. Mas-Car Auto güvencesiyle güvenle kiralayabilirsiniz.' ?>
        </p>

        <!-- Teknik Özellikler -->
        <h2 class="h4 fw-bold mt-5 mb-4 reveal">Teknik Özellikler</h2>
        <div class="row g-3 reveal">
          <div class="col-6 col-md-3">
            <div class="spec-card">
              <div class="spec-icon"><i class="bi bi-calendar3"></i></div>
              <div class="fw-bold small"><?= (int)$v['year'] ?></div>
              <div class="text-muted" style="font-size:.8rem;">Model Yılı</div>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="spec-card">
              <div class="spec-icon"><i class="bi bi-fuel-pump"></i></div>
              <div class="fw-bold small"><?= h(ucfirst($v['fuel_type'])) ?></div>
              <div class="text-muted" style="font-size:.8rem;">Yakıt Tipi</div>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="spec-card">
              <div class="spec-icon"><i class="bi bi-gear"></i></div>
              <div class="fw-bold small"><?= h(ucfirst($v['gear_type'])) ?></div>
              <div class="text-muted" style="font-size:.8rem;">Vites</div>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="spec-card">
              <div class="spec-icon"><i class="bi bi-people"></i></div>
              <div class="fw-bold small"><?= (int)$v['seats'] ?> Kişi</div>
              <div class="text-muted" style="font-size:.8rem;">Koltuk Sayısı</div>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="spec-card">
              <div class="spec-icon"><i class="bi bi-car-front"></i></div>
              <div class="fw-bold small"><?= h(ucfirst($segmentLabels[$v['segment']] ?? $v['segment'])) ?></div>
              <div class="text-muted" style="font-size:.8rem;">Segment</div>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="spec-card">
              <div class="spec-icon"><i class="bi bi-check-circle-fill" style="color:<?= $v['status']==='musait'?'#4ade80':'#ef4444' ?>"></i></div>
              <div class="fw-bold small"><?= h($statusLabels[$v['status']] ?? ucfirst($v['status'])) ?></div>
              <div class="text-muted" style="font-size:.8rem;">Durum</div>
            </div>
          </div>
          <?php if ($v['has_ac'] ?? false): ?>
          <div class="col-6 col-md-3">
            <div class="spec-card">
              <div class="spec-icon"><i class="bi bi-snow"></i></div>
              <div class="fw-bold small">Var</div>
              <div class="text-muted" style="font-size:.8rem;">Klima</div>
            </div>
          </div>
          <?php endif; ?>
          <?php if ($v['engine_cc'] ?? false): ?>
          <div class="col-6 col-md-3">
            <div class="spec-card">
              <div class="spec-icon"><i class="bi bi-speedometer2"></i></div>
              <div class="fw-bold small"><?= (int)$v['engine_cc'] ?> cc</div>
              <div class="text-muted" style="font-size:.8rem;">Motor</div>
            </div>
          </div>
          <?php endif; ?>
        </div>

        <!-- Özellikler -->
        <?php if ($v['features'] ?? false): ?>
        <h2 class="h4 fw-bold mt-5 mb-3 reveal">Donanım & Özellikler</h2>
        <div class="row g-2 reveal">
          <?php foreach (explode(',', $v['features']) as $feat): $feat = trim($feat); if ($feat): ?>
          <div class="col-md-6">
            <div class="d-flex align-items-center gap-2" style="padding:.5rem 0;">
              <i class="bi bi-check-circle-fill" style="color:var(--mc-red);"></i>
              <span class="small text-muted"><?= h($feat) ?></span>
            </div>
          </div>
          <?php endif; endforeach; ?>
        </div>
        <?php endif; ?>

      </div>

      <!-- SAĞ: REZERVASYON SIDEBAR -->
      <div class="col-lg-5">
        <div class="sticky-sidebar">

          <!-- Fiyat Kartı -->
          <div class="reservation-card mb-4 reveal">
            <div class="justify-content-between align-items-center" style="display:flex; margin-bottom:1.5rem;">
              <div>
                <h2 class="h4 mb-0"><?= $title ?></h2>
                <span class="text-muted small"><?= h(ucfirst($segmentLabels[$v['segment']] ?? '')) ?> · <?= (int)$v['year'] ?></span>
              </div>
              <span class="vehicle-badge" style="position:static; background:<?= $v['status']==='musait' ? 'var(--mc-red)' : 'var(--mc-anthracite)' ?>;"><?= h($statusLabels[$v['status']] ?? ucfirst($v['status'])) ?></span>
            </div>
            <div class="mb-4">
              <div class="vehicle-price" style="font-size:2rem;"><?= number_format((float)$v['daily_price'], 0, ',', '.') ?> ₺ <small>/ günlük</small></div>
              <?php if ($v['monthly_price'] ?? false): ?>
              <div class="text-muted mt-1" style="font-size:.95rem;">Aylık: <strong style="color:var(--mc-black);"><?= number_format((float)$v['monthly_price'], 0, ',', '.') ?> ₺</strong></div>
              <?php endif; ?>
            </div>
            <div class="vehicle-specs mb-3" style="font-size:.88rem;">
              <span><i class="bi bi-fuel-pump"></i><?= h(ucfirst($v['fuel_type'])) ?></span>
              <span><i class="bi bi-gear"></i><?= h(ucfirst($v['gear_type'])) ?></span>
              <span><i class="bi bi-people"></i><?= (int)$v['seats'] ?> Kişi</span>
            </div>
            <a href="https://wa.me/905424495454?text=<?= urlencode('Merhaba, ' . $title . ' araç kiralamak istiyorum.') ?>" target="_blank" rel="noopener" class="btn btn-mc-primary w-100 mb-2"><i class="bi bi-whatsapp me-2"></i>WhatsApp ile Kirala</a>
            <a href="tel:+905424495454" class="btn btn-mc-outline w-100"><i class="bi bi-telephone-fill me-2"></i>0 (542) 449 5454</a>
          </div>

          <!-- Müsaitlik Kontrolü -->
          <div class="reservation-card mb-4 reveal">
            <h3 class="h5 fw-bold mb-3"><i class="bi bi-calendar-check me-2" style="color:var(--mc-red);"></i>Müsaitlik Kontrolü</h3>
            <form class="row g-3" id="checkAvailabilityForm" action="check-availability.php" method="post">
              <div class="col-6">
                <label class="form-label small">Alış Tarihi</label>
                <input type="date" name="start_date" class="form-control" required>
              </div>
              <div class="col-6">
                <label class="form-label small">Teslim Tarihi</label>
                <input type="date" name="end_date" class="form-control" required>
              </div>
              <input type="hidden" name="vehicle_id" value="<?= (int)$v['id'] ?>">
              <div class="col-12">
                <button type="submit" class="btn btn-mc-outline btn-sm-pill w-100"><i class="bi bi-search me-2"></i>Müsaitlik Sorgula</button>
              </div>
              <div class="col-12" id="availabilityResult"></div>
            </form>
          </div>

          <!-- Hızlı Rezervasyon -->
          <div class="reservation-card reveal">
            <h3 class="h5 fw-bold mb-3"><i class="bi bi-pencil-square me-2" style="color:var(--mc-red);"></i>Hızlı Rezervasyon</h3>
            <form class="row g-3 needs-validation" novalidate data-mc-form="reservation-detail" action="process-reservation.php" method="post">
              <input type="hidden" name="vehicle_id" value="<?= (int)$v['id'] ?>">
              <input type="hidden" name="vehicle" value="<?= $title ?>">
              <div class="col-12">
                <label class="form-label small">Ad Soyad</label>
                <input type="text" name="full_name" class="form-control" required>
                <div class="invalid-feedback">Zorunlu alan.</div>
              </div>
              <div class="col-12">
                <label class="form-label small">Telefon</label>
                <input type="tel" name="phone" class="form-control" required>
                <div class="invalid-feedback">Zorunlu alan.</div>
              </div>
              <div class="col-6">
                <label class="form-label small">Alış Tarihi</label>
                <input type="date" name="start_date" class="form-control" required>
                <div class="invalid-feedback">Zorunlu alan.</div>
              </div>
              <div class="col-6">
                <label class="form-label small">Teslim Tarihi</label>
                <input type="date" name="end_date" class="form-control" required>
                <div class="invalid-feedback">Zorunlu alan.</div>
              </div>
              <div class="col-12">
                <label class="form-label small">Not (opsiyonel)</label>
                <textarea class="form-control" name="message" rows="2"></textarea>
              </div>
              <div class="col-12">
                <button type="submit" class="btn btn-mc-primary w-100"><i class="bi bi-check-lg me-2"></i>Rezervasyon Talep Et</button>
              </div>
            </form>
          </div>

        </div>
      </div>

    </div>
  </div>
</section>
</main>

<script>
function changeMainImage(thumb) {
  const main = document.getElementById('mainGalleryImage');
  if (!main || !thumb) return;
  main.src = thumb.src;
  main.alt = thumb.alt;
  document.querySelectorAll('.thumbnail-img').forEach(t => t.classList.remove('active'));
  thumb.classList.add('active');
}

// Availability check form
const avForm = document.getElementById('checkAvailabilityForm');
if (avForm) {
  avForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    const resultDiv = document.getElementById('availabilityResult');
    const btn = avForm.querySelector('button[type="submit"]');
    const origText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border"></span> Kontrol ediliyor...';
    resultDiv.innerHTML = '';

    try {
      const formData = new FormData(avForm);
      const resp = await fetch(avForm.action, { method: 'POST', body: formData });
      const data = await resp.json();
      if (data && data.success) {
        resultDiv.innerHTML = '<div style="padding:.75rem;border-radius:10px;background:#f0fdf4;color:#166534;font-size:.9rem;margin-top:.5rem;"><i class="bi bi-check-circle-fill me-2"></i>' + (data.message || 'Araç belirtilen tarihlerde müsait!') + '</div>';
      } else {
        resultDiv.innerHTML = '<div style="padding:.75rem;border-radius:10px;background:#fef2f2;color:#991b1b;font-size:.9rem;margin-top:.5rem;"><i class="bi bi-exclamation-circle-fill me-2"></i>' + (data && data.message ? data.message : 'Araç belirtilen tarihlerde müsait değil.') + '</div>';
      }
    } catch(err) {
      resultDiv.innerHTML = '<div style="padding:.75rem;border-radius:10px;background:#fef2f2;color:#991b1b;font-size:.9rem;margin-top:.5rem;"><i class="bi bi-exclamation-circle-fill me-2"></i>Bağlantı hatası. Lütfen tekrar deneyin.</div>';
    } finally {
      btn.disabled = false;
      btn.innerHTML = origText;
    }
  });
}
</script>

<footer class="mc-footer">
  <div class="container">
    <div class="footer-grid row g-5">
      <div class="footer-col col-lg-4">
        <a href="index.php" class="mc-brand navbar-brand mb-3 d-inline-flex"><span class="brand-mark">M</span>Mas-Car Auto</a>
        <p>Kocaali'de araç kiralama ve özel oto servis alanında güvenilir çözüm ortağınız.</p>
        <div class="footer-social"><a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a><a href="#" aria-label="Facebook"><i class="bi bi-facebook"></i></a><a href="https://wa.me/905424495454" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a></div>
      </div>
      <div class="footer-col col-lg-2 col-md-4 col-6">
        <h4>Hızlı Menü</h4>
        <a href="index.php">Ana Sayfa</a>
        <a href="service.php">Hizmetler</a>
        <a href="rent.php">Araç Kiralama</a>
        <a href="gallery.php">Galeri</a>
      </div>
      <div class="footer-col col-lg-2 col-md-4 col-6">
        <h4>Kurumsal</h4>
        <a href="about.html">Hakkımızda</a>
        <a href="faq.html">S.S.S.</a>
        <a href="contact.html">İletişim</a>
      </div>
      <div class="footer-col col-lg-4 col-md-4">
        <h4>İletişim</h4>
        <p><i class="bi bi-geo-alt-fill"></i> Yayla Mah. Gaffar Okkan Cad. No:1, Kocaali/Sakarya</p>
        <p><i class="bi bi-telephone-fill"></i> <a href="tel:+905424495454">0 (542) 449 5454</a></p>
        <p><i class="bi bi-envelope-fill"></i> <a href="mailto:info@mascarauto.com.tr">info@mascarauto.com.tr</a></p>
        <p><i class="bi bi-clock-fill"></i> Pzt-Cmt: 08:30-19:00</p>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <span data-current-year></span> Mas-Car Auto Özel Servis Kocaali. Tüm hakları saklıdır.</span>
    </div>
  </div>
</footer>

<div class="floating-actions">
  <a href="#" class="fab fab-top" id="scrollTopBtn" aria-label="Yukarı çık"><i class="bi bi-arrow-up"></i></a>
  <a href="tel:+905424495454" class="fab fab-phone" aria-label="Ara"><i class="bi bi-telephone-fill"></i></a>
  <a href="https://wa.me/905424495454" target="_blank" rel="noopener" class="fab fab-whatsapp" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a>
</div>

<div class="mc-cookie" id="mc-cookie">
  <div class="cookie-content" style="display:flex;align-items:flex-start;gap:.75rem;">
    <i class="bi bi-shield-lock-fill" style="color:var(--mc-red);font-size:1.2rem;flex-shrink:0;margin-top:.15rem;"></i>
    <p>Sitemizde çerezler kullanılmaktadır. KVKK kapsamında <a href="javascript:void(0)" onclick="alert('Kişisel Verilerin Korunması Kanunu (KVKK) kapsamında kişisel verileriniz, site kullanımınızı iyileştirmek ve yasal yükümlülükleri yerine getirmek amacıyla işlenmektedir. Detaylı bilgi için bizimle iletişime geçebilirsiniz.')">açıklama</a> için tıklayın.</p>
  </div>
  <button class="btn btn-mc-primary btn-sm-pill" data-cookie-accept>Kabul Et</button>
</div>

<script src="js/main.js" defer></script>
</body>
</html>
